/**
 * 蚂蚁拿块关卡图修改工具 · 界面层（app.js）
 * 任务：ANT-ARTTOOL-CLASSIFY-20260729 · 阶段3（第一阶段：进度区域定位）
 *
 * 职责：导入配对 → 求解/回放（Worker 优先，file:// 下自动退回主线程）→ 进度吸附 → 两状态差值 → 描边高亮。
 * 所有求解与模拟一律走本工具目录下的 bin/js/（正式代码的副本，2026-08-03 起随工具打包），
 * 本文件不含任何求解算法。正式来源仍是项目根目录的 bin/，见 bin/来源说明.md。
 */
(function () {
  'use strict';

  var C = window.ArtToolCore;
  var $ = function (id) { return document.getElementById(id); };

  var S = {
    items: [],          // 每关：{key,txtName,levelName,solveName,blocks,level,solve,tl,pxStep,interval,routes,merged,warns}
    index: {},          // key（去扩展名的文件名）→ item，用于同名索引匹配
    cur: -1,
    worker: null,
    workerReady: null,  // null=未探测 true=可用 false=退回主线程
    onWorkerMsg: null,
    busy: false,
    demo: {             // 自动演示播放状态（不影响已定位的区间结果，只是另一套只读游标）
      timer: null,
      idx: 0            // 0=开局；1..n=第几步结束
    },
    edit: {              // 美术编辑状态：拖动绘制 / 框选编辑（局部统计/局部替换/局部绘制）+ 整图替换 + 靠色检查 + 撤销 + 导出
      on: false,
      color: 1,
      // 'paint'=拖动绘制（默认） 'select'=矩形框选 'lasso'=套索 'region'=同色连通块 'color'=按色选
      // 后三种是任务 ANT-ARTTOOL-SUBJECT-EXTRACT-20260902 新增的主体提取选法
      tool: 'paint',
      original: null,      // 进入编辑模式时的像素矩阵快照（还原用）
      undoStack: [],       // 每步 {r,c,before,after} 数组（一次点选/一次替换算一批）
      // selection 仍是 {r0,c0,r1,c1}（闭区间），但自本轮起它是 **mask 的外接矩形**，
      //   保留它是因为若干既有面板按矩形显示「选区 W×H、行 a–b 列 c–d」；
      //   **真正的选区权威是 mask** —— 不规则选区（套索/同色块）无法用矩形表达。
      //   凡是要「选区内的格子」的地方一律走 selCells()，不要再直接 cellsInRect(selection)。
      selection: null,
      mask: null,          // C.maskNew() 掩码：本轮起的选区权威。null = 未选
      dragging: false, dragStart: null, dragCurrent: null,   // 拖拽框选中的临时状态
      lassoPath: null,     // 套索拖拽中的轨迹 [{r,c}]，松手后转成掩码
      paintDragging: false,   // 「选区内绘制」模式下正在拖拽连续绘制
      replacing: null      // {scope:'global'|'selection', oldId} 正在等待用户从色库选目标色完成替换
    },
    // 主体提取：剔除操作的撤销栈。与 edit.undoStack 分开 ——
    //   那个是「逐像素改色」的批次栈，这里存的是整张图的快照（剔除一次可能动几百格，
    //   逐像素记反而更大），两者互不干扰，各自的撤销按钮也分开。
    extract: { undo: [], lastResult: null },
    pieceLib: [],          // 图纸库（type='artPiece' 的条目），见 PIECE_LIB_STORAGE_KEY
    viewMode: 'before',    // 'before'=查看原关卡 'after'=查看重构后关卡（仅影响 draw()/演示/棋盘展示，不影响编辑/定位等操作对象）
    genParams: null,       // 用户导入的生成器标准参数：{ recognized, unrecognized, source, fileName }，未导入为 null
    exportLib: [],          // 待导出库条目数组，见 EXPORT_LIB_STORAGE_KEY 持久化说明
    // 界面偏好（2026-09-15 需求④）：artOnly = 纯美术编辑模式；collapsed = {卡片id:1} 折叠状态。
    // 只影响显示，不影响任何数据；持久化在 UI_PREF_STORAGE_KEY。
    ui: { artOnly: false, collapsed: {} },
    /* 拼接工作台（任务 ANT-ARTTOOL-PIECE-COMPOSE-20260915）。
     * 与 S.items（导入的关卡）**完全分开**：拼接是在一张新画布上摆部件，
     * 不是在编辑某一关，混进 S.items 会让既有的求解/重构/导出链路读到一个没有关卡本体的条目。
     * layers 里每个 = { id, name, blocks, rows, cols, offR, offC, locked, visible }
     *   —— 位置只由 offR/offC 表示，拖拽不动像素，所以拖来拖去是无损的。 */
    compose: {
      active: false,
      rows: 0, cols: 0,        // 0 = 还没建画布
      sources: [],             // 可用部件（导入的 txt / 从图纸库取的），不直接参与出图
      layers: [],              // 画布上的图层，数组顺序 = 层序（后面盖前面）
      selected: [],            // 选中的图层 id（多选用于合并成新主体）
      drag: null,              // 移动图层的拖拽态
      paintDrag: null,         // 手动涂色的一笔（连续拖动期间）
      shapeDrag: null,         // 直线/边框的「拖范围」态，松手才落笔
      lastBorder: null,        // 上一次生成的边框形态，供「局部替换某一部件的颜色」
      undo: [],                // 绘制撤销栈（存整层快照；一次直线/边框动几十上百格，逐格记反而更大）
      nextId: 1,
      lastAudit: null
    }
  };

  // 待导出库持久化：用 localStorage 保存，页面刷新或重新打开后仍能恢复（需求 §六.3）。
  // 只存"当前必需的最小数据集"（原/新关卡、原/新目标图、求解pickOrder等纯JSON数据），
  // 不存 canvas/DOM 引用等不可序列化对象；体量上一份典型55x55关卡的待导出条目约几十KB，
  // localStorage 单域通常有 5-10MB 上限，实践中可支持数十到上百个待导出条目。
  var EXPORT_LIB_STORAGE_KEY = 'antArtTool_exportLibrary_v1';
  // 图纸库单独一个 key：它与关卡待导出库是两类东西（图纸只有像素矩阵、没有关卡），
  // 混在同一个数组里会让既有的批量导出逻辑（无条件读 originalLevel）直接抛错。
  var PIECE_LIB_STORAGE_KEY = 'antArtTool_pieceLibrary_v1';
  // 界面偏好（纯美术编辑模式 + 各卡片折叠状态）。与两个数据库分开存：
  // 这是「怎么看」的偏好，不是数据，清掉它不该影响任何图纸或关卡。
  var UI_PREF_STORAGE_KEY = 'antArtTool_uiPrefs_v1';

  // 纯美术编辑模式下要收起来的卡片（用户 2026-09-15 需求④：
  //「把其他关于生产关卡，暂存压力等功能收缩起来」）。
  // 留下的是：1.导入、5.显示与导出（在中栏）、8.美术编辑、12.主体提取 ——
  // 这样「美术编辑」与「主体提取」在右栏里直接相邻，不用中间隔着 9/10/11 三张卡来回滚。
  // 具体隐藏由 CSS 的 body.artOnly 规则做，这里只列出清单供面板提示与回归核对使用。
  var ART_ONLY_HIDDEN = ['cardSolve', 'cardInterval', 'cardMulti', 'cardDemo',
    'cardPressure', 'cardRecon', 'cardExportLib'];
  // 用户需求④原话是「可以将**所有**的功能可选择的折叠隐藏」，所以每新增一张卡片都要登记到这里。
  // 2026-09-15 补入 composeCard（拼接）—— 漏登记的话那张卡片点标题没反应，属于静默失效。
  var COLLAPSIBLE_CARDS = ['cardImport', 'cardSolve', 'cardInterval', 'cardMulti', 'cardDemo',
    'editCard', 'cardPressure', 'cardRecon', 'cardExportLib', 'extractCard', 'composeCard'];

  // ==================== 日志与遮罩 ====================
  function log(msg) {
    var el = $('log');
    var t = new Date().toTimeString().slice(0, 8);
    el.textContent += '[' + t + '] ' + msg + '\n';
    el.scrollTop = el.scrollHeight;
  }
  function overlay(show, text) {
    $('overlay').classList.toggle('hidden', !show);
    if (text != null) $('overlayText').textContent = text;
  }

  // ==================== 破坏性操作的两段式二次确认 ====================
  // 用户 2026-08-20 中途任务：「还原为原图」「清空待导出库」手误点一下就把成果弄没了，要二次确认。
  //
  // 为什么不用原生 confirm()：本工具内零 confirm、零 alert，所有反馈都走页面内 log()。
  // 弹窗会打断这套既有风格，而且 confirm 会阻塞渲染。两段式按钮同样挡得住手误，且不打断流程。
  //
  // 时序：点击① → 待确认态 + 冷却期(期间点击一律忽略，这是挡连击/双击穿透的关键)
  //      → 冷却后 TIMEOUT 内 点击② → 执行动作并复位
  //      → 超时 / 按 Esc / 按钮失焦 → 自动复位，动作不执行
  var CONFIRM_COOLDOWN_MS = 400;    // 冷却：这段时间内的第二次点击判定为手误连击，忽略
  var CONFIRM_TIMEOUT_MS = 4000;    // 待确认态存活时长，超时自动放弃，按钮不长期停在危险态
  var armedConfirms = [];           // 当前处于待确认态的复位函数（供 Esc 一次性全部取消）

  /**
   * 给按钮套一道二次确认。只改「点击 → 执行」之间的触发路径，不碰被触发的操作本身。
   * @param {string} id 按钮 DOM id
   * @param {object} o
   *   o.confirmText 待确认态显示的按钮文案
   *   o.hint        进入待确认态时写入日志的说明；可以是字符串或返回字符串的函数（需要动态数量时用函数）
   *   o.action      确认后真正执行的函数
   *   o.guard       返回 false 则不进入待确认态（前置条件不满足，例如库本来就是空的）
   */
  function armConfirm(id, o) {
    var btn = $(id);
    if (!btn) return null;
    var originalText = btn.textContent;
    var armedAt = 0, timer = null;

    function reset() {
      if (timer) { clearTimeout(timer); timer = null; }
      armedAt = 0;
      btn.textContent = originalText;
      btn.classList.remove('confirming');
      var i = armedConfirms.indexOf(reset);
      if (i >= 0) armedConfirms.splice(i, 1);
    }

    btn.onclick = function () {
      if (armedAt) {
        // —— 第二段 ——
        if (Date.now() - armedAt < CONFIRM_COOLDOWN_MS) return;   // 冷却内 = 手误连击，吞掉
        reset();
        o.action();
        return;
      }
      // —— 第一段：只进入待确认态，绝不执行动作 ——
      if (typeof o.guard === 'function' && !o.guard()) return;
      armedAt = Date.now();
      btn.textContent = o.confirmText;
      btn.classList.add('confirming');
      armedConfirms.push(reset);
      timer = setTimeout(reset, CONFIRM_TIMEOUT_MS);
      if (o.hint) log(typeof o.hint === 'function' ? o.hint() : o.hint);
    };
    // 焦点离开按钮（去点了别处）即放弃确认，避免危险态被遗留在页面上
    btn.addEventListener('blur', function () { if (armedAt) reset(); });
    return reset;
  }

  /** 取消当前所有待确认态（Esc 用）。 */
  function cancelArmedConfirms() {
    if (!armedConfirms.length) return false;
    armedConfirms.slice().forEach(function (fn) { fn(); });
    return true;
  }
  function busy(on) {
    S.busy = on;
    ['btnSolve', 'btnLocate', 'btnRoutes', 'fileInput', 'dirInput'].forEach(function (id) {
      var el = $(id); if (el) el.disabled = on;
    });
  }
  function kvTable(rows) {
    var h = '<table>';
    for (var i = 0; i < rows.length; i++) {
      h += '<tr><td class="k">' + rows[i][0] + '</td><td class="v">' + rows[i][1] + '</td></tr>';
    }
    return h + '</table>';
  }

  // ==================== 导入 ====================
  /** 索引键 = 去掉扩展名的文件名（`.solve.json` 视为一个整体扩展名）。同键 = 同一关。 */
  function baseKey(name) {
    return String(name).replace(/\.solve\.json$/i, '').replace(/\.json$/i, '').replace(/\.txt$/i, '');
  }
  function getItem(key) {
    var it = S.index[key];
    if (it) return it;
    it = { key: key, warns: [] };
    S.index[key] = it;
    S.items.push(it);
    return it;
  }

  /**
   * 读取一批文件（来自「选择文件」或「选择文件夹」，文件夹会递归给出全部子文件）。
   * 只收 .txt / .json，其余（.DS_Store、图片、csv、md…）静默忽略并计数。
   * 用固定并发的队列逐个读，边读边报进度，避免一次性起上千个 FileReader。
   */
  function readFiles(fileList, fromDir) {
    var all = Array.prototype.slice.call(fileList);
    var files = all.filter(function (f) { return /\.(txt|json)$/i.test(f.name); });
    var ignored = all.length - files.length;
    if (!files.length) {
      log('本次选择的 ' + all.length + ' 个文件里没有 .txt / .json，未导入');
      return;
    }

    /* 预判：同名是否存在关卡文件（靠文件名判断，`*.solve.json` 是求解数据，其余 .json 视为关卡）。
     * 有关卡文件时，求解数据只需保留 pickOrder，可丢掉体积最大的 replay.steps 等字段，
     * 避免整批 348 关全量驻留内存；没有关卡文件时才保留 replay 作为兜底显示。 */
    var hasLevel = {};
    files.forEach(function (f) {
      if (/\.json$/i.test(f.name) && !/\.solve\.json$/i.test(f.name)) hasLevel[baseKey(f.name)] = true;
    });

    /* 汇总类伴生文件识别（2026-08-05 §导出对齐）：生成器导出包里的 关卡数据/关卡数据.json
     * 是整批聚合（{type:'ant-level-data', levels:[...]}），不是单关文件。core.js 的 detectKind
     * 对它返回 'unknown'，若直接计入 bad 会在日志里显示成「读不出来的文件」，误导使用者。
     * 只在本文件做这一层判定，不改 core.js。 */
    function isAggregateFile(text) {
      try {
        var j = JSON.parse(text);
        return !!(j && j.type === 'ant-level-data' && Array.isArray(j.levels));
      } catch (e) { return false; }
    }
    var added = 0, bad = 0, processed = 0, active = 0, i = 0, skippedAggregate = 0;
    var LIMIT = 8;
    busy(true);
    overlay(true, '读取 0/' + files.length + ' 个文件…');
    log('开始导入' + (fromDir ? '文件夹' : '') + '：可用 ' + files.length + ' 个文件' +
      (ignored ? '，忽略 ' + ignored + ' 个非 txt/json' : ''));

    function handleOne(f, text) {
      var kind = C.detectKind(f.name, text);
      var key = baseKey(f.name);
      try {
        if (kind === 'txt') {
          var a = getItem(key);
          a.txtName = f.name; a.blocks = C.parseTxt(text); a.tl = null; a.interval = null;
          added++;
        } else if (kind === 'level' || kind === 'leveldata') {
          var b = getItem(key);
          b.levelName = f.name; b.level = JSON.parse(text); b.levelKind = kind;
          b.tl = null; b.interval = null;
          added++;
        } else if (kind === 'solve') {
          var c = getItem(key);
          var sv = JSON.parse(text);
          if (hasLevel[key]) {
            // 只留重放所需的最小集合 + 正式压力审核所需的两类真实数据（pickOrder 是求解器真实产出，
            // 逐步轨迹由工具真机口径重放；pressureSamples/stepBufferHistory 是求解时的真实压力样本，
            // 正式压力审核/前中后压力/卡点位置必须用它们，不能靠点击时间线反推——需求07.30 §三.2 明确要求，
            // 体积很小（每关约几十到上百条 {done,buf}），不是丢掉 replay.steps 那个量级的问题）。
            sv = {
              meta: sv.meta, summary: sv.summary, pickOrder: sv.pickOrder, audit: sv.audit, player: sv.player,
              pressureSamples: sv.pressureSamples, stepBufferHistory: sv.stepBufferHistory
            };
          }
          c.solveName = f.name; c.solve = sv; c.tl = null; c.interval = null;
          added++;
        } else if (isAggregateFile(text)) {
          // 生成器导出包的【汇总类】伴生文件（关卡数据/关卡数据.json）：整批聚合，不是单关文件。
          // 以前它落进 detectKind 的 'unknown' → 被计入「读不出来的文件」，看着像导入出错，
          // 其实是正常伴生文件——单关内容已由同批的 关卡/、txt图/、求解数据/ 三件套提供。
          // 这里显式识别为「跳过」而不是「失败」。判定放在本文件、不动 core.js 的 detectKind。
          skippedAggregate++;
        } else {
          bad++;
          if (bad <= 10) log('无法识别（既不是关卡本体也不是求解数据）：' + f.name);
        }
      } catch (e) {
        bad++;
        if (bad <= 10) log('解析失败 ' + f.name + '：' + (e && e.message));
      }
    }

    function pump() {
      while (active < LIMIT && i < files.length) {
        var f = files[i++];
        active++;
        (function (f) {
          var fr = new FileReader();
          fr.onload = function () { handleOne(f, fr.result); step(); };
          fr.onerror = function () { bad++; step(); };
          fr.readAsText(f);
        })(f);
      }
      if (active === 0 && i >= files.length) {
        busy(false); overlay(false);
        finishImport(added, bad, ignored, skippedAggregate);
      }
    }
    function step() {
      active--; processed++;
      if (processed % 40 === 0) overlay(true, '读取 ' + processed + '/' + files.length + ' 个文件…');
      pump();
    }
    pump();
  }

  function finishImport(added, bad, ignored, skippedAggregate) {
    // 目标图来源：优先 TXT；没有 TXT 时用关卡本体内的 blocks（两者都有则做一致性校验）
    S.items.forEach(function (it) {
      it.warns = [];
      var fromLevel = it.level && it.level.blocks && it.level.blocks.length ? it.level.blocks : null;
      if (!it.blocks && fromLevel) { it.blocks = fromLevel; it.warns.push('目标图取自关卡本体 blocks（未导入 TXT）'); }
      if (it.blocks && fromLevel) {
        var same = it.blocks.length === fromLevel.length && it.blocks.every(function (row, r) {
          return row.length === fromLevel[r].length && row.every(function (v, c) { return v === fromLevel[r][c]; });
        });
        if (!same) it.warns.push('⚠ TXT 与关卡本体 blocks 不一致（以 TXT 为显示，求解仍用关卡本体）');
      }
      if (!it.level) it.warns.push('缺关卡文件：无法求解，只能看图（阶段二将支持从 TXT 重建关卡）');
    });
    // 排序会打乱下标，先记住当前选中的关名，排完再按名字找回
    var curKey = S.cur >= 0 && S.items[S.cur] ? S.items[S.cur].key : null;
    S.items.sort(function (a, b) { return a.key < b.key ? -1 : (a.key > b.key ? 1 : 0); });
    S.cur = -1;
    if (curKey) {
      for (var i = 0; i < S.items.length; i++) if (S.items[i].key === curKey) { S.cur = i; break; }
    }

    // 配套统计：三件套齐全的关数
    var full = 0, noLevel = 0, noSolve = 0, noTxt = 0;
    S.items.forEach(function (x) {
      if (x.txtName && x.level && x.solve) full++;
      if (!x.level) noLevel++;
      if (!x.solve) noSolve++;
      if (!x.txtName) noTxt++;
    });
    $('importStat').innerHTML = '共 <b>' + S.items.length + '</b> 关　三件套齐全 ' + full +
      '　缺关卡 ' + noLevel + '　缺求解 ' + noSolve + '　缺TXT ' + noTxt +
      '<br><span class="muted">本次读入 ' + added + ' 个文件，失败 ' + bad +
      (skippedAggregate ? '，跳过汇总文件 ' + skippedAggregate : '') +
      (ignored ? '，忽略非 txt/json ' + ignored : '') + '</span>';
    renderList();
    if (S.cur < 0 && S.items.length) select(0);
    log('导入完成：索引 ' + S.items.length + ' 关（三件套齐全 ' + full + '，缺关卡 ' + noLevel + '，缺求解 ' + noSolve + '，缺TXT ' + noTxt + '）' +
      (skippedAggregate ? '；已跳过 ' + skippedAggregate + ' 个汇总文件（关卡数据.json 这类整批聚合，非单关数据，不影响导入）' : ''));
  }

  function renderList() {
    var kw = ($('listFilter') && $('listFilter').value || '').trim().toLowerCase();
    var h = '', shown = 0;
    for (var i = 0; i < S.items.length; i++) {
      var it = S.items[i];
      if (kw && it.key.toLowerCase().indexOf(kw) < 0) continue;
      shown++;
      if (shown > 500) { h += '<div class="item muted">…还有更多，请用过滤框缩小范围</div>'; break; }
      var tags = '';
      tags += '<span class="tag ' + (it.txtName ? 'ok' : (it.blocks ? 'warn' : 'bad')) + '">图</span>';
      tags += '<span class="tag ' + (it.level ? 'ok' : 'bad') + '">关卡</span>';
      tags += '<span class="tag ' + (it.solve ? 'ok' : '') + '">求解</span>';
      h += '<div class="item' + (i === S.cur ? ' active' : '') + '" data-i="' + i + '">' +
        '<span class="nm">' + it.key + '</span>' + tags + '</div>';
    }
    $('levelList').innerHTML = h || '<div class="item muted">' + (S.items.length ? '无匹配' : '暂无') + '</div>';
    Array.prototype.forEach.call($('levelList').querySelectorAll('.item[data-i]'), function (el) {
      el.onclick = function () { select(+el.getAttribute('data-i')); };
    });
  }

  function select(i) {
    S.cur = i;
    renderList();
    var it = S.items[i];
    // 切关：暂停演示、清空棋盘面板、关闭编辑模式（编辑快照与新关卡的 blocks 不是同一份数据，不能带着切）
    demoPause();
    S.demo.idx = 0;
    if ($('optEdit').checked) { $('optEdit').checked = false; }
    S.edit.on = false; S.edit.original = null; S.edit.undoStack = [];
    clearSelection(); S.edit.replacing = null; S.edit.paintDragging = false;
    $('cv').classList.remove('editing');
    it._playerOne = undefined;   // 切关后原关卡玩家结果缓存清空，避免用上一关的结果
    renderSolveInfo();
    renderInterval();
    renderRoutes();
    refreshEditPanels();
    renderEditInfo();
    refreshBoardPanel();
    refreshPressureChart();
    resetReconView();
    draw();
    log('选中 ' + it.key + (it.warns.length ? '（' + it.warns.join('；') + '）' : ''));
  }

  function cur() { return S.cur >= 0 ? S.items[S.cur] : null; }

  /**
   * 视图对象：draw()/棋盘展示/自动演示按 S.viewMode 决定显示原关卡还是重构后关卡的数据，
   * 但导入/求解/进度定位/多路线/美术编辑/重构操作全部仍作用在 cur()（真实的关卡条目）上，不受视图切换影响。
   * 重构后视图是从 it.reconResult 惰性构建的一个「只读展示包」，字段形状与 it 一致（blocks/tl/interval/pxStep/verify），
   * 但不写回 it，也不参与导入索引。
   */
  function viewItem() {
    var it = cur();
    if (!it) return null;
    if (S.viewMode !== 'after' || !it.reconResult || !it.reconResult.ok) return it;
    var rr = it.reconResult;
    if (!rr.tl) rr.tl = C.reconstructToTimeline(rr);
    if (!rr.viewWrap) rr.viewWrap = { key: it.key + '（重构后）', blocks: null, level: rr.level, warns: [] };
    var vw = rr.viewWrap;
    vw.blocks = rr.level.blocks;
    vw.tl = rr.tl;
    if (rr.tl && !vw._pxBuilt) {
      vw.pxStep = {};
      for (var i = 0; i < rr.tl.steps.length; i++) {
        var s = rr.tl.steps[i];
        for (var j = 0; j < s.cells.length; j++) vw.pxStep[s.cells[j]] = { step: s.step, done: s.done };
      }
      vw.verify = C.verifyTimeline(rr.tl);
      vw._pxBuilt = true;
    }
    // 区间：沿用当前已定位区间的「用户要求区间」百分比，在重构后关卡的时间线上重新吸附计算，
    // 保证两边比较的是同一个用户输入区间，而不是同一组扁平像素下标（棋盘尺寸可能不同）。
    if (it.interval && rr.tl && rr.tl.completed) {
      var iv2 = C.snapInterval(rr.tl.steps, rr.tl.totalBoxes, it.interval.requested.lo / 100, it.interval.requested.hi / 100);
      if (iv2) { iv2.comps = C.connectedComponents(iv2.diffPixels, rr.tl.rows, rr.tl.cols); vw.interval = iv2; }
      else vw.interval = null;
    } else {
      vw.interval = null;
    }
    vw.merged = null; vw.routes = null;   // 多路线复核不对重构后关卡重跑，视图切到 after 时不显示多路线分层
    return vw;
  }

  // ==================== 求解信息面板 ====================
  function renderSolveInfo() {
    var it = cur();
    if (!it) { $('solveInfo').innerHTML = '<span class="muted">请先选择一关</span>'; return; }
    var rows = [];
    rows.push(['关卡', it.key]);
    rows.push(['目标图', it.blocks ? (it.blocks.length + ' × ' + it.blocks[0].length + '，' + countPixels(it.blocks) + ' 像素') : '<span class="tag bad">缺失</span>']);
    rows.push(['关卡文件', it.levelName || '<span class="tag bad">缺失</span>']);
    rows.push(['求解数据', it.solveName || '<span class="muted">未导入（可现场求解）</span>']);
    if (it.tl) {
      rows.push(['路线来源', it.tl.source + (it.tl.pass != null ? '（命中遍 ' + it.tl.pass + '）' : '')]);
      rows.push(['是否通关', it.tl.completed ? '<span class="tag ok">通关</span>' : '<span class="tag bad">未通关</span>']);
      rows.push(['求解步数', it.tl.steps_count]);
      rows.push(['总盒数 / 总像素', it.tl.totalBoxes + ' / ' + it.tl.totalPixels]);
      if (it.verify) {
        rows.push(['时间线自检', '像素合计 ' + it.verify.pixelSum +
          '，重复 ' + it.verify.duplicate + '，越界 ' + it.verify.outOfBounds +
          '，盒数单调 ' + (it.verify.monotonic ? '是' : '否') +
          '，全覆盖 ' + (it.verify.coversAll === null ? '—' : (it.verify.coversAll ? '是' : '否'))]);
      }
    }
    if (it.warns.length) rows.push(['提示', it.warns.join('<br>')]);
    $('solveInfo').innerHTML = kvTable(rows);
  }

  function countPixels(blocks) {
    var n = 0;
    for (var r = 0; r < blocks.length; r++) for (var c = 0; c < blocks[r].length; c++) if (blocks[r][c] > 0) n++;
    return n;
  }

  // ==================== Worker ====================
  function initWorker(cb) {
    if (S.workerReady !== null) return cb(S.workerReady ? S.worker : null);
    var w;
    try { w = new Worker('js/solve-worker.js'); }
    catch (e) { S.workerReady = false; log('无法创建 Worker（' + (e && e.message) + '），改用主线程求解'); return cb(null); }
    var settled = false;
    function fallback(why) {
      if (settled) return;
      settled = true; clearTimeout(to); S.workerReady = false;
      try { w.terminate(); } catch (e) { }
      log('Worker 不可用（' + why + '），改用主线程求解：求解期间页面会短暂无响应');
      cb(null);
    }
    var to = setTimeout(function () { fallback('探活超时'); }, 8000);
    w.onerror = function (e) { fallback((e && e.message) || 'onerror'); };
    w.onmessage = function (ev) {
      var d = ev.data || {};
      if (!settled) {
        if (d.type === 'pong' && d.ready) {
          settled = true; clearTimeout(to); S.workerReady = true; S.worker = w;
          log('Worker 就绪：求解在后台线程执行，页面不卡');
          return cb(w);
        }
        if (d.type === 'pong' || d.type === 'fatal') return fallback(d.error || '正式求解器未载入');
        return;
      }
      if (S.onWorkerMsg) S.onWorkerMsg(d);
    };
    w.postMessage({ cmd: 'ping' });
  }

  // ==================== 求解 / 时间线 ====================
  /** 确保当前关有可用时间线；没有则按「导入求解数据 → 现场求解」的顺序取得。 */
  function ensureTimeline(cb, forceSolve) {
    var it = cur();
    if (!it) return;
    if (it.tl && !forceSolve) return cb(it.tl);

    if (it.solve && !forceSolve) {
      // 首选：只取导入数据里的真实 pickOrder，逐步轨迹由工具按真机口径（useSlotStart）重放。
      // 这样既不必重新求解（快），又保证区域口径与正式求解器/真机一致。
      if (it.level) {
        var tlPO = null;
        try { tlPO = C.timelineFromSolveFilePickOrder(it.solve, it.level, { captureBoard: true }); }
        catch (e) { log('按导入的消除顺序回放失败：' + (e && e.message)); }
        if (tlPO && tlPO.steps.length) {
          if (!tlPO.completed) log('⚠ 按导入的消除顺序回放没走完（' + (tlPO.replayFail || '未全消') + '），不能用于区间定位');
          adoptTimeline(it, tlPO);
          log('已按导入求解数据里的真实消除顺序回放（真机口径，未重新求解）：步 ' + tlPO.steps_count +
            '，命中遍 ' + tlPO.pass);
          return cb(it.tl);
        }
        log('导入的求解数据里没有可用的消除顺序，改为现场求解');
      } else {
        // 没有关卡文件就无法重放，只能退用文件里的旧口径逐步数据，并明确提示
        var tlOld = C.timelineFromSolveFile(it.solve);
        if (tlOld && tlOld.steps && tlOld.steps.length) {
          adoptTimeline(it, tlOld);
          it.warns.push('⚠ 未导入关卡文件，只能用求解数据里阶段2 旧回放口径的逐步轨迹：' +
            '该口径未带 useSlotStart，逐步消除像素与真机/正式求解器不一致，区域仅供粗看。导入关卡文件即可按真机口径重放。');
          renderSolveInfo();
          log('⚠ 使用阶段2 旧回放口径（缺关卡文件，无法真机口径重放）');
          return cb(it.tl);
        }
      }
    }

    if (!it.level) { log('缺关卡文件，无法求解'); return; }

    busy(true); overlay(true, '准备求解…');
    initWorker(function (w) {
      if (w) {
        var reqId = Date.now();
        S.onWorkerMsg = function (d) {
          if (d.reqId !== reqId) return;
          if (d.type === 'stage') { overlay(true, d.text); return; }
          if (d.type === 'fatal') { S.onWorkerMsg = null; busy(false); overlay(false); log('求解失败：' + d.error); return; }
          if (d.type === 'solved') {
            S.onWorkerMsg = null; busy(false); overlay(false);
            if (!d.completed) { log('标准复核未通关（进度 ' + d.progress + '%，步 ' + d.steps + '），不做区间定位'); renderSolveInfo(); return; }
            it.solve = null; it.solveName = null;
            var tl2 = C.timelineFromReplay(d.replay, {
              pass: d.pass, steps_count: d.summary.steps,
              totalBoxes: d.summary.totalBoxes, totalPixels: d.summary.totalPixels, completed: true
            });
            adoptTimeline(it, tl2);
            it.liveSolve = d;
            log('现场求解完成：命中遍 ' + d.pass + '，步 ' + d.summary.steps + '，耗时 ' + (d.solveMs / 1000).toFixed(1) + 's');
            cb(it.tl);
          }
        };
        w.postMessage({ cmd: 'solve', reqId: reqId, level: it.level, budgetMs: C.DEFAULT_BUDGET_MS });
      } else {
        overlay(true, '主线程求解中，请稍候（页面会短暂无响应）…');
        setTimeout(function () {
          try {
            var t0 = Date.now();
            var sv = C.solveStandard(it.level, C.DEFAULT_BUDGET_MS);
            if (!sv.completed) {
              log('标准复核未通关（进度 ' + (sv.result ? sv.result.progress : 0) + '%），不做区间定位');
            } else {
              var rp = C.replay(it.level, sv.result.pickOrder, { captureBoard: true });
              var tl3 = C.timelineFromReplay(rp, { pass: sv.pass, steps_count: sv.result.steps, completed: true });
              it.solve = null; it.solveName = null;
              adoptTimeline(it, tl3);
              it.liveSolve = {
                completed: true, pass: sv.pass, solveMs: Date.now() - t0,
                summary: {
                  steps: sv.result.steps, totalBoxes: sv.parsed.totalBoxes, totalPixels: sv.parsed.totalPixels,
                  eliminatedPixels: sv.result.eliminatedPixels, progress: sv.result.progress,
                  maxBuffer: sv.result.maxBuffer || 0, avgBuffer: sv.result.avgBuffer
                },
                pickOrder: sv.result.pickOrder,
                // 主线程求解分支此前遗漏了这两个真实压力样本字段（Worker 分支因为直接转发完整消息 d 未遗漏），
                // 现场求解（无论走 Worker 还是主线程）都必须能提供正式压力审核数据，两条路径口径一致。
                stepBufferHistory: sv.result.stepBufferHistory,
                pressureSamples: sv.result.pressureSamples
              };
              log('现场求解完成（主线程）：命中遍 ' + sv.pass + '，步 ' + sv.result.steps + '，耗时 ' + ((Date.now() - t0) / 1000).toFixed(1) + 's');
            }
          } catch (e) {
            log('求解异常：' + (e && e.message));
          }
          busy(false); overlay(false); renderSolveInfo();
          if (it.tl) cb(it.tl);
        }, 60);
      }
    });
  }

  /** 采用一条时间线：做自检、建「像素→步」映射、刷新面板。 */
  function adoptTimeline(it, tl) {
    it.tl = tl;
    it.verify = C.verifyTimeline(tl);
    it.pxStep = {};
    for (var i = 0; i < tl.steps.length; i++) {
      var s = tl.steps[i];
      for (var j = 0; j < s.cells.length; j++) it.pxStep[s.cells[j]] = { step: s.step, done: s.done };
    }
    it.interval = null; it.routes = null; it.merged = null;
    it.pressureCurve = null; it._playerOne = undefined;   // 新时间线意味着新求解结果，旧压力曲线/玩家结果缓存必须失效
    // 目标图尺寸与时间线口径核对（像素扁平下标依赖列数）
    if (it.blocks && (it.blocks.length !== tl.rows || it.blocks[0].length !== tl.cols)) {
      it.warns.push('⚠ 目标图 ' + it.blocks.length + '×' + it.blocks[0].length +
        ' 与求解路线记录的 ' + tl.rows + '×' + tl.cols + ' 不一致，高亮位置不可信');
      log('尺寸不一致：目标图 ' + it.blocks.length + '×' + it.blocks[0].length + '，路线 ' + tl.rows + '×' + tl.cols);
    }
    if (it.verify.duplicate || it.verify.outOfBounds || !it.verify.monotonic) {
      log('时间线自检异常：重复 ' + it.verify.duplicate + '，越界 ' + it.verify.outOfBounds + '，单调 ' + it.verify.monotonic);
    }
    renderSolveInfo();
    refreshBoardPanel();   // 有了新时间线（哪怕还没定位区间）就能看棋盘区+暂存区，不必强制先定位
    refreshPressureChart();
  }

  // ==================== 区间定位 ====================
  function locate() {
    var it = cur();
    if (!it) return;
    var lo = parseFloat($('loPct').value), hi = parseFloat($('hiPct').value);
    if (isNaN(lo) || isNaN(hi)) { log('请输入有效的上下限百分比'); return; }
    lo = Math.max(0, Math.min(100, lo)); hi = Math.max(0, Math.min(100, hi));
    // 重新定位前先停掉演示播放：定时器仍在跑的话会用旧游标反复重绘，盖掉本次刚画好的新结果。
    demoPause();
    ensureTimeline(function (tl) {
      if (!tl.completed) { log('该路线未通关，拒绝出区间结果'); return; }
      var iv = C.snapInterval(tl.steps, tl.totalBoxes, lo / 100, hi / 100);
      if (!iv) { log('区间计算失败：时间线为空'); return; }
      iv.comps = C.connectedComponents(iv.diffPixels, tl.rows, tl.cols);
      // 用新结果完整替换旧区间：多路线分层（routes/merged）与区间区域对比缓存都是针对上一次
      // lo/hi 算出来的，不清空的话 draw() 里 anyMultiOn && it.merged 分支会继续拿旧的多路线
      // 区域盖住本次新区间的高亮。
      it.interval = iv;
      it.routes = null; it.merged = null;
      it._lastRegionCompare = null; it._regionCompareMeta = null;
      $('reconRegionInfo').innerHTML = '';
      $('regionCompareBox').style.display = 'none';
      renderInterval();
      renderRoutes();
      // demoSetupFromInterval() 会把演示游标复位到新区间下限，但它内部会立刻用「演示累计揭示」样式
      // 重绘一次画布（demoRenderAtIdx→demoDrawTarget）。这个累计揭示画面只取决于区间下限对应的步数，
      // 50%-90% 与 50%-60% 的下限同为 50%，两次画出来的内容完全一样——这正是「切换区间后目标图看起来
      // 没变」的根因：原代码把这一步放在 draw() 之后调用，结果它的重绘覆盖掉了 draw() 刚画好的新区间。
      // 修正：demoSetupFromInterval() 放前面只用来复位游标/演示信息面板，refreshBoardPanel()/draw()
      // 放最后，保证画布和棋盘面板最终呈现的是本次新区间的静态高亮结果，不是演示游标画面。
      demoSetupFromInterval();
      refreshBoardPanel();
      refreshPressureChart();
      draw();
      log('区间定位：要求 ' + iv.requested.lo + '%–' + iv.requested.hi + '% → 实际 ' +
        iv.snapped.lo + '%–' + iv.snapped.hi + '%（完成盒 ' + iv.doneBoxes.lo + '–' + iv.doneBoxes.hi +
        '，步 ' + iv.stepIndex.lo + '–' + iv.stepIndex.hi + '），区域 ' + iv.diffPixelCount + ' 像素 / ' + iv.comps.length + ' 连通块');
      // 差值口径自检：B − A 必须等于区间内各步 cells 之和
      var chk = 0;
      for (var i = iv.stepIndex.lo; i < iv.stepIndex.hi; i++) chk += tl.steps[i].cells.length;
      if (chk !== iv.diffPixelCount) log('⚠ 差值自检不一致：逐步求和 ' + chk + ' ≠ B−A ' + iv.diffPixelCount);
    });
  }

  function renderInterval() {
    var it = cur(), iv = it && it.interval;
    if (!iv) { $('intervalInfo').innerHTML = ''; return; }
    var tl = it.tl;
    var rows = [
      ['用户要求区间', '<span class="big">' + iv.requested.lo + '% – ' + iv.requested.hi + '%</span>'],
      ['实际采用区间', '<span class="big">' + iv.snapped.lo + '% – ' + iv.snapped.hi + '%</span>'],
      ['对应完成盒数', iv.doneBoxes.lo + ' – ' + iv.doneBoxes.hi + ' / ' + iv.totalBoxes],
      ['对应步序号', (iv.stepIndex.lo === 0 ? '开局' : '第 ' + iv.stepIndex.lo + ' 步') + ' → 第 ' + iv.stepIndex.hi + ' 步（共 ' + tl.steps_count + ' 步）'],
      ['状态A 已消除', iv.stateAPixelCount + ' 像素'],
      ['状态B 已消除', iv.stateBPixelCount + ' 像素'],
      ['区间区域 B−A', '<span class="big">' + iv.diffPixelCount + ' 像素</span>，' + iv.comps.length + ' 个连通块'],
      ['占全图比例', tl.totalPixels ? (iv.diffPixelCount / tl.totalPixels * 100).toFixed(2) + '%' : '—']
    ];
    if (iv.empty) rows.push(['提示', '<span class="tag warn">区间为空</span> 上下限吸附到了同一个可达进度，请拉开区间']);
    $('intervalInfo').innerHTML = kvTable(rows);
  }

  // ==================== 多路线复核 ====================
  function runRoutes() {
    var it = cur();
    if (!it) return;
    if (!it.level) { log('缺关卡文件，无法做多路线复核'); return; }
    var want = parseInt($('routeCount').value, 10) || 3;
    var lo = Math.max(0, Math.min(100, parseFloat($('loPct').value))) / 100;
    var hi = Math.max(0, Math.min(100, parseFloat($('hiPct').value))) / 100;

    busy(true); overlay(true, '多路线复核准备中…');
    initWorker(function (w) {
      function finish(routes, tried) {
        busy(false); overlay(false);
        if (!routes.length) { log('多路线复核：没有取到可通关路线'); return; }
        var intervals = routes.map(function (rt) {
          return C.snapInterval(rt.timelineSteps, rt.totalBoxes, lo, hi);
        });
        var merged = C.mergeRouteRegions(intervals);
        it.routes = { routes: routes, tried: tried, intervals: intervals };
        it.merged = merged;
        renderRoutes();
        draw();
        log('多路线复核完成：' + routes.length + ' 条不重复路线，稳定 ' + merged.stable.length +
          ' / 高频 ' + merged.frequent.length + ' / 浮动 ' + merged.floating.length + ' 像素');
      }
      if (w) {
        var reqId = Date.now();
        S.onWorkerMsg = function (d) {
          if (d.reqId !== reqId) return;
          if (d.type === 'stage') { overlay(true, d.text); return; }
          if (d.type === 'fatal') { S.onWorkerMsg = null; busy(false); overlay(false); log('多路线失败：' + d.error); return; }
          if (d.type === 'routes') { S.onWorkerMsg = null; finish(d.routes, d.tried); }
        };
        w.postMessage({ cmd: 'routes', reqId: reqId, level: it.level, maxRoutes: want });
      } else {
        overlay(true, '主线程多路线复核中，请稍候（页面会短暂无响应）…');
        setTimeout(function () {
          var seen = {}, routes = [], tried = [];
          for (var i = 0; i < C.ROUTE_PASSES.length && routes.length < want; i++) {
            var p = C.ROUTE_PASSES[i], one = null;
            try { one = C.solveOnePass(it.level, p); } catch (e) { tried.push({ tag: p.tag, error: e && e.message }); continue; }
            if (!one.completed) { tried.push({ tag: p.tag, completed: false, progress: one.result ? one.result.progress : 0 }); continue; }
            var sig = one.result.pickOrder.map(function (x) { return x.r + ',' + x.c; }).join(';');
            if (seen[sig]) { tried.push({ tag: p.tag, completed: true, duplicateOf: seen[sig] }); continue; }
            seen[sig] = p.tag;
            var rp = C.replay(it.level, one.result.pickOrder);
            routes.push({
              tag: p.tag, mode: p.mode, noise: p.noise, seed: p.seed, steps: one.result.steps,
              maxBuffer: one.result.maxBuffer || 0, avgBuffer: one.result.avgBuffer,
              replayOk: rp.ok, replayFail: rp.fail, rows: rp.rows, cols: rp.cols,
              totalBoxes: rp.totalBoxes, totalPixels: rp.totalPixels, timelineSteps: rp.steps
            });
            tried.push({ tag: p.tag, completed: true, accepted: true, steps: one.result.steps });
          }
          finish(routes, tried);
        }, 60);
      }
    });
  }

  function renderRoutes() {
    var it = cur();
    if (!it || !it.routes) { $('routeInfo').innerHTML = ''; return; }
    var R = it.routes, m = it.merged;
    var rows = [['不重复可通关路线', R.routes.length + ' 条']];
    R.routes.forEach(function (rt, i) {
      var iv = R.intervals[i];
      rows.push(['路线 ' + (i + 1) + '（' + rt.tag + '·' + rt.mode + '）',
        '步 ' + rt.steps + '，峰值 ' + rt.maxBuffer + '；实际区间 ' + iv.snapped.lo + '%–' + iv.snapped.hi +
        '%，盒 ' + iv.doneBoxes.lo + '–' + iv.doneBoxes.hi + '，区域 ' + iv.diffPixelCount + ' 像素']);
    });
    rows.push(['稳定区域（全部路线）', '<span class="big">' + m.stable.length + '</span> 像素']);
    rows.push(['高频区域（多数路线）', m.frequent.length + ' 像素']);
    rows.push(['浮动区域（少数路线）', m.floating.length + ' 像素']);
    var skipped = R.tried.filter(function (t) { return !t.accepted; });
    if (skipped.length) {
      rows.push(['未采用的遍次', skipped.map(function (t) {
        return t.tag + '：' + (t.error ? '异常' : (t.duplicateOf ? '与 ' + t.duplicateOf + ' 路线相同（去重）' : '未通关 ' + (t.progress || 0) + '%'));
      }).join('<br>')]);
    }
    $('routeInfo').innerHTML = kvTable(rows);
  }

  // ==================== 绘制 ====================
  var STROKE = {
    single: '#00E5FF',
    stable: '#3BFF9E',
    frequent: '#FFD400',
    floating: '#FF5E5E',
    stateA: '#8A93A6'
  };

  function draw() {
    var cv = $('cv'), ctx = cv.getContext('2d');
    var it = viewItem();
    if (!it || !it.blocks) {
      cv.width = 600; cv.height = 200;
      ctx.fillStyle = '#0f1216'; ctx.fillRect(0, 0, cv.width, cv.height);
      ctx.fillStyle = '#5d6779'; ctx.font = '13px sans-serif';
      ctx.fillText('导入 TXT 目标图 / 关卡文件后在此显示', 20, 40);
      $('legend').innerHTML = '';
      return;
    }
    var blocks = it.blocks, rows = blocks.length, cols = blocks[0].length;
    var cell = parseInt($('cellSize').value, 10) || 11;
    cv.width = cols * cell + 1; cv.height = rows * cell + 1;

    ctx.fillStyle = '#0f1216'; ctx.fillRect(0, 0, cv.width, cv.height);

    var iv = it.interval;
    var inDiff = {};
    if (iv) for (var i = 0; i < iv.diffPixels.length; i++) inDiff[iv.diffPixels[i]] = 1;
    var dim = $('optDim').checked && iv;

    // ① 原图像素（描边只画在格线上，不覆盖任何像素颜色）
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        var id = blocks[r][c];
        if (!id) continue;
        ctx.fillStyle = window.AntSolver.getColorCSS(id);
        ctx.fillRect(c * cell, r * cell, cell, cell);
        if (dim && !inDiff[r * cols + c]) {
          ctx.fillStyle = 'rgba(10,12,16,0.62)';
          ctx.fillRect(c * cell, r * cell, cell, cell);
        }
      }
    }

    // ①b 碎色像素高亮（任务 ANT-ARTTOOL-FRAGMENT-QUOTA-20260825）
    // 画在原图之上、格线之下：用醒目描边圈出「被判为碎色」的像素，让美术直接看到该修哪里。
    // 只在勾选了高亮、且已算过碎色、且算的就是当前这张图时才画（换关卡后不拿上一关的结果乱标）。
    if ($('fragHighlight') && $('fragHighlight').checked && fragState.result &&
        fragState.key === it.key && fragState.result.fragCells.length) {
      var fc = fragState.result.fragCells;
      ctx.save();
      // 半透明红色蒙层 + 白色细边：蒙层保证小格子也看得见，白边保证在深色像素上不糊
      for (var fi = 0; fi < fc.length; fi++) {
        var p = fc[fi];
        if (p.r >= rows || p.c >= cols) continue;
        ctx.fillStyle = 'rgba(255,64,64,0.42)';
        ctx.fillRect(p.c * cell, p.r * cell, cell, cell);
      }
      if (cell >= 5) {
        ctx.strokeStyle = 'rgba(255,255,255,0.85)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (var fj = 0; fj < fc.length; fj++) {
          var q = fc[fj];
          if (q.r >= rows || q.c >= cols) continue;
          ctx.rect(q.c * cell + 1.5, q.r * cell + 1.5, cell - 3, cell - 3);
        }
        ctx.stroke();
      }
      ctx.restore();
    }

    // ② 格线
    if ($('optGrid').checked && cell >= 6) {
      ctx.strokeStyle = 'rgba(255,255,255,0.07)'; ctx.lineWidth = 1;
      ctx.beginPath();
      for (var x = 0; x <= cols; x++) { ctx.moveTo(x * cell + .5, 0); ctx.lineTo(x * cell + .5, rows * cell); }
      for (var y = 0; y <= rows; y++) { ctx.moveTo(0, y * cell + .5); ctx.lineTo(cols * cell, y * cell + .5); }
      ctx.stroke();
    }

    // ③ 区间前已消除范围（可选参考线）
    if ($('optA').checked && iv && iv.stateAPixels.length) {
      strokeGroups(ctx, [iv.stateAPixels], rows, cols, cell, STROKE.stateA, 1.2, [3, 3]);
    }

    // ③b 空位斜纹（任务 ANT-ARTTOOL-SUBJECT-EXTRACT-20260902）
    //   剔除后的格子值为 0。0 在画布上本来就没颜色，但「没画东西」和「这里是空的」
    //   在深色底上看起来一样，美术分不清主体边界到哪。所以给 0 画斜纹底。
    //   只在图里确实存在 0 时才画，避免给没剔过的图无谓加纹理。
    if (!$('optShowVoid') || $('optShowVoid').checked) {
      var hasVoid = false;
      for (var vr = 0; vr < rows && !hasVoid; vr++) {
        for (var vc = 0; vc < cols; vc++) { if (blocks[vr][vc] <= 0) { hasVoid = true; break; } }
      }
      if (hasVoid) {
        ctx.save();
        for (var zr = 0; zr < rows; zr++) {
          for (var zc = 0; zc < cols; zc++) {
            if (blocks[zr][zc] > 0) continue;
            var zx = zc * cell, zy = zr * cell;
            ctx.fillStyle = '#2b1e15';
            ctx.fillRect(zx, zy, cell, cell);
            // 斜纹：两条对角细线，格子小到 3px 以下就只填底色（画线也看不清）
            if (cell >= 4) {
              ctx.strokeStyle = 'rgba(120,96,74,0.55)';
              ctx.lineWidth = 1;
              ctx.beginPath();
              ctx.moveTo(zx, zy + cell); ctx.lineTo(zx + cell, zy);
              ctx.moveTo(zx, zy + cell / 2); ctx.lineTo(zx + cell / 2, zy);
              ctx.moveTo(zx + cell / 2, zy + cell); ctx.lineTo(zx + cell, zy + cell / 2);
              ctx.stroke();
            }
          }
        }
        ctx.restore();
      }
    }

    // ④ 高亮：多路线分层（三类各自独立开关，可任意组合）或单路线区间。
    // 三个开关互相独立：切换只重绘（本函数本身），不重新执行多路线求解——求解结果已存在 it.merged，
    // 这里只是按开关状态决定要不要画某一类，不触碰 it.merged 数据本身。
    var legend = [];
    var anyMultiOn = $('showStable').checked || $('showFrequent').checked || $('showFloating').checked;
    if (anyMultiOn && it.merged) {
      var m = it.merged;
      if ($('showStable').checked && m.stable.length) { strokeGroups(ctx, groups(m.stable, rows, cols), rows, cols, cell, STROKE.stable, 2, null); legend.push([STROKE.stable, '稳定区域（全部 ' + m.routeCount + ' 条路线）' + m.stable.length + ' 像素', 'solid']); }
      if ($('showFrequent').checked && m.frequent.length) { strokeGroups(ctx, groups(m.frequent, rows, cols), rows, cols, cell, STROKE.frequent, 2, [5, 3]); legend.push([STROKE.frequent, '高频区域（多数路线）' + m.frequent.length + ' 像素', 'dashed']); }
      if ($('showFloating').checked && m.floating.length) { strokeGroups(ctx, groups(m.floating, rows, cols), rows, cols, cell, STROKE.floating, 2, [2, 3]); legend.push([STROKE.floating, '浮动区域（少数路线）' + m.floating.length + ' 像素', 'dotted']); }
    } else if (iv && iv.diffPixels.length) {
      var gs = $('optComp').checked ? iv.comps : [iv.diffPixels];
      strokeGroups(ctx, gs, rows, cols, cell, STROKE.single, 2, null);
      legend.push([STROKE.single, '区间消除区域（' + iv.snapped.lo + '%–' + iv.snapped.hi + '%）' + iv.diffPixelCount + ' 像素 / ' + gs.length + ' 块', 'solid']);
      // 连通块编号（块数不多且格子够大时标注，方便美术口头指位）
      if ($('optComp').checked && iv.comps.length <= 30 && cell >= 9) {
        ctx.font = 'bold ' + Math.max(9, Math.floor(cell * 0.9)) + 'px Menlo, monospace';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        for (var k = 0; k < iv.comps.length; k++) {
          var comp = iv.comps[k], sr = 0, sc = 0;
          for (var t = 0; t < comp.length; t++) { sr += Math.floor(comp[t] / cols); sc += comp[t] % cols; }
          var tx = (sc / comp.length + 0.5) * cell, ty = (sr / comp.length + 0.5) * cell;
          ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,0.85)';
          ctx.strokeText(String(k + 1), tx, ty);
          ctx.fillStyle = STROKE.single;
          ctx.fillText(String(k + 1), tx, ty);
        }
      }
    }
    if ($('optA').checked && iv) legend.push([STROKE.stateA, '区间前已消除范围（状态A）', 'dashed']);

    $('legend').innerHTML = legend.map(function (l) {
      return '<span><i class="sw" style="border-top-color:' + l[0] + ';border-top-style:' + l[2] + '"></i>' + l[1] + '</span>';
    }).join('');

    // ⑤ 选区预览（编辑模式下才画；不覆盖任何像素颜色，只淡淡着色 + 描边）
    //   任务 ANT-ARTTOOL-SUBJECT-EXTRACT-20260902：选区从「只有矩形」扩到任意形状，
    //   所以这里由「画矩形框」改成「按掩码逐格淡色 + 沿掩码边界描边」。
    //   颜色用青色系，与碎色高亮的红、区间描边的白区分开（三者可能同时出现）。
    if (S.edit.on) {
      // 拖拽中的临时预览
      if (S.edit.dragging && S.edit.dragStart && S.edit.dragCurrent) {
        if (S.edit.lassoPath && S.edit.lassoPath.length) {
          // 套索：把轨迹连成线，实时看得见画到哪
          ctx.save();
          ctx.strokeStyle = 'rgba(0,0,0,0.8)'; ctx.lineWidth = 3;
          ctx.beginPath();
          S.edit.lassoPath.forEach(function (p, i) {
            var x = p.c * cell + cell / 2, y = p.r * cell + cell / 2;
            if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
          });
          ctx.stroke();
          ctx.strokeStyle = '#3fb6c4'; ctx.lineWidth = 1.5;
          ctx.stroke();
          ctx.restore();
        } else {
          var dr = normalizeRect(S.edit.dragStart, S.edit.dragCurrent);
          drawSelectionRect(ctx, dr, cell, true);
        }
      } else if (S.edit.mask) {
        drawMaskOverlay(ctx, S.edit.mask, cell);
      }
    }
  }

  /**
   * 按掩码画选区：逐格淡青色着色 + 沿掩码外边界描边。
   * 逐格着色是必要的 —— 不规则选区光靠描边，用户很难分清哪些格在里面
   * （尤其是同色块选出来的锯齿形状）。着色用低透明度，不遮住底下的颜色 id。
   */
  function drawMaskOverlay(ctx, mask, cell) {
    ctx.save();
    ctx.fillStyle = 'rgba(63,182,196,0.28)';
    for (var i = 0; i < mask.bits.length; i++) {
      if (!mask.bits[i]) continue;
      var r = Math.floor(i / mask.cols), c = i % mask.cols;
      ctx.fillRect(c * cell, r * cell, cell, cell);
    }
    // 描边：只在「选中 ↔ 未选中/越界」的交界处画线，所以不会盖住像素。
    // 复用 core 的 outlineSegments，与「进度区间描边」同一套几何口径。
    if (!$('optShowMaskOutline') || $('optShowMaskOutline').checked) {
      var segs = C.outlineSegments(C.maskToIndices(mask), mask.rows, mask.cols);
      ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,0.85)';
      strokeSegs(ctx, segs, cell);
      ctx.lineWidth = 1.5; ctx.strokeStyle = '#3fb6c4';
      strokeSegs(ctx, segs, cell);
    }
    ctx.restore();
  }

  /**
   * 画 outlineSegments 的线段。
   * ⚠ 它返回的是**数组** `[x1,y1,x2,y2]`（格线坐标，单位=格），不是 {x1,y1,…} 对象 ——
   * 见 core.js 里 `segs.push([c, r, c + 1, r])`。按对象取字段会得到 undefined、整条描边不显示。
   */
  function strokeSegs(ctx, segs, cell) {
    ctx.beginPath();
    for (var i = 0; i < segs.length; i++) {
      var s = segs[i];
      ctx.moveTo(s[0] * cell, s[1] * cell);
      ctx.lineTo(s[2] * cell, s[3] * cell);
    }
    ctx.stroke();
  }

  /** 画一个矩形选区边框：dashed=true 表示拖拽中的临时预览（虚线），否则是已确定选区（实线）。 */
  function drawSelectionRect(ctx, rect, cell, dashed) {
    var x = rect.c0 * cell, y = rect.r0 * cell;
    var w = (rect.c1 - rect.c0 + 1) * cell, h = (rect.r1 - rect.r0 + 1) * cell;
    ctx.save();
    ctx.setLineDash(dashed ? [5, 3] : []);
    ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(0,0,0,0.85)';
    ctx.strokeRect(x + 1, y + 1, w - 2, h - 2);
    ctx.strokeStyle = '#ffffff';
    ctx.strokeRect(x + 1, y + 1, w - 2, h - 2);
    ctx.restore();
  }

  function groups(pixels, rows, cols) {
    return $('optComp').checked ? C.connectedComponents(pixels, rows, cols) : [pixels];
  }

  /** 逐组描边：先画深色底线再画亮色，保证在任何像素颜色上都看得见；线画在格线上，不遮盖像素。 */
  function strokeGroups(ctx, gs, rows, cols, cell, color, width, dash) {
    for (var g = 0; g < gs.length; g++) {
      var segs = C.outlineSegments(gs[g], rows, cols);
      for (var pass = 0; pass < 2; pass++) {
        ctx.beginPath();
        ctx.setLineDash(pass === 0 ? [] : (dash || []));
        ctx.lineWidth = pass === 0 ? width + 1.6 : width;
        ctx.strokeStyle = pass === 0 ? 'rgba(0,0,0,0.8)' : color;
        for (var i = 0; i < segs.length; i++) {
          var s = segs[i];
          ctx.moveTo(s[0] * cell, s[1] * cell);
          ctx.lineTo(s[2] * cell, s[3] * cell);
        }
        ctx.stroke();
      }
    }
    ctx.setLineDash([]);
  }

  // ==================== 悬停读数 ====================
  function onHover(ev) {
    var it = viewItem();
    if (!it || !it.blocks) return;
    var cv = $('cv'), rect = cv.getBoundingClientRect();
    var cell = parseInt($('cellSize').value, 10) || 11;
    var c = Math.floor((ev.clientX - rect.left) / cell), r = Math.floor((ev.clientY - rect.top) / cell);
    var rows = it.blocks.length, cols = it.blocks[0].length;
    if (r < 0 || c < 0 || r >= rows || c >= cols) return;
    var id = it.blocks[r][c], idx = r * cols + c;
    var txt = '行 ' + r + ' 列 ' + c + '　' + colorLabel(id);
    var st = it.pxStep && it.pxStep[idx];
    if (st) {
      txt += '　消除于第 ' + st.step + ' 步（该步结束完成 ' + st.done + ' 盒' +
        (it.tl ? '，进度 ' + (st.done / it.tl.totalBoxes * 100).toFixed(2) + '%' : '') + '）';
    } else if (it.tl) {
      txt += '　本路线未记录该像素的消除步（请检查尺寸口径）';
    }
    if (it.interval) {
      txt += '　' + (it.interval.diffPixels.indexOf(idx) >= 0 ? '✅ 在当前区间内' : '不在当前区间');
    }
    $('readout').textContent = txt;
  }

  // ==================== 导出 ====================
  function download(name, blob) {
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }
  function exportPng() {
    var it = cur();
    if (!it || !it.blocks) return;
    $('cv').toBlob(function (b) { download(it.key + '_区间高亮.png', b); });
  }
  function exportJson() {
    var it = cur();
    if (!it || !it.interval) { log('请先定位区域'); return; }
    var iv = it.interval, tl = it.tl;
    var out = {
      工具: '蚂蚁拿块关卡图修改工具 · 阶段一',
      关卡: it.key,
      数据定性: '基于正式关卡 JSON 重新求解/回放的标准复核路线，不声称还原生产时未保存的原始路线',
      冰块耐久: C.ICE_DURABILITY,
      进度口径: '已完成盒数 ÷ 总盒数',
      路线来源: tl.source, 命中遍: tl.pass, 是否通关: tl.completed,
      求解步数: tl.steps_count, 总盒数: tl.totalBoxes, 总像素: tl.totalPixels,
      目标图尺寸: { 行: tl.rows, 列: tl.cols },
      像素编码: '扁平下标 = 行 * ' + tl.cols + ' + 列',
      用户要求区间: iv.requested, 实际采用区间: iv.snapped,
      对应完成盒数: iv.doneBoxes, 对应步序号: iv.stepIndex,
      状态A像素数: iv.stateAPixelCount, 状态B像素数: iv.stateBPixelCount,
      区间区域像素数: iv.diffPixelCount,
      连通块数: iv.comps.length,
      连通块: iv.comps.map(function (comp) { return { 像素数: comp.length, 像素: comp }; }),
      区间区域像素: iv.diffPixels,
      时间线自检: it.verify,
      多路线: it.merged ? {
        路线数: it.merged.routeCount,
        稳定区域像素数: it.merged.stable.length,
        高频区域像素数: it.merged.frequent.length,
        浮动区域像素数: it.merged.floating.length,
        稳定区域像素: it.merged.stable,
        高频区域像素: it.merged.frequent,
        浮动区域像素: it.merged.floating,
        各路线: it.routes.routes.map(function (rt, i) {
          return {
            遍次: rt.tag, 模式: rt.mode, 噪声: rt.noise, 种子: rt.seed, 步数: rt.steps,
            实际区间: it.routes.intervals[i].snapped,
            完成盒数: it.routes.intervals[i].doneBoxes,
            区域像素数: it.routes.intervals[i].diffPixelCount
          };
        })
      } : null
    };
    download(it.key + '_区间定位.json', new Blob([JSON.stringify(out, null, 1)], { type: 'application/json' }));
    log('已导出区间定位 JSON');
  }

  // ==================== 棋盘区 + 暂存区对比 ====================
  // 复用 core.js 的 boardAtStep(tl, idx) 取某一步结束时的 {cells, frozen, buffer, bufferLimit} 快照。
  // 渲染思路参考正式 bin/js/app.js 的 renderCell/renderBufferSlots（取色只认 AntSolver.getColorCSS/getColorName，
  // 冰用 thaw/durability，锁链用组号描边），但重新实现为本工具自己的小函数，不复制其 UI 代码。

  /**
   * 刷新棋盘区 + 暂存区面板。不再强制要求先「定位区域」：
   *   - 有 tl（求解路线）+ 有 interval（已定位区间）→ 展示状态A（区间下限）/ 状态B（区间上限）
   *   - 有 tl 但还没定位区间 → 展示开局 / 末局（求解完成时的最终棋盘+暂存），先让用户看到棋盘区不是空的
   *   - 还没有 tl（没求解/没导入求解数据）→ 提示需要先有一条求解路线
   *   - tl 存在但没有棋盘快照（多路线复核产生的路线不带快照）→ 提示改用标准路线
   * 演示播放时（S.demo.idx>0）不覆盖，交给 demoRenderAtIdx 接管左列显示"当前帧"。
   */
  function refreshBoardPanel() {
    var it = viewItem();
    var show = $('optBoard').checked;
    var wrap = $('boardCompareWrap');
    if (!show) { wrap.classList.add('hidden'); wrap.innerHTML = ''; return; }
    if (S.demo.timer) return;   // 演示播放中，由 demoRenderAtIdx 接管，不要在这里抢着刷新
    wrap.classList.remove('hidden');

    if (!it || !it.tl) {
      wrap.innerHTML = '<div class="muted">先在「2. 求解路线」求解或导入求解数据，这里会显示棋盘区与暂存区。</div>';
      return;
    }
    if (!it.tl.initialBoard) {
      wrap.innerHTML = '<div class="muted">当前路线没有棋盘快照（多路线复核产生的路线不带快照），请用「2. 求解路线」的标准路线，或重新「定位区域」。</div>';
      return;
    }

    var loIdx, hiIdx, headA, headB;
    if (it.interval) {
      loIdx = it.interval.stepIndex.lo; hiIdx = it.interval.stepIndex.hi;
      headA = '状态A（区间下限 ' + it.interval.snapped.lo + '%）';
      headB = '状态B（区间上限 ' + it.interval.snapped.hi + '%）';
    } else {
      loIdx = 0; hiIdx = it.tl.steps.length;
      headA = '开局（第 0 步）'; headB = '末局（第 ' + hiIdx + ' 步，' + (it.tl.completed ? '通关' : '未通关') + '）';
    }
    buildBoardPanel(wrap, headA, headB);
    var boardA = C.boardAtStep(it.tl, loIdx);
    var boardB = C.boardAtStep(it.tl, hiIdx);
    drawBoardInto($('cvBoardA'), boardA);
    drawBoardInto($('cvBoardB'), boardB);
    drawBufferInto($('bufA'), boardA);
    drawBufferInto($('bufB'), boardB);
  }

  /** 搭建左右两列骨架（每次调用都会整段重建，标题按传入的文案覆盖）。 */
  function buildBoardPanel(wrap, headA, headB) {
    wrap.innerHTML =
      '<div class="boardCol"><div class="boardColHead">' + headA + '</div>' +
      '<canvas id="cvBoardA"></canvas><div class="bufferRow" id="bufA"></div></div>' +
      '<div class="boardCol"><div class="boardColHead">' + headB + '</div>' +
      '<canvas id="cvBoardB"></canvas><div class="bufferRow" id="bufB"></div></div>';
  }

  /** 单格渲染：与正式 bin/js/app.js renderCell 思路一致（黑块/管道/冰/锁链/问号图标 + 盒色+数字），画到 canvas 而非 DOM。 */
  function drawBoardInto(cv, board) {
    if (!board) return;
    var rows = board.boardRows, cols = board.boardCols;
    var cell = Math.max(10, Math.min(34, Math.floor(320 / Math.max(1, cols))));
    cv.width = cols * cell + 1; cv.height = rows * cell + 1;
    var ctx = cv.getContext('2d');
    ctx.fillStyle = '#0f1216'; ctx.fillRect(0, 0, cv.width, cv.height);
    ctx.font = Math.max(9, Math.floor(cell * 0.34)) + 'px Menlo, monospace';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        var cellData = board.cells[r][c];
        var x = c * cell, y = r * cell;
        if (!cellData) { continue; }
        if (cellData.t === 'black') {
          ctx.fillStyle = '#2a2f38'; ctx.fillRect(x, y, cell, cell);
          ctx.fillStyle = '#ff8080'; ctx.fillText('✕', x + cell / 2, y + cell / 2);
        } else if (cellData.t === 'pipe') {
          ctx.fillStyle = '#20262f'; ctx.fillRect(x, y, cell, cell);
          var arrow = { 11: '▲', 12: '▶', 13: '▼', 14: '◀' }[cellData.dir] || '▼';
          var remain = (cellData.queue ? cellData.queue.length : 0) - (cellData.next || 0);
          ctx.fillStyle = '#9fd0ff';
          ctx.fillText(arrow + remain, x + cell / 2, y + cell / 2);
        } else if (cellData.t === 'box') {
          ctx.fillStyle = window.AntSolver.getColorCSS(cellData.color);
          ctx.fillRect(x, y, cell, cell);
          ctx.fillStyle = textColorFor(cellData.color);
          ctx.fillText(String(cellData.count), x + cell / 2, y + cell / 2);
          if (cellData.ice > 0) {
            var f = board.frozen[r + ',' + c];
            var txt = f ? '❄' + Math.max(0, f.thaw) + '/' + f.durability : '❄' + cellData.ice;
            ctx.fillStyle = '#bfe9ff'; ctx.font = Math.max(8, Math.floor(cell * 0.26)) + 'px Menlo, monospace';
            ctx.fillText(txt, x + cell / 2, y + cell * 0.82);
            ctx.font = Math.max(9, Math.floor(cell * 0.34)) + 'px Menlo, monospace';
          }
          if (cellData.chain > 0) {
            ctx.strokeStyle = '#ffcc00'; ctx.lineWidth = 2;
            ctx.strokeRect(x + 1.5, y + 1.5, cell - 3, cell - 3);
          }
        }
      }
    }
    ctx.strokeStyle = 'rgba(255,255,255,0.06)'; ctx.lineWidth = 1;
    ctx.beginPath();
    for (var gx = 0; gx <= cols; gx++) { ctx.moveTo(gx * cell + .5, 0); ctx.lineTo(gx * cell + .5, rows * cell); }
    for (var gy = 0; gy <= rows; gy++) { ctx.moveTo(0, gy * cell + .5); ctx.lineTo(cols * cell, gy * cell + .5); }
    ctx.stroke();
  }

  function textColorFor(colorId) {
    var hex = window.AntSolver.getColorCSS(colorId);
    var m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
    if (!m) return '#fff';
    var n = parseInt(m[1], 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    return (0.299 * r + 0.587 * g + 0.114 * b) < 140 ? '#fff' : '#000';
  }

  /** 暂存槛位渲染：用 core.js 的 bufferSlotsArray 把稀疏 buffer 铺成定长数组，逐槛画一个色块。 */
  function drawBufferInto(el, board) {
    if (!board) { el.innerHTML = ''; return; }
    var arr = C.bufferSlotsArray(board.buffer, board.bufferLimit);
    var h = '';
    for (var i = 0; i < arr.length; i++) {
      var b = arr[i];
      if (!b) { h += '<div class="bufSlot empty">槛' + i + '</div>'; continue; }
      var cls = 'bufSlot' + (b.link ? ' linked' : '');
      h += '<div class="' + cls + '" style="background:' + window.AntSolver.getColorCSS(b.color) +
        ';color:' + textColorFor(b.color) + '" title="槛位 ' + i + (b.link ? '，锁链组 ' + b.link : '') + '">' +
        b.progress + '/' + b.need + '</div>';
    }
    el.innerHTML = h;
  }

  // ==================== 暂存压力图 ====================
  // 单关：横轴进度、纵轴暂存量，标暂存上限/峰值/均值/用户区间/卡点。
  // 叠加对比：重构成功后同一张图画两条曲线（原关卡 vs 重构后关卡），进度都按各自总盒数换算成百分比对齐。

  var PRESSURE_COLOR_BEFORE = '#e6d2ba';
  var PRESSURE_COLOR_AFTER = '#ffb066';
  // 玩家轨迹用一个明显不同的色，避免和全知的两条线混淆（需求 §一.5）。
  var PRESSURE_COLOR_PLAYER = '#7fd1ff';

  /**
   * 取当前关「真实求解结果」的压力样本：优先取现场求解结果（it.liveSolve.pressureSamples），
   * 其次取导入求解数据里的真实样本（it.solve.pressureSamples——用导入 pickOrder 重放出时间线时
   * it.solve 本身不会被清空，见 ensureTimeline）。两者都没有时返回 null，界面须如实提示
   * 「正式压力审核暂无数据」，不得用点击时间线反推伪造（需求07.30 §三.2 明确禁止）。
   */
  function officialSamplesOf(it) {
    if (it.liveSolve && it.liveSolve.pressureSamples && it.liveSolve.pressureSamples.length) return it.liveSolve.pressureSamples;
    if (it.solve && it.solve.pressureSamples && it.solve.pressureSamples.length) return it.solve.pressureSamples;
    return null;
  }

  // 压力图当前查看的是哪一套轨迹（需求 08.03 §一：全知与玩家两套各自真实的数据，切换查看）。
  // 'omni' = 全知求解轨迹；'player' = 玩家模拟轨迹。
  S.pressureTrack = 'omni';

  function refreshPressureChart() {
    if (S.pressureTrack === 'player') { refreshPressureChartPlayer(); return; }
    refreshPressureChartOmni();
  }

  /** 全知轨迹：沿用原有逻辑与口径，未改动（需求 §一.3 要求不改全知求解与正式压力审核口径）。 */
  function refreshPressureChartOmni() {
    var it = cur();
    var cv = $('cvPressure');
    $('playerSeedRow').style.display = 'none';
    if (!it || !it.tl) { drawPressureEmpty(cv, '先求解或导入求解数据后显示暂存压力曲线。'); $('pressureTrackInfo').innerHTML = ''; $('pressureInfo').innerHTML = ''; $('pressureCompareTable').innerHTML = ''; return; }
    var curveBefore = it.pressureCurve ||
      (it.pressureCurve = C.pressureCurveFromTl(it.tl, { officialSamples: officialSamplesOf(it) }));
    var overlay = $('optPressureOverlay').checked && it.reconResult && it.reconResult.ok;
    var curveAfter = null;
    if (overlay) {
      var rr = it.reconResult;
      if (!rr.tl) rr.tl = C.reconstructToTimeline(rr);
      if (rr.tl) curveAfter = rr.pressureCurve ||
        (rr.pressureCurve = C.pressureCurveFromTl(rr.tl, { officialAuditPrecomputed: rr.audit || null }));
    }
    drawPressureChart(cv, curveBefore, curveAfter, it.interval, {
      track: 'omni', xLabel: '完成进度',
      legend: curveAfter ? [['修改前', PRESSURE_COLOR_BEFORE], ['重构后', PRESSURE_COLOR_AFTER]] : [['全知（修改前）', PRESSURE_COLOR_BEFORE]]
    });
    renderPressureTrackInfo({
      track: 'omni', curve: curveBefore,
      note: curveAfter ? '两条曲线都是全知求解轨迹，区别是修改前与重构后，不是全知与玩家。' : ''
    });
    renderPressureInfo(curveBefore, curveAfter);
  }

  /**
   * 玩家轨迹：来自正式玩家模拟真实操作过程中每一拍的暂存占用，与全知曲线是两套数据，互不代替。
   * 没有有效玩家操作时显示「无有效玩家轨迹」；玩家验证接口异常时显示接口异常——
   * 两种情况都不画曲线、也不拿全知数据补图（需求 §一.4 最后两条）。
   */
  function refreshPressureChartPlayer() {
    var it = cur();
    var cv = $('cvPressure');
    if (!it) { drawPressureEmpty(cv, '先选择一关。'); $('pressureTrackInfo').innerHTML = ''; return; }
    var useRecon = $('optPlayerSource').checked;
    var src = playerTrackSourceOf(it, useRecon);
    $('playerSeedRow').style.display = '';
    if (!src.ok) {
      drawPressureEmpty(cv, src.message);
      $('pressureTrackInfo').innerHTML = kvTable([[src.bad ? '<span class="tag bad">' + src.title + '</span>' : '<span class="tag warn">' + src.title + '</span>', src.message]]);
      $('pressureInfo').innerHTML = ''; $('pressureCompareTable').innerHTML = '';
      renderPlayerSeedOptions(null);
      return;
    }
    renderPlayerSeedOptions(src.multi);
    var idx = Math.max(0, Math.min(src.multi.rounds.length - 1, parseInt($('selPlayerSeed').value, 10) || 0));
    var round = src.multi.rounds[idx];
    var curve = C.playerPressureCurve(round);
    if (!curve.valid) {
      var why = curve.reason === 'noPicks' ? '这一轮玩家一次球都没取到' :
        curve.reason === 'noTimeline' ? '这一轮没有记录到任何暂存变化' :
          curve.reason === 'roundError' ? '这一轮模拟本身报错' : '这一轮没有可用轨迹';
      drawPressureEmpty(cv, '无有效玩家轨迹：' + why + '。');
      $('pressureTrackInfo').innerHTML = kvTable([
        ['<span class="tag warn">无有效玩家轨迹</span>', why + '。本图不会用全知数据代替，也不会画成一条 0 压力曲线。'],
        ['当前查看', '玩家轨迹　种子 ' + round.seed + '　' + src.label]
      ]);
      $('pressureInfo').innerHTML = ''; $('pressureCompareTable').innerHTML = '';
      return;
    }
    drawPressureChart(cv, curve, null, null, {
      track: 'player', xLabel: '操作步数（共 ' + curve.steps + ' 步）',
      xTicksAsSteps: curve.steps,
      legend: [['玩家（种子 ' + curve.seed + '）', PRESSURE_COLOR_PLAYER]],
      color: PRESSURE_COLOR_PLAYER
    });
    renderPressureTrackInfo({ track: 'player', curve: curve, source: src.label });
    renderPressureInfo(curve, null);
    $('pressureCompareTable').innerHTML = '';
  }

  /**
   * 取玩家多轮结果：重构后关卡用重构时已经跑好的那份；原关卡按需现算一次并缓存。
   * 两边都走 core 的同一套多轮函数与同一张种子表，不另写第二套模拟。
   */
  function playerTrackSourceOf(it, useRecon) {
    if (useRecon) {
      var rr = it.reconResult;
      if (!rr || !rr.ok) {
        return { ok: false, title: '还没有重构后关卡', bad: false,
          message: '要看重构后关卡的玩家轨迹，请先点「重新生成关卡」并成功一次；或取消勾选改看原关卡。' };
      }
      if (rr.playerHealth && !rr.playerHealth.ok) {
        return { ok: false, title: '玩家验证接口异常', bad: true,
          message: rr.playerHealth.detail + '　本次玩家数值一律不可用，不会画成 0 压力曲线，也不会用全知数据代替。' };
      }
      if (!rr.playerMulti || !rr.playerMulti.rounds || !rr.playerMulti.rounds.length) {
        return { ok: false, title: '无有效玩家轨迹', bad: false, message: '重构结果里没有多轮玩家数据。' };
      }
      return { ok: true, multi: rr.playerMulti, label: '重构后关卡' };
    }
    if (!it.level) {
      return { ok: false, title: '缺少关卡本体', bad: false,
        message: '原关卡的玩家轨迹需要关卡本体 JSON；本关只导入了目标图。' };
    }
    if (it._playerMulti === undefined) {
      busy(true); overlay(true, '正在跑原关卡的多轮玩家模拟…');
      var res = null;
      try { res = C.playerMultiFromLevelFile(it.level, {}); } catch (e) { res = null; }
      busy(false); overlay(false);
      it._playerMulti = res && res.multi ? res.multi : null;
      it._playerMultiHealth = res && res.health ? res.health : null;
      if (it._playerMulti) {
        log('原关卡多轮玩家模拟完成：' + it._playerMulti.roundCount + ' 轮，通关率 ' +
          (it._playerMulti.successRate * 100).toFixed(0) + '%。');
      }
    }
    if (it._playerMultiHealth && !it._playerMultiHealth.ok) {
      return { ok: false, title: '玩家验证接口异常', bad: true,
        message: it._playerMultiHealth.detail + '　本次玩家数值一律不可用，不会画成 0 压力曲线，也不会用全知数据代替。' };
    }
    if (!it._playerMulti || !it._playerMulti.rounds.length) {
      return { ok: false, title: '无有效玩家轨迹', bad: false, message: '原关卡没有跑出可用的玩家轨迹。' };
    }
    return { ok: true, multi: it._playerMulti, label: '原关卡' };
  }

  /** 种子下拉：逐轮列出种子与该轮结果，便于用户挑一轮看（需求 §一.4「可以选择具体轮次查看」）。 */
  function renderPlayerSeedOptions(multi) {
    var sel = $('selPlayerSeed');
    if (!sel) return;
    if (!multi || !multi.rounds || !multi.rounds.length) { sel.innerHTML = '<option value="0">（无）</option>'; return; }
    var keep = sel.value;
    sel.innerHTML = multi.rounds.map(function (x, i) {
      var tag = x.error ? '本轮异常' : ((x.won ? '通关' : '未通关') + '，峰值 ' + x.bufferPeak);
      return '<option value="' + i + '">种子 ' + x.seed + '（' + tag + '）</option>';
    }).join('');
    if (keep !== '' && +keep < multi.rounds.length) sel.value = keep;
  }

  /** 图上方的口径说明：当前看的是哪一套轨迹、种子、坐标轴含义、暂存上限、峰值。 */
  function renderPressureTrackInfo(o) {
    var box = $('pressureTrackInfo');
    if (!box) return;
    var c = o.curve;
    var rows = [];
    if (o.track === 'player') {
      rows.push(['当前查看', '<span class="tag ok">玩家轨迹</span>　来自正式玩家模拟的真实操作过程（' + o.source + '）']);
      rows.push(['玩家随机种子', String(c.seed)]);
      rows.push(['本轮结果', (c.won ? '通关' : '未通关') + '　取球 ' + c.picks + ' 次　复活 ' +
        c.revivesUsed + '/' + c.reviveCap + '　完成盒 ' + c.completedBoxes + '/' + c.totalBoxes]);
      rows.push(['坐标轴', '横轴：操作步数（共 ' + c.steps + ' 步）　纵轴：暂存数量']);
    } else {
      rows.push(['当前查看', '<span class="tag ok">全知轨迹</span>　来自正式全知求解的消除顺序']);
      rows.push(['坐标轴', '横轴：完成进度 0%–100%　纵轴：暂存数量']);
    }
    rows.push(['暂存上限', String(c.bufferLimit) + '（图上虚线）']);
    rows.push(['暂存峰值', String(c.peak) + '　均值 ' + c.avg]);
    if (o.note) rows.push(['提示', o.note]);
    box.innerHTML = kvTable(rows);
  }

  // ==================== 可悬浮面板（用户 2026-08-03 微调第 4、5 项） ====================
  // 「悬浮」按钮把面板从原位脱出来变成可拖动的浮层，拖标题栏移动，再点一次收回原位。
  // 只改这个面板自己的定位，不动页面其它布局，也不影响目标图的绘制与坐标换算。
  // FLOAT_STATE：id → { left, top, width, height } 记住上次拖到哪、拉成多大，收回再悬浮时回到同一状态
  var FLOAT_STATE = {};
  var FLOAT_MIN_W = 180, FLOAT_MIN_H = 90;

  function toggleFloat(id) {
    var el = $(id);
    if (!el) return;
    var on = !el.classList.contains('floating');
    var btn = el.querySelector('.floatToggle');
    if (on) {
      var st = FLOAT_STATE[id];
      var r = el.getBoundingClientRect();
      if (!st) {
        st = FLOAT_STATE[id] = {
          left: Math.max(8, r.left), top: Math.max(8, r.top),
          width: Math.max(FLOAT_MIN_W, Math.round(r.width)), height: 0   // height=0 表示高度跟内容走
        };
      }
      el.classList.add('floating');
      el.style.left = st.left + 'px';
      el.style.top = st.top + 'px';
      el.style.width = st.width + 'px';
      el.style.height = st.height ? st.height + 'px' : '';
      if (btn) btn.textContent = '收回原位';
      log('「' + floatTitleOf(el) + '」已变成悬浮框：拖标题栏移动，拖右边缘/下边缘/右下角可以放大缩小；' +
        '再点「收回原位」放回目标图右侧。');
    } else {
      el.classList.remove('floating');
      el.style.left = ''; el.style.top = ''; el.style.width = ''; el.style.height = '';
      if (btn) btn.textContent = '悬浮';
      log('「' + floatTitleOf(el) + '」已收回原位。');
    }
  }

  /** 给面板补上三个拉伸手柄（右边缘 / 下边缘 / 右下角）。只在悬浮态下由 CSS 显示。 */
  function ensureResizeHandles(el) {
    if (el.querySelector('.rzBR')) return;
    ['rzR', 'rzB', 'rzBR'].forEach(function (cls) {
      var h = document.createElement('div');
      h.className = 'rzHandle ' + cls;
      h.setAttribute('data-rz', cls);
      el.appendChild(h);
    });
  }

  function floatTitleOf(el) {
    var t = el.querySelector('.floatTitle');
    return t ? t.textContent.trim() : '面板';
  }

  /**
   * 给所有带「悬浮」按钮的面板绑定：切换悬浮、拖标题栏移动、拖边缘放大缩小。
   * 移动与拉伸都只在悬浮态下生效；非悬浮态下面板在目标图右侧那一列里按列宽走，不允许乱拉。
   */
  /* ==================== 界面偏好：纯美术编辑模式 + 卡片折叠 ====================
   * 任务 ANT-ARTTOOL-EDGE-TRIM-20260915 需求④。
   *
   * 两个**独立维度**，刻意不合并：
   *   - 纯美术编辑模式：决定「哪些卡片与本次工作无关」，整类隐藏；
   *   - 折叠：决定「这张卡片我现在想不想看它的内容」，用户逐张的意图。
   * 合并会出问题：退出纯美术模式时若把折叠状态也一并重置，用户手动折起来的卡片会莫名展开；
   * 反之若用折叠来实现纯美术模式，用户退出模式后还得逐张展开 7 张卡。
   * 所以隐藏走 CSS 的 body.artOnly、折叠走各卡片自己的 .collapsed，互不干扰。
   */
  function loadUiPrefs() {
    var p = { artOnly: false, collapsed: {} };
    try {
      var raw = localStorage.getItem(UI_PREF_STORAGE_KEY);
      if (raw) {
        var o = JSON.parse(raw) || {};
        p.artOnly = !!o.artOnly;
        if (o.collapsed && typeof o.collapsed === 'object') p.collapsed = o.collapsed;
      }
    } catch (e) {
      // 界面偏好坏掉不该拦住工具启动，用默认值继续，但要说出来
      log('界面偏好读取失败（' + (e && e.message) + '），已用默认布局');
    }
    return p;
  }

  function saveUiPrefs() {
    try {
      localStorage.setItem(UI_PREF_STORAGE_KEY, JSON.stringify({
        artOnly: !!S.ui.artOnly, collapsed: S.ui.collapsed || {}
      }));
    } catch (e) { log('界面偏好保存失败（' + (e && e.message) + '），本次布局不会被记住'); }
  }

  /** 应用纯美术编辑模式。隐藏动作全部由 CSS 的 body.artOnly 完成。 */
  function applyArtOnly(quiet) {
    var on = !!S.ui.artOnly;
    document.body.classList.toggle('artOnly', on);
    var cb = $('optArtOnly');
    if (cb) cb.checked = on;
    if (!quiet) {
      if (on) {
        log('已进入纯美术编辑模式：收起了 ' + ART_ONLY_HIDDEN.length +
          ' 块与生产/求解相关的功能（求解路线、进度区间、多路线复核、自动演示、暂存压力图、' +
          '重构关卡、待导出库）以及棋盘/暂存对比区。' +
          '现在「8. 美术编辑」与「12. 主体提取」相邻。' +
          '注意：只是**收起显示**，数据和已有选区都还在，取消勾选即恢复。');
      } else {
        log('已退出纯美术编辑模式，全部功能恢复显示（各卡片的折叠状态保持不变）。');
      }
    }
    // 画布尺寸不随卡片显隐变化，但右侧列宽会变，重绘一次避免残影
    draw();
  }

  /** 折叠/展开一张卡片。 */
  function setCardCollapsed(id, on) {
    var el = $(id);
    if (!el) return;
    el.classList.toggle('collapsed', !!on);
    S.ui.collapsed = S.ui.collapsed || {};
    if (on) S.ui.collapsed[id] = 1; else delete S.ui.collapsed[id];
  }

  /** 给每张卡片的标题装上折叠开关，并恢复上次的折叠状态。 */
  function initCardCollapse() {
    COLLAPSIBLE_CARDS.forEach(function (id) {
      var card = $(id);
      if (!card) return;
      // 普通卡片点 h3；美术编辑那张的标题在 .floatHead > .floatTitle 里。
      // 不用 ':scope > h3' —— 那个选择器在部分环境（含本项目的回归 DOM 桩）拿不到，
      // 会让折叠静默失效。直接遍历直接子节点，行为确定。
      var head = null, kids = card.children || [];
      for (var i = 0; i < kids.length; i++) {
        if ((kids[i].tagName || '').toLowerCase() === 'h3') { head = kids[i]; break; }
      }
      if (!head) head = card.querySelector('.floatHead > .floatTitle') || card.querySelector('.floatTitle');
      if (!head) return;
      head.title = (head.title ? head.title + '　' : '') + '点标题可折叠/展开这张卡片';
      head.onclick = function (ev) {
        // 标题行里还有「悬浮」按钮等控件，点它们不该触发折叠
        if (ev && ev.target && ev.target !== head) {
          var tag = (ev.target.tagName || '').toLowerCase();
          if (tag === 'button' || tag === 'input' || tag === 'a' || tag === 'select') return;
        }
        setCardCollapsed(id, !card.classList.contains('collapsed'));
        saveUiPrefs();
      };
      if (S.ui.collapsed && S.ui.collapsed[id]) setCardCollapsed(id, true);
    });
  }

  /** 顶栏「折叠全部」：只要还有展开的就全折起，全折了就全展开。 */
  function toggleCollapseAll() {
    // 纯美术模式下已经隐藏的卡片不算在内 —— 否则「全部展开」会去展开看不见的卡片，
    // 用户会觉得按钮没反应（因为可见的那几张其实没变）。
    var targets = COLLAPSIBLE_CARDS.filter(function (id) {
      return $(id) && !(S.ui.artOnly && ART_ONLY_HIDDEN.indexOf(id) >= 0);
    });
    var anyOpen = targets.some(function (id) { return !$(id).classList.contains('collapsed'); });
    targets.forEach(function (id) { setCardCollapsed(id, anyOpen); });
    saveUiPrefs();
    var btn = $('btnCollapseAll');
    if (btn) btn.textContent = anyOpen ? '展开全部' : '折叠全部';
    log(anyOpen ? '已折叠全部 ' + targets.length + ' 张可见卡片（点标题可单独展开）'
      : '已展开全部 ' + targets.length + ' 张可见卡片');
    draw();
  }

  /* ==================== 13. 图纸拼接工作台 ====================
   * 任务 ANT-ARTTOOL-PIECE-COMPOSE-20260915（用户 2026-09-15 六条需求）。
   *
   * 用户口径（原话）：部件「默认是单独的主体，互不影响，**可叠加**」，但
   * 「可叠加状态只存在于编辑过程中，类似于美术先临时摆放，而不是输出后的合法图」。
   * → 所以本模块把「摆放」和「合法性」彻底分开：
   *     摆放期不拦任何叠加，只把冲突**高亮出来**；
   *     导出/入库前才做体检并**拦住**。
   *
   * 独立 canvas（#composeCv）、独立状态（S.compose），不碰 draw() 与 S.items。
   */

  var COMPOSE_CONFLICT_COLOR = '#ff5a5a';
  var COMPOSE_SELECT_COLOR = '#a98bd8';

  function cpS() { return S.compose; }
  function cpHasCanvas() { return cpS().rows > 0 && cpS().cols > 0; }
  function cpLayerById(id) {
    var L = cpS().layers, i;
    for (i = 0; i < L.length; i++) if (L[i].id === id) return L[i];
    return null;
  }
  function cpIsSelected(id) { return cpS().selected.indexOf(id) >= 0; }

  /** 进入 / 退出拼接工作台。用 body class 驱动显隐，与 artOnly 同一套机制，互不打扰。 */
  function enterCompose() {
    var C2 = cpS();
    C2.active = true;
    document.body.classList.add('composeMode');
    if (!cpHasCanvas()) {
      log('已进入拼接工作台。先在右边「13. 图纸拼接」①里设定新图规格并点「新建画布」，' +
        '再从②的部件列表把部件放上画布。');
    } else {
      log('已回到拼接工作台（画布 ' + C2.rows + '×' + C2.cols + '，' + C2.layers.length + ' 个图层还在）。');
    }
    // 首次进入时，如果图纸库里有东西就直接带进来，省一步手动点
    if (!C2.sources.length && S.pieceLib && S.pieceLib.length) {
      composeAddFromLib(true);
    }
    renderComposeAll();
  }

  function exitCompose() {
    cpS().active = false;
    document.body.classList.remove('composeMode');
    log('已退出拼接工作台。画布与图层都留着，下次点「🧩 拼接图纸」还在。');
    draw();   // 回到常规视图要重绘目标图
  }

  /** 新建画布（用户需求③：可预设新 txt 图的规格）。 */
  function composeNewCanvas() {
    var r = parseInt($('inComposeRows').value, 10);
    var c = parseInt($('inComposeCols').value, 10);
    if (!isFinite(r) || !isFinite(c) || r < 4 || c < 4) {
      log('画布规格要填 ≥4 的整数（行与列）'); return;
    }
    if (r > 200 || c > 200) { log('画布最大 200×200（再大浏览器绘制会明显变慢）'); return;
    }
    var C2 = cpS();
    var had = C2.layers.length;
    C2.rows = r; C2.cols = c;
    // 换画布不清图层：部件的偏移是画布坐标，换了尺寸后可能有部件落到界外，
    // 但那属于「需要重新摆」而不是「数据没了」—— 直接清掉会让用户白摆一遍。
    // 落到界外多少格由体检如实报出来。
    C2.lastAudit = null;
    log('画布已设为 ' + r + '×' + c + '（' + (r * c) + ' 格）。' +
      (had ? '原有 ' + had + ' 个图层保留，若有部件落到界外会在图层列表里标出来。' : ''));
    renderComposeAll();
  }

  function composeClearCanvas() {
    var C2 = cpS();
    C2.layers = []; C2.selected = []; C2.lastAudit = null;
    log('画布上的图层已全部移除（部件列表不受影响，可以重新摆）。');
    renderComposeAll();
  }

  /* ---------- 部件来源（用户需求②：可导入 txt 图和图库） ---------- */

  function composeAddSource(name, blocks, from) {
    var C2 = cpS();
    var base = safeFileName(name || '部件');
    var nm = base, k = 2;
    while (C2.sources.some(function (s) { return s.name === nm; })) { nm = base + '_' + k; k++; }
    var nz = 0;
    for (var r = 0; r < blocks.length; r++) for (var c = 0; c < blocks[r].length; c++) if (blocks[r][c] > 0) nz++;
    C2.sources.push({
      name: nm, blocks: blocks,
      rows: blocks.length, cols: blocks[0] ? blocks[0].length : 0,
      pixelCount: nz, bbox: C.bboxOfBlocks(blocks), from: from || ''
    });
    return nm;
  }

  function composeImportTxt(files) {
    if (!files || !files.length) return;
    var arr = Array.prototype.slice.call(files);
    var okN = 0, bad = [];
    var pending = arr.length;
    arr.forEach(function (f) {
      var fr = new FileReader();
      fr.onload = function () {
        try {
          var bl = C.parseTxt(String(fr.result));
          if (!bl.length || !bl[0].length) throw new Error('解析出空矩阵');
          composeAddSource(f.name.replace(/\.txt$/i, ''), bl, 'txt:' + f.name);
          okN++;
        } catch (e) {
          bad.push(f.name + '（' + (e && e.message) + '）');
        }
        if (--pending === 0) finish();
      };
      fr.onerror = function () { bad.push(f.name + '（读取失败）'); if (--pending === 0) finish(); };
      fr.readAsText(f);
    });
    function finish() {
      log('部件导入：成功 ' + okN + (bad.length ? '，失败 ' + bad.length + ' —— ' + bad.join('；') : ''));
      renderComposeAll();
    }
  }

  /** 从图纸库把部件加进来。quiet=true 用于进入拼接时的自动带入。 */
  function composeAddFromLib(quiet) {
    var lib = S.pieceLib || [];
    var pieces = lib.filter(function (p) { return p && p.type === C.ART_PIECE_TYPE && p.blocks; });
    if (!pieces.length) {
      if (!quiet) log('图纸库是空的。先去「12. 主体提取」抠几个部件存进图纸库，或用上面的「导入 TXT 图」。');
      return;
    }
    var n = 0;
    pieces.forEach(function (p) { composeAddSource(p.key, p.blocks, 'lib'); n++; });
    log('已从图纸库添加 ' + n + ' 个部件到部件列表' + (quiet ? '（进入拼接时自动带入）' : '') + '。');
    if (!quiet) renderComposeAll();
  }

  function composeClearSources() {
    cpS().sources = [];
    log('部件列表已清空（画布上已摆好的图层不受影响）。');
    renderComposeAll();
  }

  /** 把一个部件放上画布 → 成为一个图层（用户需求④）。 */
  function composePlace(srcIndex) {
    var C2 = cpS();
    if (!cpHasCanvas()) { log('先新建画布，再放部件'); return; }
    var s = C2.sources[srcIndex];
    if (!s) return;
    // 默认落点：尽量放在画布内、且不与已有图层重叠的位置；找不到就放左上角并如实说明
    var spot = composeFindSpot(s);
    C2.layers.push({
      id: C2.nextId++, name: s.name, blocks: s.blocks,
      rows: s.rows, cols: s.cols,
      offR: spot.r, offC: spot.c, locked: false, visible: true
    });
    C2.selected = [C2.layers[C2.layers.length - 1].id];
    C2.lastAudit = null;
    log('已把「' + s.name + '」放上画布，位置 行' + spot.r + ' 列' + spot.c +
      (spot.found ? '（自动找了个不重叠的空位）' : '（**没找到不重叠的空位**，先叠着放在这里，拖到合适位置即可 —— 摆放期允许叠加）'));
    renderComposeAll();
  }

  /**
   * 给新部件找一个「在画布内且不与现有图层重叠」的落点。
   * 找不到就返回 (0,0) 并标记 found=false —— 按用户口径叠着放也是允许的，
   * 所以这里不拒绝，只是把情况说清。
   */
  function composeFindSpot(s) {
    var C2 = cpS();
    var bb = s.bbox;
    if (!bb) return { r: 0, c: 0, found: true };
    // 只需要让部件的**有效内容**落在画布里，所以按 bbox 算可行的偏移范围
    var maxR = C2.rows - bb.rows - bb.r0, maxC = C2.cols - bb.cols - bb.c0;
    var step = 1;
    for (var r = -bb.r0; r <= maxR; r += step) {
      for (var c = -bb.c0; c <= maxC; c += step) {
        var probe = C2.layers.concat([{ blocks: s.blocks, offR: r, offC: c, visible: true }]);
        var cf = C.composeConflicts(probe, C2.rows, C2.cols, 1);
        if (cf.count === 0) {
          var pl = C.composeLayerPlacement({ blocks: s.blocks, offR: r, offC: c }, C2.rows, C2.cols);
          if (pl.clipped === 0) return { r: r, c: c, found: true };
        }
      }
    }
    return { r: Math.max(0, -bb.r0), c: Math.max(0, -bb.c0), found: false };
  }

  /* ---------- 绘制 ---------- */

  function composeCell() { return parseInt($('composeCellSize').value, 10) || 9; }

  /** 拼接画布绘制：底图 → 各图层 → 部件边界 → 冲突高亮 → 选中框。 */
  function drawCompose() {
    var cv = $('composeCv');
    if (!cv) return;
    var ctx = cv.getContext('2d');
    var C2 = cpS();
    if (!cpHasCanvas()) {
      cv.width = 600; cv.height = 160;
      ctx.fillStyle = '#17100a'; ctx.fillRect(0, 0, cv.width, cv.height);
      ctx.fillStyle = '#8f7963'; ctx.font = '13px sans-serif';
      ctx.fillText('还没有画布 —— 在右边「13. 图纸拼接」①设定规格并点「新建画布」', 20, 40);
      return;
    }
    var cell = composeCell(), rows = C2.rows, cols = C2.cols;
    cv.width = cols * cell + 1; cv.height = rows * cell + 1;

    // 底：空画布（用斜纹表示「空」，与主体提取里的口径一致 —— 空位不是某种颜色）
    ctx.fillStyle = '#17100a'; ctx.fillRect(0, 0, cv.width, cv.height);
    if (cell >= 4) {
      ctx.strokeStyle = 'rgba(255,255,255,0.045)'; ctx.lineWidth = 1;
      for (var d = -rows; d < cols; d += 2) {
        ctx.beginPath();
        ctx.moveTo(d * cell, 0); ctx.lineTo((d + rows) * cell, rows * cell);
        ctx.stroke();
      }
    }

    // 各图层（按层序，后画的盖前面 —— 与 composeFlatten 同一口径）
    C2.layers.forEach(function (L) {
      if (!L.visible) return;
      var bl = L.blocks;
      for (var r = 0; r < bl.length; r++) {
        for (var c = 0; c < bl[r].length; c++) {
          var v = bl[r][c];
          if (v <= 0) continue;
          var R = r + L.offR, Cc = c + L.offC;
          if (R < 0 || Cc < 0 || R >= rows || Cc >= cols) continue;
          ctx.fillStyle = window.AntSolver.getColorCSS(v);
          ctx.fillRect(Cc * cell, R * cell, cell, cell);
        }
      }
    });

    if ($('optComposeGrid').checked && cell >= 5) {
      ctx.strokeStyle = 'rgba(255,255,255,0.08)'; ctx.lineWidth = 1;
      for (var i = 0; i <= cols; i++) { ctx.beginPath(); ctx.moveTo(i * cell + .5, 0); ctx.lineTo(i * cell + .5, rows * cell); ctx.stroke(); }
      for (var j = 0; j <= rows; j++) { ctx.beginPath(); ctx.moveTo(0, j * cell + .5); ctx.lineTo(cols * cell, j * cell + .5); ctx.stroke(); }
    }

    // 各部件边界：多主体摆放时，不描边根本分不清哪块属于哪个部件
    if ($('optComposeOutline').checked) {
      C2.layers.forEach(function (L) {
        if (!L.visible) return;
        var idx = [];
        for (var r = 0; r < L.blocks.length; r++) for (var c = 0; c < L.blocks[r].length; c++) {
          if (L.blocks[r][c] <= 0) continue;
          var R = r + L.offR, Cc = c + L.offC;
          if (R < 0 || Cc < 0 || R >= rows || Cc >= cols) continue;
          idx.push(R * cols + Cc);
        }
        if (!idx.length) return;
        var segs = C.outlineSegments(idx, rows, cols);
        ctx.strokeStyle = cpIsSelected(L.id) ? COMPOSE_SELECT_COLOR : 'rgba(255,255,255,0.34)';
        ctx.lineWidth = cpIsSelected(L.id) ? 2 : 1;
        ctx.beginPath();
        segs.forEach(function (s) {
          ctx.moveTo(s[0] * cell, s[1] * cell);
          ctx.lineTo(s[2] * cell, s[3] * cell);
        });
        ctx.stroke();
      });
    }

    // 冲突高亮：摆放期不拦，但必须看得见
    if ($('optComposeConflict').checked) {
      var cf = C.composeConflicts(C2.layers, rows, cols, 4000);
      if (cf.count) {
        ctx.fillStyle = 'rgba(255,90,90,0.55)';
        cf.cells.forEach(function (x) { ctx.fillRect(x.c * cell, x.r * cell, cell, cell); });
        if (cell >= 6) {
          ctx.strokeStyle = COMPOSE_CONFLICT_COLOR; ctx.lineWidth = 1;
          cf.cells.forEach(function (x) { ctx.strokeRect(x.c * cell + .5, x.r * cell + .5, cell - 1, cell - 1); });
        }
      }
    }

    // 直线/边框的拖拽预览：落笔前先看清会画成什么样，避免反复撤销试错
    if (C2.shapeDrag) {
      var sd = C2.shapeDrag;
      var preview = [];
      if (sd.tool === 'line') {
        preview = C.lineCells(sd.from.r, sd.from.c, sd.to.r, sd.to.c, composeBrushWidth(), rows, cols);
      } else {
        try {
          preview = C.borderShape($('selComposeBorder').value,
            { r0: sd.from.r, c0: sd.from.c, r1: sd.to.r, c1: sd.to.c },
            composeBrushWidth(), rows, cols).cells;
        } catch (e) { preview = []; }
      }
      var pc = composeBrushColor();
      ctx.globalAlpha = 0.62;
      ctx.fillStyle = pc === 0 ? '#8f7963' : window.AntSolver.getColorCSS(pc);
      preview.forEach(function (x) { ctx.fillRect(x.c * cell, x.r * cell, cell, cell); });
      ctx.globalAlpha = 1;
      if (cell >= 5) {
        ctx.strokeStyle = COMPOSE_SELECT_COLOR; ctx.lineWidth = 1;
        ctx.setLineDash([3, 2]);
        var rr0 = Math.min(sd.from.r, sd.to.r), rr1 = Math.max(sd.from.r, sd.to.r);
        var cc0 = Math.min(sd.from.c, sd.to.c), cc1 = Math.max(sd.from.c, sd.to.c);
        ctx.strokeRect(cc0 * cell + .5, rr0 * cell + .5, (cc1 - cc0 + 1) * cell - 1, (rr1 - rr0 + 1) * cell - 1);
        ctx.setLineDash([]);
      }
    }

    // 选中图层的外接框（拖拽时看得见抓的是谁）
    C2.selected.forEach(function (id) {
      var L = cpLayerById(id);
      if (!L) return;
      var pl = C.composeLayerPlacement(L, rows, cols);
      if (!pl.bbox) return;
      var b = pl.bbox;
      ctx.strokeStyle = COMPOSE_SELECT_COLOR; ctx.lineWidth = 2;
      ctx.setLineDash([4, 3]);
      ctx.strokeRect(b.c0 * cell + 1, b.r0 * cell + 1, b.cols * cell - 2, b.rows * cell - 2);
      ctx.setLineDash([]);
    });
  }

  /* ---------- 面板 ---------- */

  function composeThumb(blocks, max) {
    max = max || 34;
    var rows = blocks.length, cols = blocks[0] ? blocks[0].length : 0;
    var cv = document.createElement('canvas');
    var px = Math.max(1, Math.floor(max / Math.max(rows, cols)));
    cv.width = cols * px; cv.height = rows * px;
    var ctx = cv.getContext('2d');
    ctx.fillStyle = '#17100a'; ctx.fillRect(0, 0, cv.width, cv.height);
    for (var r = 0; r < rows; r++) for (var c = 0; c < cols; c++) {
      var v = blocks[r][c];
      if (v <= 0) continue;
      ctx.fillStyle = window.AntSolver.getColorCSS(v);
      ctx.fillRect(c * px, r * px, px, px);
    }
    return cv;
  }

  function renderComposeSources() {
    var box = $('composeSourceList'), info = $('composeSourceInfo');
    if (!box) return;
    var C2 = cpS();
    info.innerHTML = C2.sources.length
      ? '<div class="kvRow"><span>可用部件</span><b>' + C2.sources.length + ' 个</b></div>'
      : '<div class="muted">还没有部件 —— 用上面的「导入 TXT 图」或「从图纸库全部添加」</div>';
    box.innerHTML = '';
    C2.sources.forEach(function (s, i) {
      var row = document.createElement('div');
      row.className = 'item';
      row.appendChild(composeThumb(s.blocks));
      var txt = document.createElement('div');
      txt.className = 'grow';
      txt.innerHTML = '<b>' + escHtml(s.name) + '</b>　' + s.rows + '×' + s.cols +
        '，' + s.pixelCount + ' 格' +
        (s.bbox ? '，占位 ' + s.bbox.rows + '×' + s.bbox.cols : '，<span style="color:#ff9a9a">空图</span>');
      row.appendChild(txt);
      var btn = document.createElement('button');
      btn.className = 'miniBtn';
      btn.textContent = '放上画布';
      btn.disabled = !cpHasCanvas() || !s.bbox;
      btn.title = !cpHasCanvas() ? '先新建画布' : (!s.bbox ? '这是一张空图，放上去没有意义' : '放到画布上成为一个新图层');
      btn.onclick = function () { composePlace(i); };
      row.appendChild(btn);
      var del = document.createElement('button');
      del.className = 'miniBtn';
      del.textContent = '移除';
      del.title = '从部件列表移除（不影响已经摆到画布上的图层）';
      del.onclick = function () { C2.sources.splice(i, 1); renderComposeAll(); };
      row.appendChild(del);
      box.appendChild(row);
    });
  }

  function renderComposeLayers() {
    var box = $('composeLayerList'), info = $('composeLayerInfo');
    if (!box) return;
    var C2 = cpS();
    if (!cpHasCanvas()) {
      info.innerHTML = '<div class="muted">还没有画布</div>';
      box.innerHTML = ''; return;
    }
    var audit = C.composeAudit(C2.layers, C2.rows, C2.cols);
    C2.lastAudit = audit;
    info.innerHTML =
      '<div class="kvRow"><span>画布</span><b>' + C2.rows + '×' + C2.cols + '</b></div>' +
      '<div class="kvRow"><span>图层</span><b>' + C2.layers.length + '</b>（可见 ' + audit.visibleLayers + '）</div>' +
      '<div class="kvRow"><span>实际非空像素</span><b>' + audit.pixelActual + '</b>' +
      '（占画布 ' + (audit.pixelActual / (C2.rows * C2.cols) * 100).toFixed(1) + '%）</div>' +
      '<div class="kvRow"><span>叠加冲突</span><b style="color:' +
      (audit.conflictCount ? '#ff9a9a' : '#9ad0a0') + '">' + audit.conflictCount + ' 格</b>' +
      (audit.conflictCount ? '（摆放期允许，导出前需清零）' : '') + '</div>' +
      (audit.clipped ? '<div class="kvRow"><span>被画布切掉</span><b style="color:#ff9a9a">' +
        audit.clipped + ' 格</b>（有部件伸出画布）</div>' : '');

    box.innerHTML = '';
    // 列表按「后画的在上面」展示，与图层直觉一致（数组末尾 = 最上层）
    for (var i = C2.layers.length - 1; i >= 0; i--) {
      (function (L, idx) {
        var pl = C.composeLayerPlacement(L, C2.rows, C2.cols);
        var badConf = audit.conflicts.perLayer[idx] || 0;
        var row = document.createElement('div');
        row.className = 'item' + (cpIsSelected(L.id) ? ' selected' : '') + (badConf ? ' conflict' : '');
        row.appendChild(composeThumb(L.blocks, 26));
        var txt = document.createElement('div');
        txt.className = 'grow';
        txt.innerHTML = '<b>' + escHtml(L.name) + '</b>　行' + L.offR + ' 列' + L.offC +
          '　' + pl.inside + ' 格' +
          (pl.clipped ? ' <span class="layerBadge bad">切掉 ' + pl.clipped + '</span>' : '') +
          (badConf ? ' <span class="layerBadge bad">冲突 ' + badConf + '</span>' : '') +
          (L.locked ? ' <span class="layerBadge locked">已固定</span>' : '') +
          (!L.visible ? ' <span class="layerBadge">已隐藏</span>' : '');
        txt.onclick = function (ev) { composeSelectLayer(L.id, ev && (ev.shiftKey || ev.metaKey)); };
        txt.style.cursor = 'pointer';
        txt.title = '点击选中（Shift/Cmd 多选，多选后可合并成一个新主体）。选中后可用方向键逐格微调位置';
        row.appendChild(txt);
        [['up', '↑', '上移一层（重叠时盖住下面的）'],
        ['down', '↓', '下移一层'],
        ['center', '居中', '把这个部件在画布上居中'],
        ['lock', L.locked ? '解固' : '固定', L.locked ? '解除固定，重新可拖' : '固定位置，防止误拖'],
        ['hide', L.visible ? '隐藏' : '显示', L.visible ? '暂时隐藏（不参与冲突检查与导出）' : '重新显示'],
        ['del', '移除', '从画布移除（部件列表里还留着）']
        ].forEach(function (spec) {
          var b = document.createElement('button');
          b.className = 'miniBtn';
          b.textContent = spec[1];
          b.title = spec[2];
          b.onclick = function (ev) { ev.stopPropagation(); composeLayerAction(L.id, spec[0]); };
          row.appendChild(b);
        });
        box.appendChild(row);
      })(C2.layers[i], i);
    }
    syncComposeButtons();
  }

  function composeSelectLayer(id, additive) {
    var C2 = cpS();
    if (additive) {
      var k = C2.selected.indexOf(id);
      if (k >= 0) C2.selected.splice(k, 1); else C2.selected.push(id);
    } else {
      C2.selected = [id];
    }
    renderComposeAll();
  }

  function syncComposeButtons() {
    var C2 = cpS();
    var a = C2.lastAudit;
    var can = cpHasCanvas() && C2.layers.length > 0 && a && a.pixelActual > 0;
    var clean = can && a.conflictCount === 0 && a.clipped === 0;
    var e1 = $('btnComposeExportTxt'), e2 = $('btnComposeToLib');
    if (e1) {
      e1.disabled = !can;
      e1.title = !can ? '先新建画布并放上部件'
        : (clean ? '导出为 TXT 目标图' : '当前有叠加冲突或部件被切掉 —— 点了会先告诉你哪里有问题');
    }
    if (e2) { e2.disabled = !can; }
    var em = $('btnComposeMerge');
    if (em) {
      em.disabled = C2.selected.length < 2;
      em.title = C2.selected.length < 2
        ? '先选中 2 个以上图层（Shift 点击多选）'
        : '把选中的 ' + C2.selected.length + ' 个图层合并成一个整体，之后不能再单独拖开';
    }
    var eu = $('btnComposeUndo');
    if (eu) {
      var un = (C2.undo || []).length;
      eu.disabled = !un;
      eu.title = un ? '撤销上一笔绘制（还可撤 ' + un + ' 步）' : '还没有绘制操作可撤销';
    }
    var el2 = $('btnComposeLayerExport');
    if (el2) {
      var one = C2.selected.length === 1 ? cpLayerById(C2.selected[0]) : null;
      el2.disabled = !one;
      el2.title = one ? '把「' + one.name + '」单独导出成 txt 模块，之后可当部件再导入'
        : '先选中恰好一个图层';
    }
    // 边框那一行只在「边框」工具下才有意义，其它工具下淡化提示
    var br = $('composeBorderRow');
    if (br) br.style.opacity = (composeTool() === 'border') ? '1' : '0.5';
    var info = $('composeCanvasInfo');
    if (info) {
      info.textContent = cpHasCanvas()
        ? (C2.rows + '×' + C2.cols + '　图层 ' + C2.layers.length +
          (a ? '　像素 ' + a.pixelActual + (a.conflictCount ? '　⚠ 冲突 ' + a.conflictCount : '') : ''))
        : '还没有画布';
    }
  }

  function renderComposeAll() {
    renderComposeSources();
    renderComposeLayers();
    renderComposeBorderParts();
    renderComposePalette();
    drawCompose();
  }

  /* ---------- 拖拽摆放（用户需求④⑤：可以随意拖拽 / 固定） ---------- */

  /** 鼠标位置 → 拼接画布的格坐标。允许越界（拖到画布外也要能继续拖），所以不夹取。 */
  function composeEventToCell(ev) {
    var cell = composeCell();
    var rect = $('composeCv').getBoundingClientRect();
    return {
      r: Math.floor((ev.clientY - rect.top) / cell),
      c: Math.floor((ev.clientX - rect.left) / cell)
    };
  }

  /**
   * 命中测试：这一格上最上面的那个图层是谁。
   * 从数组末尾往前找 —— 数组末尾是最上层，与 composeFlatten 的覆盖顺序、
   * 以及图层列表的展示顺序（末尾在最上面）保持同一套口径。
   * 只认**非 0 像素**：点在部件的空隙上等于没点到它，否则一个带大片空白的部件会
   * 把它外接矩形内的所有点击都吃掉，下面的图层再也选不中。
   */
  function composeHitLayer(r, c) {
    var L = cpS().layers;
    for (var i = L.length - 1; i >= 0; i--) {
      var la = L[i];
      if (!la.visible) continue;
      var rr = r - la.offR, cc = c - la.offC;
      if (rr < 0 || cc < 0 || rr >= la.blocks.length) continue;
      var row = la.blocks[rr];
      if (!row || cc >= row.length) continue;
      if (row[cc] > 0) return la;
    }
    return null;
  }

  function onComposeMouseDown(ev) {
    var C2 = cpS();
    if (!cpHasCanvas()) {
      // 原先这里是静默 return —— 用户在没建画布时点画布，什么反应都没有，
      // 只能自己猜是哪里不对。改成如实说清下一步。
      log('还没有画布，点不了。先在右边「13. 图纸拼接」①填好行列，点「新建画布」。');
      return;
    }
    var p = composeEventToCell(ev);

    // 绘制类工具优先接管：它们作用于「当前选中的图层」，与命中测试无关
    // （否则在空白处画不了 —— 那里没有任何图层可命中）。
    var tool = composeTool();
    if (tool !== 'move') {
      if (p.r < 0 || p.c < 0 || p.r >= C2.rows || p.c >= C2.cols) return;
      // 空白画布上直接就能画：没有可画图层时自动补一张（用户 2026-09-15 追加要求）
      var L = composeEnsureDrawTarget();
      if (!L) return;
      if (tool === 'paint') {
        C2.paintDrag = { id: L.id, last: null };
        composeStrokeTo(L, p, true);
      } else if (tool === 'line' || tool === 'border') {
        // 直线/边框都是「拖一个范围」：按下记起点，松手才落笔，中途画预览
        C2.shapeDrag = { id: L.id, tool: tool, from: p, to: p };
        drawCompose();
      } else if (tool === 'fill') {
        composeFillAt(L, p);
      }
      return;
    }

    var hit = composeHitLayer(p.r, p.c);
    if (!hit) {
      // 点空白 = 取消选择（和常见图形工具一致）
      if (C2.selected.length) { C2.selected = []; renderComposeAll(); }
      return;
    }
    // Shift/Cmd 点击 = 加减选（用户需求⑤：可加选减选不同的主体成为新主体）
    if (ev.shiftKey || ev.metaKey) { composeSelectLayer(hit.id, true); return; }
    if (!cpIsSelected(hit.id)) C2.selected = [hit.id];
    if (hit.locked) {
      log('「' + hit.name + '」已固定，拖不动。要挪它先在图层列表里点「解固」。');
      renderComposeAll();
      return;
    }
    // 记下按下时的偏移与鼠标格，拖动时用差值 —— 这样不会因为取整而抖动
    C2.drag = {
      id: hit.id, startR: p.r, startC: p.c,
      baseOff: {},                      // 支持多选一起拖
      moved: false
    };
    C2.selected.forEach(function (id) {
      var la = cpLayerById(id);
      if (la && !la.locked) C2.drag.baseOff[id] = { r: la.offR, c: la.offC };
    });
    $('composeCv').classList.add('dragging');
    renderComposeAll();
  }

  /** 是否有任何一种拖拽正在进行。事件兜底的判断条件必须用它，漏掉哪一种就会有一类操作卡住。 */
  function composeDragging() {
    var C2 = cpS();
    return !!(C2.drag || C2.paintDrag || C2.shapeDrag);
  }

  function onComposeMouseMove(ev) {
    var C2 = cpS();
    if (!cpHasCanvas()) return;

    // 兜底：鼠标按键已经松开却还处于拖拽态，说明 mouseup 丢了
    // （最常见的是在浏览器窗口外松手，document 也收不到）。
    // 不兜的话涂色会变成「跟随鼠标一直画」，用户完全无法控制。
    // ev.buttons 是位掩码，0 = 没有任何键按下；不支持该属性的环境返回 undefined，此时不做判断。
    if (composeDragging() && ev && typeof ev.buttons === 'number' && ev.buttons === 0) {
      onComposeMouseUp();
      return;
    }

    var p = composeEventToCell(ev);

    // 连续涂色：把上一格到这一格连成线，否则快速拖动会留下断点
    if (C2.paintDrag) {
      var pl = cpLayerById(C2.paintDrag.id);
      if (pl) composeStrokeTo(pl, p, false);
      composeReadoutAt(p.r, p.c);
      return;
    }
    // 直线/边框的拖拽预览
    if (C2.shapeDrag) {
      C2.shapeDrag.to = p;
      drawCompose();
      composeReadoutAt(p.r, p.c);
      return;
    }
    if (!C2.drag) { composeReadoutAt(p.r, p.c); return; }
    var dR = p.r - C2.drag.startR, dC = p.c - C2.drag.startC;
    if (dR === 0 && dC === 0) return;
    var changed = false;
    Object.keys(C2.drag.baseOff).forEach(function (id) {
      var la = cpLayerById(+id);
      if (!la) return;
      var b = C2.drag.baseOff[id];
      var nr = b.r + dR, nc = b.c + dC;
      if (la.offR !== nr || la.offC !== nc) { la.offR = nr; la.offC = nc; changed = true; }
    });
    if (changed) {
      C2.drag.moved = true;
      C2.lastAudit = null;
      drawCompose();
      composeReadoutAt(p.r, p.c);
    }
  }

  function onComposeMouseUp() {
    var C2 = cpS();
    $('composeCv').classList.remove('dragging');

    if (C2.paintDrag) {
      var n = C2.paintDrag.painted || 0;
      C2.paintDrag = null;
      if (n) log('涂色：' + n + ' 个像素');
      renderComposeAll();
      return;
    }
    if (C2.shapeDrag) {
      var sd = C2.shapeDrag;
      C2.shapeDrag = null;
      var L = cpLayerById(sd.id);
      if (!L) { renderComposeAll(); return; }
      if (sd.tool === 'line') {
        var cells = C.lineCells(sd.from.r, sd.from.c, sd.to.r, sd.to.c,
          composeBrushWidth(), C2.rows, C2.cols);
        var k = composeApplyCells(L, cells, composeBrushColor(), '画直线');
        if (k) {
          log('直线：从 行' + sd.from.r + ' 列' + sd.from.c + ' 到 行' + sd.to.r + ' 列' + sd.to.c +
            '，线宽 ' + composeBrushWidth() + ' 格，' + k + ' 个像素');
        }
      } else {
        composeMakeBorder({ r0: sd.from.r, c0: sd.from.c, r1: sd.to.r, c1: sd.to.c });
        return;      // composeMakeBorder 内部已经刷过面板
      }
      renderComposeAll();
      return;
    }

    if (!C2.drag) return;
    var moved = C2.drag.moved;
    var ids = Object.keys(C2.drag.baseOff);
    C2.drag = null;
    if (moved) {
      // 拖完才刷面板：拖动中只重绘画布，避免每帧重建两个列表（几十个图层时会明显卡）
      renderComposeAll();
      var la = ids.length === 1 ? cpLayerById(+ids[0]) : null;
      var a = cpS().lastAudit;
      log('已移动 ' + (la ? '「' + la.name + '」到 行' + la.offR + ' 列' + la.offC : ids.length + ' 个图层') +
        (a ? '。当前冲突 ' + a.conflictCount + ' 格' + (a.clipped ? '，被画布切掉 ' + a.clipped + ' 格' : '') : ''));
    }
  }

  /**
   * 手动涂色的一笔：把上一格连到这一格。
   * 必须连线而不是只涂当前格 —— 鼠标事件是离散采样的，快速拖动时相邻两次事件可能隔好几格，
   * 只涂当前格会留下一串断点。
   */
  function composeStrokeTo(L, p, first) {
    var C2 = cpS();
    var pd = C2.paintDrag;
    if (!pd) return;
    var w = composeBrushWidth();
    var cells = (first || !pd.last)
      ? C.lineCells(p.r, p.c, p.r, p.c, w, C2.rows, C2.cols)
      : C.lineCells(pd.last.r, pd.last.c, p.r, p.c, w, C2.rows, C2.cols);
    pd.last = { r: p.r, c: p.c };
    // 一笔之内只压一次撤销快照：拖一条长线应当一次撤回，而不是撤几十次
    var local = [];
    for (var i = 0; i < cells.length; i++) {
      var r = cells[i].r - L.offR, c = cells[i].c - L.offC;
      if (r < 0 || c < 0 || r >= L.blocks.length) continue;
      if (!L.blocks[r] || c >= L.blocks[r].length) continue;
      local.push({ r: r, c: c });
    }
    if (!local.length) return;
    if (!pd.pushed) { composePushUndo(L, '涂色'); pd.pushed = true; }
    var res = C.paintCells(L.blocks, local, composeBrushColor());
    if (!res.changed) return;
    L.blocks = res.blocks;
    pd.painted = (pd.painted || 0) + res.changed;
    C2.lastAudit = null;
    drawCompose();      // 拖动中只重绘画布，松手才刷面板
  }

  /** 填充：把点中的那一片同值区域换成当前颜色（用户需求⑥末段）。 */
  function composeFillAt(L, p) {
    var C2 = cpS();
    var r = p.r - L.offR, c = p.c - L.offC;
    if (r < 0 || c < 0 || r >= L.blocks.length || !L.blocks[r] || c >= L.blocks[r].length) {
      log('那一格不在「' + L.name + '」的范围内。想填整张画布上的空白，请选中一个和画布同大的图层' +
        '（「新建空白图层」建出来的就是）。');
      return;
    }
    var color = composeBrushColor();
    var res = C.fillRegion(L.blocks, r, c, color);
    if (!res.changed) {
      log('填充没有改变任何像素（点中的那一片本来就是这个颜色）');
      return;
    }
    composePushUndo(L, '填充');
    L.blocks = res.blocks;
    C2.lastAudit = null;
    var fromName = res.fromColor === 0 ? '空白' : window.AntSolver.getColorName(res.fromColor) + '(' + res.fromColor + ')';
    var toName = color === 0 ? '空白' : window.AntSolver.getColorName(color) + '(' + color + ')';
    log('填充：把「' + L.name + '」里与 行' + r + ' 列' + c + ' 相连的 ' + res.changed +
      ' 格' + fromName + ' 换成了' + toName + '。' +
      (res.fromColor === 0 ? '（若填出了预期范围，说明那片空白是连通的 —— 先把缺口封上再填）' : ''));
    renderComposeAll();
  }

  function composeReadoutAt(r, c) {
    var el = $('composeReadout');
    if (!el) return;
    var C2 = cpS();
    if (r < 0 || c < 0 || r >= C2.rows || c >= C2.cols) { el.textContent = '（在画布外）'; return; }
    var flat = C.composeFlatten(C2.layers, C2.rows, C2.cols);
    var v = flat[r][c];
    var owners = [];
    C2.layers.forEach(function (la) {
      if (!la.visible) return;
      var rr = r - la.offR, cc = c - la.offC;
      if (rr < 0 || cc < 0 || rr >= la.blocks.length) return;
      var row = la.blocks[rr];
      if (!row || cc >= row.length || row[cc] <= 0) return;
      owners.push(la.name);
    });
    el.textContent = '行 ' + r + ' 列 ' + c + '　' +
      (v > 0 ? window.AntSolver.getColorName(v) + '(' + v + ')' : '空') +
      (owners.length > 1 ? '　⚠ ' + owners.length + ' 个部件重叠在这里：' + owners.join(' / ')
        : owners.length === 1 ? '　来自「' + owners[0] + '」' : '');
  }

  /* ---------- 图层操作（用户需求⑤：固定 / 单个图层编辑 / 层序） ---------- */

  function composeLayerAction(id, act) {
    var C2 = cpS();
    var i = C2.layers.findIndex(function (x) { return x.id === id; });
    if (i < 0) return;
    var L = C2.layers[i];
    switch (act) {
      case 'lock':
        L.locked = !L.locked;
        log('「' + L.name + '」' + (L.locked ? '已固定（拖不动，防止误碰）' : '已解固'));
        break;
      case 'hide':
        L.visible = !L.visible;
        log('「' + L.name + '」' + (L.visible ? '已显示' : '已隐藏（不参与冲突检查也不会出现在导出结果里）'));
        break;
      case 'del':
        C2.layers.splice(i, 1);
        C2.selected = C2.selected.filter(function (x) { return x !== id; });
        log('已从画布移除「' + L.name + '」（部件列表里还在，可以重新放）');
        break;
      case 'up':
        if (i < C2.layers.length - 1) {
          C2.layers[i] = C2.layers[i + 1]; C2.layers[i + 1] = L;
          log('「' + L.name + '」上移一层（越上层越后画，重叠时盖住下面的）');
        } else { log('「' + L.name + '」已经在最上层'); }
        break;
      case 'down':
        if (i > 0) {
          C2.layers[i] = C2.layers[i - 1]; C2.layers[i - 1] = L;
          log('「' + L.name + '」下移一层');
        } else { log('「' + L.name + '」已经在最下层'); }
        break;
      case 'center': {
        var pl = C.composeLayerPlacement(L, C2.rows, C2.cols);
        var bb = C.bboxOfBlocks(L.blocks);
        if (!bb) { log('这个图层是空图，没法居中'); break; }
        L.offR = Math.round((C2.rows - bb.rows) / 2) - bb.r0;
        L.offC = Math.round((C2.cols - bb.cols) / 2) - bb.c0;
        log('「' + L.name + '」已居中到 行' + L.offR + ' 列' + L.offC);
        break;
      }
    }
    C2.lastAudit = null;
    renderComposeAll();
  }

  /** 方向键微调选中图层（像素级定位靠鼠标拖很难精确，这一步是必需的）。 */
  function composeNudge(dR, dC) {
    var C2 = cpS();
    if (!C2.active || !cpHasCanvas() || !C2.selected.length) return false;
    var moved = 0;
    C2.selected.forEach(function (id) {
      var L = cpLayerById(id);
      if (!L || L.locked) return;
      L.offR += dR; L.offC += dC; moved++;
    });
    if (!moved) { log('选中的图层都被固定了，先解固再挪'); return true; }
    C2.lastAudit = null;
    renderComposeAll();
    return true;
  }

  /* ---------- 出图（用户需求⑤后半：导出要检查叠加错误） ----------
   *
   * 用户原话：「可叠加状态只存在于编辑过程中，类似于美术先临时摆放，**而不是输出后的合法图**」。
   * 所以这里是整个拼接流程唯一会「拦」的地方：编辑期一路不拦，到出图这一步才把关。
   */

  /** 体检并把结果写进面板。返回 audit 供调用方决定要不要继续。 */
  function composeRunAudit(verbose) {
    var C2 = cpS();
    var box = $('composeAuditInfo');
    if (!cpHasCanvas()) {
      if (box) box.innerHTML = '<div class="muted">还没有画布</div>';
      return null;
    }
    var a = C.composeAudit(C2.layers, C2.rows, C2.cols);
    C2.lastAudit = a;
    var lines = [];
    lines.push('<div class="kvRow"><span>画布</span><b>' + a.rows + '×' + a.cols + '</b></div>');
    lines.push('<div class="kvRow"><span>可见图层</span><b>' + a.visibleLayers + '</b></div>');
    lines.push('<div class="kvRow"><span>实际非空像素</span><b>' + a.pixelActual + '</b></div>');

    var problems = [];
    if (a.conflictCount) {
      // 点名是哪两个部件在打架 —— 只报总数用户没法下手改
      var pairTxt = Object.keys(a.conflicts.pairs).map(function (k) {
        var ij = k.split('-').map(Number);
        var n1 = C2.layers[ij[0]] ? C2.layers[ij[0]].name : '?';
        var n2 = C2.layers[ij[1]] ? C2.layers[ij[1]].name : '?';
        return '「' + n1 + '」×「' + n2 + '」' + a.conflicts.pairs[k] + ' 格';
      }).join('；');
      problems.push('<div class="kvRow"><span style="color:#ff9a9a">叠加冲突</span><b style="color:#ff9a9a">' +
        a.conflictCount + ' 格</b></div>' +
        '<div class="hint" style="margin:2px 0 4px">' + escHtml(pairTxt) + '</div>');
    }
    if (a.clipped) {
      problems.push('<div class="kvRow"><span style="color:#ff9a9a">被画布切掉</span><b style="color:#ff9a9a">' +
        a.clipped + ' 格</b>（有部件伸出画布，出图会少东西）</div>');
    }
    if (a.layersFullyOutside.length) {
      problems.push('<div class="kvRow"><span style="color:#ff9a9a">完全在画布外</span><b style="color:#ff9a9a">' +
        a.layersFullyOutside.map(function (i) {
          return C2.layers[i] ? C2.layers[i].name : '?';
        }).join('、') + '</b>（等于没摆上）</div>');
    }
    if (!a.pixelActual) problems.push('<div class="kvRow"><span style="color:#ff9a9a">画布是空的</span><b>—</b></div>');

    if (problems.length) {
      lines.push('<div class="kvRow"><span>能否出图</span><b style="color:#ff9a9a">不能</b></div>');
      lines = lines.concat(problems);
    } else {
      lines.push('<div class="kvRow"><span>能否出图</span><b style="color:#9ad0a0">可以</b></div>');
    }
    if (box) box.innerHTML = lines.join('');

    if (verbose) {
      if (a.ok) {
        log('✅ 叠加检查通过：' + a.visibleLayers + ' 个部件互不重叠、都完整落在 ' +
          a.rows + '×' + a.cols + ' 画布内，共 ' + a.pixelActual + ' 个非空像素，可以出图。');
      } else {
        var msg = ['❌ 还不能出图：'];
        if (a.conflictCount) msg.push('有 ' + a.conflictCount + ' 格叠加冲突（把重叠的部件拖开，或把其中一个隐藏/移除）');
        if (a.clipped) msg.push('有 ' + a.clipped + ' 格被画布边界切掉（把部件拖回画布内，或把画布开大）');
        if (a.layersFullyOutside.length) msg.push('有 ' + a.layersFullyOutside.length + ' 个部件完全在画布外');
        if (!a.pixelActual) msg.push('画布上没有任何像素');
        log(msg.join('；') + '。');
      }
    }
    syncComposeButtons();
    return a;
  }

  /** 出图前的统一关卡：不合法就拦下并说清怎么改。返回 null 表示被拦。 */
  function composeGateForExport(what) {
    var a = composeRunAudit(false);
    if (!a) { log('先新建画布'); return null; }
    if (a.ok) return a;
    log('⛔ 已阻止' + what + '：当前拼接图不是合法图（编辑期允许叠着摆，但输出必须干净）。' +
      '点「检查叠加」看具体是哪些部件在哪里打架。');
    composeRunAudit(true);
    return null;
  }

  function composeExportTxt() {
    var C2 = cpS();
    var a = composeGateForExport('导出');
    if (!a) return;
    var flat = C.composeFlatten(C2.layers, C2.rows, C2.cols);
    var nm = safeFileName(($('inComposeName').value || '').trim() ||
      ('拼接_' + C2.rows + 'x' + C2.cols + '_' + C2.layers.length + '主体_' + exportStamp()));
    download(nm + '.txt', new Blob([C.serializeTxt(flat)], { type: 'text/plain;charset=utf-8' }));
    log('已导出「' + nm + '.txt」：' + C2.rows + '×' + C2.cols + '，' +
      a.visibleLayers + ' 个主体，' + a.pixelActual + ' 个非空像素。' +
      '空位是 0，可以直接再导入回本工具或交给生产侧。');
  }

  function composeToLib() {
    var C2 = cpS();
    var a = composeGateForExport('存入图纸库');
    if (!a) return;
    var flat = C.composeFlatten(C2.layers, C2.rows, C2.cols);
    var base = safeFileName(($('inComposeName').value || '').trim() ||
      ('拼接_' + C2.layers.length + '主体'));
    var nm = base, k = 2;
    while ((S.pieceLib || []).some(function (p) { return p && p.key === nm; })) { nm = base + '_' + k; k++; }
    var piece;
    try {
      piece = C.toArtPiece(flat, {
        key: nm,
        sourceName: '拼接：' + C2.layers.map(function (L) { return L.name; }).join(' + '),
        ops: C2.layers.map(function (L) {
          return { piece: L.name, offR: L.offR, offC: L.offC };
        }),
        note: '由拼接工作台合成，' + a.visibleLayers + ' 个主体'
      });
    } catch (e) { log('存入图纸库失败：' + (e && e.message)); return; }
    S.pieceLib.push(piece);
    savePieceLib();
    renderPieceLib();
    log('已把拼接结果存入图纸库：「' + nm + '」' + piece.rows + '×' + piece.cols +
      '，' + piece.pixelCount + ' 格。它现在也能当部件再拿来拼（在部件列表里点「从图纸库全部添加」）。');
    renderComposeAll();
  }

  /** 把选中的多个图层合并成一个新主体（用户需求⑤：可加选减选不同的主体成为新主体）。 */
  function composeMergeSelected() {
    var C2 = cpS();
    if (C2.selected.length < 2) {
      log('先选中 2 个以上图层再合并（在图层列表里按住 Shift/Cmd 点，或在画布上 Shift 点击）');
      return;
    }
    var idxs = [];
    C2.selected.forEach(function (id) {
      var i = C2.layers.findIndex(function (x) { return x.id === id; });
      if (i >= 0) idxs.push(i);
    });
    idxs.sort(function (a, b) { return a - b; });     // 保持原层序，合并结果的覆盖关系才与画面一致
    // 合并前先看这几个之间有没有冲突：有冲突说明它们本来就叠着，
    // 合并后被盖住的像素会真的消失（不再是「暂时被挡住」），必须先说清楚。
    var picked = idxs.map(function (i) { return C2.layers[i]; });
    var cf = C.composeConflicts(picked, C2.rows, C2.cols);
    var res;
    try {
      res = C.composeMergeLayers(C2.layers, idxs, C2.rows, C2.cols);
    } catch (e) { log('合并失败：' + (e && e.message)); return; }
    var names = picked.map(function (L) { return L.name; });
    var newName = names.join('+');
    // 移除被合并的（从后往前删，避免下标错位），插入合并结果到最上层
    for (var i = idxs.length - 1; i >= 0; i--) C2.layers.splice(idxs[i], 1);
    var merged = {
      id: C2.nextId++, name: newName, blocks: res.blocks,
      rows: res.rows, cols: res.cols, offR: 0, offC: 0, locked: false, visible: true
    };
    C2.layers.push(merged);
    C2.selected = [merged.id];
    C2.lastAudit = null;
    log('已把 ' + names.length + ' 个图层合并成一个新主体「' + newName + '」（' +
      res.pixelCount + ' 格）。' +
      (cf.count ? '⚠ 它们之间原有 ' + cf.count + ' 格重叠，合并后被盖住的像素已**真的丢掉**（不再能拖开恢复）。' : '') +
      '合并后的部件尺寸是画布尺寸 ' + res.rows + '×' + res.cols + '，偏移归零 —— ' +
      '因为多个部件的相对位置只有在画布坐标系里才有意义。');
    renderComposeAll();
  }

  /* ---------- 在图层上画（用户需求⑥：涂色 / 直线 / 边框 / 填充） ----------
   *
   * 编辑对象是**当前选中的单个图层**（用户需求⑤原话「单个图层编辑」）。
   * 所有绘制都改那个图层的 blocks，并记一次整层快照供撤销 ——
   * 直线和边框一次动几十上百格，逐格记反而更大。
   *
   * 想凭空画新东西（自制边框）就先「新建空白图层」，它就是画布尺寸的全 0 图层。
   */

  function composeTool() {
    var el = document.querySelector('input[name="composeTool"]:checked');
    return el ? el.value : 'move';
  }
  function composeBrushWidth() {
    var v = parseInt(($('inComposeWidth') || {}).value, 10);
    return isFinite(v) && v > 0 ? v : 1;
  }
  /** 画笔颜色：勾了橡皮擦就是 0（擦成空），否则用美术编辑那边选中的颜色（同一套色库，不另存一份）。 */
  function composeBrushColor() {
    if ($('optComposeErase') && $('optComposeErase').checked) return 0;
    return S.edit.color;
  }
  /** 当前唯一选中的图层；绘制类操作要求恰好选中一个，否则说不清画到哪去。 */
  function composeTargetLayer(quiet) {
    var C2 = cpS();
    if (C2.selected.length !== 1) {
      if (!quiet) {
        log(C2.selected.length === 0
          ? '先选中一个图层再画（点画布上的部件，或点图层列表里的名字）。想凭空画就点「新建空白图层」。'
          : '选中了 ' + C2.selected.length + ' 个图层 —— 画的时候只能选一个，说不清该画到哪个上面。');
      }
      return null;
    }
    var L = cpLayerById(C2.selected[0]);
    if (L && L.locked) {
      if (!quiet) log('「' + L.name + '」已固定，不能在上面画。先点「解固」。');
      return null;
    }
    return L;
  }

  /**
   * 拿一个「现在就能往上画」的图层；没有就**自动准备好**。
   * （用户 2026-09-15 追加要求：「手动涂色/直线/填充/边框等功能需要能在空白画布上直接可操作」）
   *
   * 原先的做法是：没选图层就拒绝，让用户先去点「新建空白图层」。
   * 但在一张空白画布上「先建图层再画」是纯粹的手续 —— 用户的意图明摆着是「在这张画布上画」。
   * 所以这里分三种情况区别对待，而不是一律自动建：
   *
   *   1. 没有任何可画图层（画布空的，或一个都没选中）→ **自动建一张画布尺寸的空白图层**并选中。
   *      建完就选中，所以后续每一笔都落在同一张上，不会每画一笔多出一个图层。
   *   2. 选中的图层被**固定** → 仍然拒绝。用户明确锁了它，说明是有意保护，
   *      这时自动新建会让他以为画上去了却找不到。
   *   3. 选中了**多个** → 仍然拒绝。意图明确指向若干已有图层，自动新建只会更乱。
   */
  function composeEnsureDrawTarget() {
    var C2 = cpS();
    if (!cpHasCanvas()) return null;               // 画布本身的缺失由调用方处理（它要给出更具体的提示）
    if (C2.selected.length === 1) {
      var L = cpLayerById(C2.selected[0]);
      if (L && L.locked) {
        log('「' + L.name + '」已固定，不能在上面画。先在图层列表点「解固」，或点「新建空白图层」另起一层。');
        return null;
      }
      if (L) return L;
    }
    if (C2.selected.length > 1) {
      log('选中了 ' + C2.selected.length + ' 个图层 —— 画的时候只能选一个，说不清该画到哪个上面。' +
        '先点一个图层的名字单选它。');
      return null;
    }
    // 到这里 = 没有任何选中的图层。直接备好一张能画的空白层。
    composeNewBlankLayer(true);
    var made = C2.layers[C2.layers.length - 1];
    return (made && !made.locked) ? made : null;
  }

  /** 记一次图层快照（整层），供撤销。 */
  function composePushUndo(L, what) {
    var C2 = cpS();
    C2.undo = C2.undo || [];
    C2.undo.push({
      id: L.id, what: what,
      blocks: L.blocks.map(function (r) { return r.slice(); })
    });
    if (C2.undo.length > 40) C2.undo.shift();     // 整层快照较大，留 40 步够用
    syncComposeButtons();
  }

  function composeUndo() {
    var C2 = cpS();
    if (!C2.undo || !C2.undo.length) { log('拼接里没有可撤销的绘制操作'); return; }
    var last = C2.undo.pop();
    var L = cpLayerById(last.id);
    if (!L) { log('那个图层已经被移除了，这一步撤销跳过'); renderComposeAll(); return; }
    L.blocks = last.blocks;
    C2.lastAudit = null;
    log('已撤销：' + last.what + '（' + L.name + '）');
    renderComposeAll();
  }

  /**
   * 新建一个画布尺寸的空白图层 —— 自制边框/模块的载体，也是「在空白画布上直接画」的落点。
   * `auto=true` 表示这是绘制时自动补出来的，日志措辞不同（要让用户明白多出来的这一层是哪来的）。
   */
  function composeNewBlankLayer(auto) {
    var C2 = cpS();
    if (!cpHasCanvas()) { log('先新建画布'); return null; }
    var base = auto ? '绘制层' : '空白图层', nm = base, k = 2;
    while (C2.layers.some(function (L) { return L.name === nm; })) { nm = base + '_' + k; k++; }
    var L = {
      id: C2.nextId++, name: nm,
      blocks: C.composeNewCanvas(C2.rows, C2.cols),
      rows: C2.rows, cols: C2.cols, offR: 0, offC: 0, locked: false, visible: true
    };
    C2.layers.push(L);
    C2.selected = [L.id];
    C2.lastAudit = null;
    if (auto) {
      // 自动建出来的图层必须说清，否则用户会奇怪图层列表里怎么多了一层
      log('画布上还没有可画的图层，已自动新建「' + nm + '」（' + C2.rows + '×' + C2.cols +
        ' 全空、覆盖整张画布）并选中它 —— 这一笔就画在它上面。' +
        '接着画都落在同一层；想另起一层再点「新建空白图层」。');
    } else {
      log('已新建「' + nm + '」（' + C2.rows + '×' + C2.cols + ' 全空）。' +
        '选「直线」「边框」「手动涂色」就能在它上面画；画完可用「把选中图层导出为模块 TXT」存成模块图纸。');
    }
    renderComposeAll();
    return L;
  }

  /** 把选中图层单独导出成 txt 模块（用户需求⑥：自制边框导出为全新模块图纸，再重新导入）。 */
  function composeExportLayer() {
    var L = composeTargetLayer();
    if (!L) return;
    var nz = 0;
    L.blocks.forEach(function (r) { r.forEach(function (v) { if (v > 0) nz++; }); });
    if (!nz) { log('「' + L.name + '」是空的，导出一张全 0 的图没有意义'); return; }
    var nm = safeFileName('模块_' + L.name + '_' + exportStamp());
    download(nm + '.txt', new Blob([C.serializeTxt(L.blocks)], { type: 'text/plain;charset=utf-8' }));
    log('已导出模块「' + nm + '.txt」（' + L.blocks.length + '×' + L.blocks[0].length + '，' + nz + ' 格）。' +
      '用②的「导入 TXT 图」把它加回部件列表，就能当成自制边框反复使用。');
  }

  /** 把一批格坐标画到图层上。cells 是**画布坐标**，落到图层内要减去偏移。 */
  function composeApplyCells(L, cells, color, what) {
    var local = [];
    for (var i = 0; i < cells.length; i++) {
      var r = cells[i].r - L.offR, c = cells[i].c - L.offC;
      if (r < 0 || c < 0 || r >= L.blocks.length) continue;
      if (!L.blocks[r] || c >= L.blocks[r].length) continue;
      local.push({ r: r, c: c });
    }
    if (!local.length) {
      log('这一笔全落在「' + L.name + '」的范围之外了 —— 图层只有 ' +
        L.blocks.length + '×' + (L.blocks[0] ? L.blocks[0].length : 0) +
        '，且它当前偏移在 行' + L.offR + ' 列' + L.offC + '。' +
        '想在整张画布上自由画，请用「新建空白图层」（它和画布一样大）。');
      return 0;
    }
    var res = C.paintCells(L.blocks, local, color);
    if (!res.changed) { log('这一笔没有改变任何像素（目标色与原色相同）'); return 0; }
    composePushUndo(L, what);
    L.blocks = res.blocks;
    cpS().lastAudit = null;
    return res.changed;
  }

  /* ---------- 边框生成 ---------- */

  function composeMakeBorder(box) {
    var C2 = cpS();
    // 与画布上拖出来的边框同一口径：空白画布上直接能生成，没有图层就自动补一张
    var L = composeEnsureDrawTarget();
    if (!L) return;
    var kind = $('selComposeBorder').value;
    var w = composeBrushWidth();
    var shape;
    try {
      shape = C.borderShape(kind, box, w, C2.rows, C2.cols);
    } catch (e) { log('生成边框失败：' + (e && e.message)); return; }
    var n = composeApplyCells(L, shape.cells, composeBrushColor(), '生成' + kind);
    if (!n) { renderComposeAll(); return; }
    // 记下这次的形态，供「局部替换某一部件的颜色」
    C2.lastBorder = { layerId: L.id, shape: shape, kind: kind };
    log('已在「' + L.name + '」上生成' + kind + '：线宽 ' + w + ' 格，' + n + ' 个像素，' +
      '范围 行' + shape.box.r0 + '–' + shape.box.r1 + ' 列' + shape.box.c0 + '–' + shape.box.c1 +
      '。下面列出了它的各部件，可以单独给某一部件换色。');
    renderComposeAll();
  }

  function composeBorderFull() {
    var C2 = cpS();
    if (!cpHasCanvas()) { log('先新建画布'); return; }
    composeMakeBorder({ r0: 0, c0: 0, r1: C2.rows - 1, c1: C2.cols - 1 });
  }

  /** 局部替换：把上一次生成的边框里某一个部件换成当前颜色（用户原话的「田字格四个小口」用法）。 */
  function composeRecolorPart(partIndex) {
    var C2 = cpS();
    var lb = C2.lastBorder;
    if (!lb) return;
    var L = cpLayerById(lb.layerId);
    if (!L) { log('那个图层已被移除'); C2.lastBorder = null; renderComposeAll(); return; }
    if (L.locked) { log('「' + L.name + '」已固定，先解固'); return; }
    var part = lb.shape.parts[partIndex];
    if (!part) return;
    var n = composeApplyCells(L, part.cells, composeBrushColor(), '把「' + part.name + '」换色');
    if (n) {
      log('已把' + lb.kind + '的「' + part.name + '」换成 ' +
        (composeBrushColor() === 0 ? '空' : window.AntSolver.getColorName(composeBrushColor())) +
        '（' + n + ' 格）。');
    }
    renderComposeAll();
  }

  function renderComposeBorderParts() {
    var box = $('composeBorderParts');
    if (!box) return;
    var lb = cpS().lastBorder;
    if (!lb) {
      box.innerHTML = '<div class="muted">还没有生成边框。选「边框」工具后在画布上拖一个范围，或点「铺满整张画布」。</div>';
      return;
    }
    var L = cpLayerById(lb.layerId);
    box.innerHTML = '';
    var head = document.createElement('div');
    head.className = 'item muted';
    head.textContent = '上一次生成：' + lb.kind + '（在「' + (L ? L.name : '已移除的图层') + '」上）—— 点部件名即可用当前颜色替换它';
    box.appendChild(head);
    lb.shape.parts.forEach(function (p, i) {
      var row = document.createElement('div');
      row.className = 'item';
      var txt = document.createElement('div');
      txt.className = 'grow';
      txt.textContent = p.name + '　' + p.cells.length + ' 格';
      row.appendChild(txt);
      var b = document.createElement('button');
      b.className = 'miniBtn';
      b.textContent = '换成当前色';
      b.title = '只把「' + p.name + '」这部分改成当前画笔颜色，其余不动';
      b.disabled = !L;
      b.onclick = function () { composeRecolorPart(i); };
      row.appendChild(b);
      box.appendChild(row);
    });
  }

  /** 拼接里的画笔色库（复用美术编辑的 S.edit.color，不另存一份，避免两处颜色不同步）。 */
  function renderComposePalette() {
    var pal = $('composePalette');
    if (!pal) return;
    var h = '<div class="paletteRow">';
    EDIT_PALETTE.forEach(function (id) {
      var name = window.AntSolver.getColorName(id);
      h += '<div class="swatchCell">' +
        '<div class="editSwatch' + (S.edit.color === id ? ' active' : '') +
        '" data-cpcolor="' + id + '" style="background:' + window.AntSolver.getColorCSS(id) +
        '" title="' + name + '（' + id + '号）　点击选为拼接的画笔颜色"></div>' +
        '<div class="swatchName">' + name + '(' + id + ')</div></div>';
    });
    h += '</div>';
    pal.innerHTML = h;
    Array.prototype.forEach.call(pal.querySelectorAll('[data-cpcolor]'), function (el) {
      el.onclick = function () {
        S.edit.color = +el.getAttribute('data-cpcolor');
        renderComposePalette();
        renderEditPalette();       // 两边共用一个颜色，另一边也要跟着高亮
        log('拼接画笔颜色：' + window.AntSolver.getColorName(S.edit.color) + '(' + S.edit.color + ')');
      };
    });
  }

  function initFloatPanels() {
    Array.prototype.forEach.call(document.querySelectorAll('.floatToggle'), function (btn) {
      var panel = $(btn.getAttribute('data-float'));
      if (panel) ensureResizeHandles(panel);
      btn.onclick = function (ev) { ev.stopPropagation(); toggleFloat(btn.getAttribute('data-float')); };
    });

    var act = null;   // { kind:'move'|'resize', panel, ... }

    document.addEventListener('mousedown', function (ev) {
      if (!ev.target.closest) return;
      // ① 拖边缘/角 = 放大缩小
      var rz = ev.target.closest('.rzHandle');
      if (rz) {
        var p1 = rz.parentNode;
        if (!p1 || !p1.classList.contains('floating')) return;
        var r1 = p1.getBoundingClientRect();
        act = {
          kind: 'resize', panel: p1, mode: rz.getAttribute('data-rz'),
          startX: ev.clientX, startY: ev.clientY, w0: r1.width, h0: r1.height, left: r1.left, top: r1.top
        };
        ev.preventDefault();
        return;
      }
      // ② 拖标题栏 = 移动
      var head = ev.target.closest('.floatHead');
      if (!head) return;
      var panel = head.parentNode;
      if (!panel || !panel.classList.contains('floating')) return;
      if (ev.target.classList && ev.target.classList.contains('floatToggle')) return;   // 点按钮不算拖动
      var r = panel.getBoundingClientRect();
      act = { kind: 'move', panel: panel, dx: ev.clientX - r.left, dy: ev.clientY - r.top };
      ev.preventDefault();
    });

    document.addEventListener('mousemove', function (ev) {
      if (!act) return;
      var st = FLOAT_STATE[act.panel.id] || (FLOAT_STATE[act.panel.id] = {});
      if (act.kind === 'move') {
        // 限制在窗口内，避免拖到屏幕外找不回来
        var left = Math.max(0, Math.min(window.innerWidth - 60, ev.clientX - act.dx));
        var top = Math.max(0, Math.min(window.innerHeight - 30, ev.clientY - act.dy));
        act.panel.style.left = left + 'px';
        act.panel.style.top = top + 'px';
        st.left = left; st.top = top;
        return;
      }
      // 放大缩小：右边缘只改宽，下边缘只改高，右下角同时改
      if (act.mode !== 'rzB') {
        var w = Math.max(FLOAT_MIN_W, Math.min(window.innerWidth - act.left - 4, act.w0 + (ev.clientX - act.startX)));
        act.panel.style.width = w + 'px';
        st.width = Math.round(w);
      }
      if (act.mode !== 'rzR') {
        var h = Math.max(FLOAT_MIN_H, Math.min(window.innerHeight - act.top - 4, act.h0 + (ev.clientY - act.startY)));
        act.panel.style.height = h + 'px';
        st.height = Math.round(h);
      }
    });

    document.addEventListener('mouseup', function () { act = null; });
  }

  /** 切换压力图轨迹类型，并把两个按钮的选中态同步出来（当前看的是哪一套必须一眼可见）。 */
  function setPressureTrack(track) {
    S.pressureTrack = track;
    var bo = $('btnTrackOmni'), bp = $('btnTrackPlayer');
    if (bo && bp) {
      bo.className = 'btn ' + (track === 'omni' ? 'primary' : 'ghost');
      bp.className = 'btn ' + (track === 'player' ? 'primary' : 'ghost');
    }
    refreshPressureChart();
  }

  function drawPressureEmpty(cv, msg) {
    var ctx = cv.getContext('2d');
    ctx.fillStyle = '#1c130c'; ctx.fillRect(0, 0, cv.width, cv.height);
    ctx.fillStyle = '#7a6248'; ctx.font = '11px sans-serif'; ctx.fillText(msg, 8, 20);
  }

  /**
   * 画布坐标换算：x=进度(0~1)映射到[padL,w-padR]，y=暂存量(0~bufferLimit)映射到[h-padB,padT]（上小下大翻转）。
   * 需求 07.30 §三.1 明确要求坐标可读性：横轴 0%-100% 可读比例刻度+网格，纵轴 0/1/2/3/4/5 整数刻度，
   * 图例/轴标题/数值不得互相遮挡——因此本函数加了顶部图例条（固定高度，不与曲线区重叠）和左右两侧
   * 分别放轴标题，网格线用比坐标轴更浅的颜色区分主次。
   */
  function drawPressureChart(cv, curveBefore, curveAfter, interval, opts) {
    opts = opts || {};
    var ctx = cv.getContext('2d');
    var w = cv.width, h = cv.height;
    var padL = 30, padR = 10, padT = 20, padB = 26;   // padT 多留一行给图例，padB 多留一行给横轴刻度+标题
    var plotW = w - padL - padR, plotH = h - padT - padB;
    ctx.fillStyle = '#1c130c'; ctx.fillRect(0, 0, w, h);
    var bufferLimit = curveBefore.bufferLimit || 5;
    var yMax = bufferLimit;
    function X(p) { return padL + p * plotW; }
    function Y(v) { return padT + plotH - (Math.min(v, yMax) / yMax) * plotH; }

    // 纵轴网格线 + 整数刻度 0..bufferLimit（需求：按 0、1、2、3、4、5 显示整数刻度）
    ctx.font = '9px Menlo, monospace'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    for (var yi = 0; yi <= bufferLimit; yi++) {
      var gy = Y(yi);
      ctx.strokeStyle = yi === bufferLimit ? 'rgba(255,176,102,0.5)' : 'rgba(255,255,255,0.08)';
      ctx.lineWidth = 1;
      if (yi === bufferLimit) { ctx.setLineDash([4, 3]); } else { ctx.setLineDash([]); }
      ctx.beginPath(); ctx.moveTo(padL, gy); ctx.lineTo(padL + plotW, gy); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#7a6248';
      ctx.fillText(String(yi), padL - 4, gy);
    }
    // 横轴网格线 + 刻度。全知轨迹按完成进度标 0%~100%；玩家轨迹按操作步数标真实步号，
    // 避免把「第几步」显示成百分比造成误读（需求 §一.5 要求横轴含义必须明确）。
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    var stepTotal = opts.xTicksAsSteps || 0;
    [0, 0.25, 0.5, 0.75, 1].forEach(function (p) {
      var gx = X(p);
      ctx.strokeStyle = 'rgba(255,255,255,0.06)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(gx, padT); ctx.lineTo(gx, padT + plotH); ctx.stroke();
      ctx.fillStyle = '#7a6248';
      var label = stepTotal ? String(Math.round(p * stepTotal)) : ((p * 100) + '%');
      ctx.fillText(label, Math.max(padL + 10, Math.min(gx, padL + plotW - 10)), padT + plotH + 3);
    });
    // 坐标轴主线（比网格线更亮，标出绘图区边界）
    ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(padL, padT); ctx.lineTo(padL, padT + plotH); ctx.lineTo(padL + plotW, padT + plotH); ctx.stroke();
    // 轴标题（横轴：进度；纵轴：暂存数量，竖排文字放在左上角，不与刻度数字重叠）
    ctx.fillStyle = '#9c8168'; ctx.font = '9px sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'bottom';
    ctx.fillText(opts.xLabel || '进度', padL + plotW, padT + plotH + 15);
    ctx.textAlign = 'left';
    ctx.save();
    ctx.translate(8, padT + plotH / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = 'center'; ctx.fillText('暂存数量', 0, 0);
    ctx.restore();

    // 用户区间参考带（半透明竖条）
    if (interval) {
      var x0 = X(interval.snapped.lo / 100), x1 = X(interval.snapped.hi / 100);
      ctx.fillStyle = 'rgba(255,176,102,0.10)';
      ctx.fillRect(x0, padT, Math.max(1, x1 - x0), plotH);
    }

    function drawCurve(curve, color) {
      if (!curve || !curve.points.length) return;
      ctx.strokeStyle = color; ctx.lineWidth = 1.6; ctx.beginPath();
      curve.points.forEach(function (p, i) {
        var x = X(p.progress), y = Y(p.buf);
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.stroke();
      // 卡点位置标记（若有正式审核数据；无数据时不画，不伪造标记位置）
      if (curve.audit && curve.audit.hasChoke && curve.audit.lateAt != null) {
        var cx = X(curve.audit.lateAt / 100), cy = Y(curve.audit.lateMax);
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.arc(cx, cy, 3, 0, Math.PI * 2); ctx.fill();
      }
    }
    drawCurve(curveBefore, opts.color || PRESSURE_COLOR_BEFORE);
    if (curveAfter) drawCurve(curveAfter, PRESSURE_COLOR_AFTER);

    // 顶部图例条（固定在 padT 之上的专用区域，不会被曲线/网格盖住）。
    // 需求 §一.5：图例必须写清求解类型，不能只写「修改前 / 重构后」而不说明是全知还是玩家。
    var legend = opts.legend || (curveAfter ? [['修改前', PRESSURE_COLOR_BEFORE], ['重构后', PRESSURE_COLOR_AFTER]] : null);
    if (legend && legend.length) {
      ctx.font = '9px sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
      var lx = padL;
      legend.forEach(function (lg) {
        ctx.fillStyle = lg[1]; ctx.fillRect(lx, 2, 8, 8);
        ctx.fillStyle = '#c9a98a'; ctx.fillText(lg[0], lx + 11, 2);
        lx += 11 + ctx.measureText(lg[0]).width + 12;
      });
    }
  }

  function renderPressureInfo(curveBefore, curveAfter) {
    // 玩家轨迹与全知轨迹共用这张小表，标题要跟着变，不能一律写「（原）」。
    var isPlayer = curveBefore && curveBefore.kind === 'player';
    var suffix = isPlayer ? '（玩家本轮）' : '（原）';
    var rows = [
      ['峰值 / 均值' + suffix, curveBefore.peak + ' / ' + curveBefore.avg],
      ['卡点' + suffix, curveBefore.audit ? (curveBefore.audit.hasChoke ? '有，位于进度 ' + curveBefore.audit.lateAt + '%' : '无') : '—']
    ];
    $('pressureInfo').innerHTML = kvTable(rows);
    if (!curveAfter) { $('pressureCompareTable').innerHTML = ''; return; }
    var cmpRows = [
      ['峰值 / 均值（重构后）', curveAfter.peak + ' / ' + curveAfter.avg],
      ['卡点（重构后）', curveAfter.audit ? (curveAfter.audit.hasChoke ? '有，位于进度 ' + curveAfter.audit.lateAt + '%' : '无') : '—']
    ];
    $('pressureCompareTable').innerHTML = kvTable(cmpRows);
  }

  // ==================== 自动演示 ====================
  /** 定位成功后默认把演示游标摆到区间下限，方便直接点播放看后续消除过程。 */
  function demoSetupFromInterval() {
    var it = viewItem();
    if (!it || !it.tl) return;
    S.demo.idx = it.interval ? it.interval.stepIndex.lo : 0;
    demoRenderAtIdx();
  }

  function demoPause() {
    if (S.demo.timer) { clearInterval(S.demo.timer); S.demo.timer = null; }
    $('btnDemoPlay').disabled = false;
    $('btnDemoPause').disabled = true;
  }

  function demoPlay() {
    var it = viewItem();
    if (!it || !it.tl) { log('请先求解 / 导入求解数据，得到可播放的路线'); return; }
    if (S.demo.timer) return;
    $('btnDemoPlay').disabled = true;
    $('btnDemoPause').disabled = false;
    var speed = parseInt($('demoSpeed').value, 10) || 5;
    var intervalMs = Math.max(30, 260 - speed * 24);  // 速度1→约236ms/步，速度10→约20ms/步
    S.demo.timer = setInterval(function () {
      var itNow = viewItem();
      if (!itNow || !itNow.tl || S.demo.idx >= itNow.tl.steps.length) { demoPause(); return; }
      S.demo.idx++;
      demoRenderAtIdx();
    }, intervalMs);
  }

  function demoStep(delta) {
    var it = viewItem();
    if (!it || !it.tl) return;
    demoPause();
    S.demo.idx = Math.max(0, Math.min(it.tl.steps.length, S.demo.idx + delta));
    demoRenderAtIdx();
  }

  function demoJump(idx) {
    var it = viewItem();
    if (!it || !it.tl) return;
    demoPause();
    S.demo.idx = Math.max(0, Math.min(it.tl.steps.length, idx));
    demoRenderAtIdx();
  }

  /** 渲染演示当前游标：目标图累计揭示 + 棋盘/暂存快照（若有）+ 信息面板 + 进度条。 */
  function demoRenderAtIdx() {
    var it = viewItem();
    if (!it || !it.tl) return;
    var idx = S.demo.idx;
    var scrub = $('demoScrub');
    scrub.max = it.tl.steps.length; scrub.value = idx;

    // 目标图累计揭示：用 pixelsUpTo 求 0..idx 步的并集，画法与 draw() 里的高亮一致（描边而非覆盖颜色）
    var revealed = C.pixelsUpTo(it.tl.steps, idx);
    demoDrawTarget(it, revealed);

    var board = C.boardAtStep(it.tl, idx);
    if (board && $('optBoard').checked) {
      // 演示模式下棋盘区左列改为「当前帧」，右列固定显示区间上限，方便看播放到哪一步、离目标还差多少
      $('boardCompareWrap').classList.remove('hidden');
      var boardB = it.interval ? C.boardAtStep(it.tl, it.interval.stepIndex.hi) : null;
      buildBoardPanel($('boardCompareWrap'), '当前帧（第 ' + idx + ' 步）',
        it.interval ? ('状态B（区间上限 ' + it.interval.snapped.hi + '%）') : '（未定位区间）');
      drawBoardInto($('cvBoardA'), board);
      drawBufferInto($('bufA'), board);
      if (boardB) { drawBoardInto($('cvBoardB'), boardB); drawBufferInto($('bufB'), boardB); }
    }

    var done = idx <= 0 ? 0 : it.tl.steps[idx - 1].done;
    var rows = [
      ['当前步', idx + ' / ' + it.tl.steps.length],
      ['完成盒数', done + ' / ' + it.tl.totalBoxes + '（' + (it.tl.totalBoxes ? (done / it.tl.totalBoxes * 100).toFixed(2) : 0) + '%）'],
      ['累计揭示像素', revealed.length + ' / ' + it.tl.totalPixels]
    ];
    if (idx > 0) { var s = it.tl.steps[idx - 1]; rows.push(['本步', '(' + s.r + ',' + s.c + ') ' + colorLabel(s.color) + ' ' + s.count + ' 像素']); }
    $('demoInfo').innerHTML = kvTable(rows);
  }

  /**
   * 演示专用目标图绘制：真实表现「消除」——已消除像素清空为背景色（不画色块），
   * 未消除像素保持原色。不用任何黑色遮罩（此前版本的方向是反的：未播放区域被遮罩、已播放区域显示原色，
   * 与真实游戏「消除后清空」相反，已按 Codex 审查结果修正）。
   * 绘制顺序（自底向上）：①背景 → ②未消除像素原色 → ③可选区间边界描边（不填色）。
   */
  function demoDrawTarget(it, revealedList) {
    var cv = $('cv'), ctx = cv.getContext('2d');
    var blocks = it.blocks, rows = blocks.length, cols = blocks[0].length;
    var cell = parseInt($('cellSize').value, 10) || 11;
    cv.width = cols * cell + 1; cv.height = rows * cell + 1;
    // ① 背景（同时也是「已消除像素」的显示效果：清空即背景色，不额外画任何东西）
    ctx.fillStyle = '#1c130c'; ctx.fillRect(0, 0, cv.width, cv.height);
    var revealedSet = {};
    for (var i = 0; i < revealedList.length; i++) revealedSet[revealedList[i]] = 1;
    // ② 只画「尚未消除」的像素，保持原色；已消除的格子不画，直接露出背景
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        var id = blocks[r][c];
        if (!id) continue;
        var idx = r * cols + c;
        if (revealedSet[idx]) continue;   // 已消除：不画，露出背景
        ctx.fillStyle = window.AntSolver.getColorCSS(id);
        ctx.fillRect(c * cell, r * cell, cell, cell);
      }
    }
    // ③ 区间边界（可选）：只描边，不覆盖任何像素颜色，不干扰消除状态的显示
    var legend = [];
    if ($('optDemoRegion') && $('optDemoRegion').checked && it.interval && it.interval.diffPixels.length) {
      strokeGroups(ctx, [it.interval.diffPixels], rows, cols, cell, STROKE.single, 1.4, [4, 3]);
      legend.push('<span><i class="sw" style="border-top-color:' + STROKE.single + '"></i>区间边界参考线（不影响消除显示）</span>');
    }
    $('legend').innerHTML = legend.join('');
  }

  // ==================== 美术编辑（1-34完整色库 + 颜色分组 + 全局/局部替换 + 靠色检查 + 框选） ====================
  // 交互思路参考 bin/参考/目标图TXT编辑器_可手动框选版（COLOR_MAP/replaceColor/框选状态/局部替换/局部绘制），
  // 不复制其 UI 代码；色值与中文名以 bin/参考/毛线色库/ 为唯一业务来源（与 bin/js/utils.js 的
  // AntSolver.COLORS[1..34] 完全一致，工具直接调用 getColorCSS/getColorName，不重复定义色表）。
  // 本工具只做像素编辑与守恒对比，不做自动重构关卡（重构在「10. 重构关卡」）。

  var EDIT_PALETTE = (function () { var a = []; for (var i = 1; i <= 34; i++) a.push(i); return a; })();

  /**
   * 完整色库面板（需求 08.03 §二）。
   *
   * 分组方式：**同一套色库**内部分成两段——
   *   目标图当前已有的颜色集中排在前面，并由一个共同的外层边框整体框住；
   *   当前未使用的颜色排在这个边框外面。
   * 边框内外合起来就是完整的 34 色，不复制第二套色库，也不再另做一块「当前目标图颜色」面板。
   *
   * 交互保持不变并全部保留：
   *   点任何色块 = 选为当前绘制颜色；正处于替换流程时点色块 = 选定替换目标色；
   *   边框内每个已有颜色带一个「整图替换」小按钮 = 原「当前目标图颜色」面板的全局替换入口，
   *     入口从独立面板搬进边框内，能力没有减少。
   * 边框内每个色块下方标出该色的像素数与占比。
   */
  function renderEditPalette() {
    var pal = $('editPalette');
    var it = cur();
    if (!pal) return;
    if (!it) { pal.innerHTML = ''; return; }
    var counts = colorCountsOf(it);
    var total = 0; Object.keys(counts).forEach(function (k) { total += counts[k]; });
    var usedIds = [], freeIds = [];
    for (var i = 0; i < EDIT_PALETTE.length; i++) {
      (counts[EDIT_PALETTE[i]] ? usedIds : freeIds).push(EDIT_PALETTE[i]);
    }

    function swatch(id, withStat) {
      var name = window.AntSolver.getColorName(id);
      var cnt = counts[id] || 0;
      var pct = total && cnt ? (cnt / total * 100).toFixed(1) + '%' : '';
      var isActive = S.edit.color === id;
      var replacing = S.edit.replacing && S.edit.replacing.scope === 'global' && S.edit.replacing.oldId === id;
      var h = '<div class="swatchCell' + (replacing ? ' replacing' : '') + '">' +
        '<div class="editSwatch' + (isActive ? ' active' : '') + (cnt ? ' used' : '') +
        '" data-color="' + id + '" style="background:' + window.AntSolver.getColorCSS(id) +
        '" title="' + name + '（' + id + '号）' + (cnt ? '　已用 ' + cnt + ' 像素' : '　这张图未使用') +
        '　点击选为当前绘制颜色"></div>';
      // 凡是显示颜色数量的地方都必须同时显示中文颜色名（用户 2026-08-03 微调第 6 项）
      h += '<div class="swatchName">' + name + '(' + id + ')</div>';
      if (withStat) {
        h += '<div class="swatchStat">' + cnt + ' 像素<br>' + pct + '</div>' +
          '<button class="swatchReplace' + (replacing ? ' on' : '') + '" data-replace="' + id + '" ' +
          'title="把整张图里的「' + name + '」全部换成另一个颜色：点这里，再点你要换成的色块；再点一次本按钮取消">' +
          (replacing ? '取消替换' : '整图替换') + '</button>';
      }
      return h + '</div>';
    }

    var h = '';
    h += '<div class="paletteUsedBox">' +
      '<div class="paletteGroupTitle">当前目标图已有颜色（' + usedIds.length + ' 种）' +
      (usedIds.length ? '　<span class="muted">数字为像素数与占比</span>' : '') + '</div>' +
      '<div class="paletteRow">' +
      (usedIds.length ? usedIds.map(function (id) { return swatch(id, true); }).join('')
        : '<span class="muted">这张目标图还没有任何像素</span>') +
      '</div></div>';
    h += '<div class="paletteGroupTitle">完整色库中当前未使用的颜色（' + freeIds.length + ' 种，同样可以直接选用）</div>' +
      '<div class="paletteRow">' + freeIds.map(function (id) { return swatch(id, false); }).join('') + '</div>';
    pal.innerHTML = h;

    Array.prototype.forEach.call(pal.querySelectorAll('.editSwatch'), function (el) {
      el.onclick = function () {
        var id = +el.getAttribute('data-color');
        if (S.edit.replacing) { performColorReplace(id); return; }
        S.edit.color = id;
        renderEditPalette();
      };
    });
    // 全局替换入口（原独立面板的能力，现在挂在边框内的已有颜色上）
    Array.prototype.forEach.call(pal.querySelectorAll('.swatchReplace'), function (el) {
      el.onclick = function (ev) {
        ev.stopPropagation();
        startColorReplace('global', +el.getAttribute('data-replace'));
      };
    });
  }

  /** 当前 item 目标图的颜色统计（缓存复用 core.js colorCounts，供多处面板共用）。 */
  function colorCountsOf(it) { return it && it.blocks ? C.colorCounts(it.blocks) : {}; }

  /**
   * 颜色的统一写法：中文名 + 色号。
   * 用户 2026-08-03 微调第 6 项：只要露出颜色，就要带颜色名；凡是带颜色数量的地方更必须带名字，
   * 不允许只写一个色号让人去猜。页面与导出报告都走这一个函数，避免各处写法不一致。
   */
  function colorLabel(id) {
    if (!(id > 0)) return '空白(0)';
    return window.AntSolver.getColorName(id) + '(' + id + ')';
  }

  /** 「选区内颜色」统计面板（需求 §四.5 第3点）：仅在框选工具下有选区时显示，点击某色进入「区域替换」流程。 */
  function renderSelectionColorsPanel() {
    var box = $('editSelectionColors');
    var it = cur();
    if (!box) return;
    var sel = S.edit.selection;
    var cells = selCells();
    if (!it || !it.blocks || !sel || !cells) { box.innerHTML = ''; $('editSelectionInfo').innerHTML = ''; return; }
    var w = sel.c1 - sel.c0 + 1, h2 = sel.r1 - sel.r0 + 1;
    var rectN = w * h2;
    // 选区可能不规则：既报「实际选中几格」，也报外接矩形，两者不同时明确说出来，
    // 否则用户会以为工具算错了。
    $('editSelectionInfo').innerHTML = '选区实选 <b>' + cells.length + '</b> 格' +
      (cells.length !== rectN
        ? '（不规则；外接矩形 ' + w + '×' + h2 + ' = ' + rectN + ' 格）'
        : '（矩形 ' + w + '×' + h2 + '）') +
      '　行 ' + sel.r0 + '–' + sel.r1 + '，列 ' + sel.c0 + '–' + sel.c1;
    var counts = C.colorCountsInCells(it.blocks, cells);
    var total = cells.length;
    var ids = Object.keys(counts).map(Number).sort(function (a, b) { return a - b; });
    // 每项两个动作，分开放：
    //   条目主体 → 既有的「选区内替换颜色」（不动，免得破坏原有用法）；
    //   右侧「只选」→ 2026-09-15 新增的「把选区收窄成选区里的这个颜色」。
    //   后者是「区域内同色」最省力的入口：面板已经把选区里有哪些色、各多少格列出来了，
    //   点一下就等于「套索范围 ∩ 该色」，不用再切工具、也不用记叠加方式。
    var h = ids.length ? ids.map(function (id) {
      var cnt = counts[id], pct = total ? (cnt / total * 100).toFixed(1) : '0';
      var active = S.edit.replacing && S.edit.replacing.scope === 'selection' && S.edit.replacing.oldId === id;
      return '<div class="usedColorItem' + (active ? ' active' : '') + '" data-id="' + id + '" ' +
        'title="点击：只在当前选区内把该颜色替换为另一色；再点一次取消">' +
        '<i class="sw2" style="background:' + window.AntSolver.getColorCSS(id) + '"></i>' +
        '<span>' + window.AntSolver.getColorName(id) + '(' + id + ') ' + cnt + ' 像素 ' + pct + '%' +
        (active ? '　← 点其它颜色完成替换' : '') + '</span>' +
        '<button class="miniBtn pickOnly" data-pick="' + id + '" ' +
        'title="把选区收窄成「选区里的这个颜色」（' + cnt + ' 格）。Shift 加选、Alt 减选。' +
        '用来只清边缘的描边色而不动主体轮廓">只选</button>' +
        '</div>';
    }).join('') : '<div class="muted">选区内无像素</div>';
    box.innerHTML = h;
    Array.prototype.forEach.call(box.querySelectorAll('.usedColorItem'), function (el) {
      el.onclick = function (ev) {
        // 点到「只选」按钮时不要触发替换流程
        if (ev.target && ev.target.getAttribute && ev.target.getAttribute('data-pick')) return;
        startColorReplace('selection', +el.getAttribute('data-id'));
      };
    });
    Array.prototype.forEach.call(box.querySelectorAll('button[data-pick]'), function (b) {
      b.onclick = function (ev) {
        ev.stopPropagation();
        pickColorWithinSelection(+b.getAttribute('data-pick'), ev);
      };
    });
  }

  /**
   * 「只选」：把当前选区收窄成「选区 ∩ 某个颜色」。
   *
   * 这是用户 2026-09-15 需求③的直接入口。为什么需要它（实测，见
   * `_kiro临时/09.15-去毛边与同色区域选区/`）：描边色同时构成边缘杂物和主体轮廓，
   * 且在图上是碎的（熊猫图色 33 共 573 格却切成 94 块、最大块仅 89 格），
   * 于是「同色块」一次够不着整条边缘、「按色选」又会连主体轮廓一起选中。
   * 先圈范围再按色收窄，才能只清边缘：熊猫左右边缘带 ∩ 色33 = 68 格，
   * 主体腹地那 505 格描边一格不动。
   *
   * Shift/Alt 仍然生效：加选/减选的对象同样是「选区内的该色」，而不是全图该色。
   */
  function pickColorWithinSelection(colorId, ev) {
    var it = cur();
    if (!it || !it.blocks) return;
    var region = S.edit.mask;
    if (!region) { log('先框出一个范围，再点「只选」。没有范围时按色收窄没有意义（会变成全图该色）'); return; }
    var picked = C.maskFromColorInRegion(it.blocks, colorId, region);
    var n = C.maskCount(picked);
    if (!n) { log('当前选区里没有 ' + window.AntSolver.getColorName(colorId) + '(' + colorId + ')'); return; }
    var mode = combineModeOf(ev);
    var name = window.AntSolver.getColorName(colorId) + '(' + colorId + ')';
    if (mode === 'add' || mode === 'subtract') {
      // 加/减：对象是「选区内的该色」，语义上等同于在原选区基础上做局部调整
      applySelection(picked, ev, '选区内的 ' + name + ' ' + n + ' 格');
    } else {
      // 默认（含界面选的替换/交集）都收窄为「选区 ∩ 该色」——这才是「只选」的字面意思
      setSelectionMask(picked);
      draw(); refreshEditPanels(); renderExtractPanel();
      log('只选：选区已收窄为其中的 ' + name + '，' + n + ' 格' +
        '（原选区 ' + C.maskCount(region) + ' 格）。主体其它地方的同色不受影响，' +
        '接下来可在「12. 主体提取」点「挖空选区内」清掉它们');
    }
  }

  /** 靠色检查面板（需求 §四.4，固定 5 组靠色对，不自行扩展 RGB 距离规则）：全图 + 选区（若有）分别检查。 */
  function renderCloseCheckPanels() {
    var it = cur();
    var boxFull = $('editCloseCheckFull');
    if (!it || !it.blocks) { boxFull.innerHTML = ''; return; }
    var counts = colorCountsOf(it);
    var total = 0; Object.keys(counts).forEach(function (k) { total += counts[k]; });
    var hitsFull = C.checkClosePairs(counts, total);
    boxFull.innerHTML = hitsFull.length ? hitsFull.map(function (h) {
      return '<div class="closeHit"><span class="tag warn">靠色</span> ' + h.nameA + '(' + h.a + ') ' + h.countA + ' 像素 ' + h.pctA + '%　↔　' +
        h.nameB + '(' + h.b + ') ' + h.countB + ' 像素 ' + h.pctB + '%</div>';
    }).join('') : '<div class="muted">全图未命中固定靠色对</div>';

    var boxSel = $('editCloseCheckSelection');
    var cells = selCells();
    if (!cells) { boxSel.innerHTML = ''; return; }
    var countsSel = C.colorCountsInCells(it.blocks, cells);
    var hitsSel = C.checkClosePairs(countsSel, cells.length);
    boxSel.innerHTML = hitsSel.length ? hitsSel.map(function (h) {
      return '<div class="closeHit"><span class="tag warn">选区靠色</span> ' + h.nameA + '(' + h.a + ') ' + h.countA + ' 像素　↔　' +
        h.nameB + '(' + h.b + ') ' + h.countB + ' 像素</div>';
    }).join('') : '<div class="muted">选区内未命中固定靠色对</div>';
  }

  // ==================== 碎色率检查（任务 ANT-ARTTOOL-FRAGMENT-QUOTA-20260825） ====================
  // 用户 2026-08-25：「将碎色率检查接入到修图工具，用来提醒美术应该修改到什么程度」。
  //
  // 口径来自 js/fragment.js —— 它是 bin/js/generator.js 的 computeFragmentation 同源副本，
  //   所以这里显示的碎色率就是生产时【生产前置碎色闸门】会拿去判定的那个数字，不是另一套算法。
  //   一致性已用真实源图 60 张逐字段校验（差 0.00），脚本见
  //   _kiro临时/08.25-工具碎色与配额/_验碎色口径一致.js。
  //
  // 为什么不实时重算：55×55 全图一次约 0.1~0.3s（含 eliminationOrder 求消除轮次），
  //   拖动绘制时逐格重算会卡手。改为「改动后标记过期 + 手动重算」。

  var fragState = { result: null, assess: null, stale: true, key: null };

  /** 当前选定的达标阈值（0~1 比率）。下拉选"自定义"时取旁边输入框的百分比。 */
  function currentFragGate() {
    var sel = $('fragGateSel');
    var F = window.AntFragment;
    var DEF = F ? F.GATE_DEFAULT : 0.18;
    if (!sel) return DEF;
    if (sel.value === 'custom') {
      var v = parseFloat(($('fragGateCustom') || {}).value);
      if (isNaN(v) || v <= 0 || v >= 100) return DEF;
      return +(v / 100).toFixed(6);
    }
    var r = parseFloat(sel.value);
    return (isNaN(r) || r <= 0) ? DEF : r;
  }

  /**
   * 阈值改动统一入口（用户 2026-08-25：「方便美术随时可调整」）。
   * 碎色率本身与阈值无关，所以只重新 assess，不重算碎色 —— 改阈值是即时的，不用等。
   * 同时把选择记到 localStorage（只存一个数字），下次打开工具仍是上次选的值。
   */
  function onFragGateChanged() {
    var gate = currentFragGate();
    var F = window.AntFragment;
    var saved = F && F.saveGate ? F.saveGate(gate) : false;
    var tip = $('fragGateSaved');
    if (tip) tip.textContent = saved ? '已记住 ' + (gate * 100).toFixed(2) + '%' : '';
    if (fragState.result && F) {
      fragState.assess = F.assess(fragState.result, gate);
      renderFragPanel();
    }
  }

  /** 页面初始化时把上次记住的阈值恢复到控件上（没记过则用默认 18%）。 */
  function restoreFragGate() {
    var F = window.AntFragment;
    if (!F || !F.loadSavedGate) return;
    var saved = F.loadSavedGate();
    if (saved == null) return;
    var sel = $('fragGateSel');
    if (!sel) return;
    var matched = false;
    for (var i = 0; i < sel.options.length; i++) {
      if (Math.abs(parseFloat(sel.options[i].value) - saved) < 1e-9) { sel.value = sel.options[i].value; matched = true; break; }
    }
    if (!matched) {
      sel.value = 'custom';
      if ($('fragGateCustom')) {
        $('fragGateCustom').style.display = '';
        $('fragGateCustom').value = +(saved * 100).toFixed(2);
      }
    }
    var tip = $('fragGateSaved');
    if (tip) tip.textContent = '已恢复上次设置 ' + (saved * 100).toFixed(2) + '%';
  }

  /** 目标图有改动 → 把已算出的碎色率标为过期（不清空，仍显示旧值但标注"已过期"）。 */
  function markFragStale() {
    if (fragState.result) { fragState.stale = true; renderFragPanel(); }
  }

  /** 真正跑一次碎色计算。overlay 遮罩：全图计算有感知延迟，不给反馈会让人以为按钮没响应。 */
  function runFragCheck(silent) {
    var it = cur();
    var box = $('fragInfo');
    if (!box) return;
    if (!window.AntFragment) { box.innerHTML = '<div class="muted">碎色模块未加载（js/fragment.js）</div>'; return; }
    // 碎色率由 bin/js/generator.js 的 computeFragmentation 计算。若 bin 副本版本过旧（v102 之前
    // 没有这个函数），如实提示而不是静默出 0 —— 静默出 0 会让美术以为图很干净。
    if (!window.AntFragment.ready()) {
      box.innerHTML = '<div class="muted">碎色计算不可用：当前 <code>bin/js/generator.js</code> 副本里没有 ' +
        '<code>computeFragmentation</code>（该函数自主工程 v102 起提供）。请按 ' +
        '<code>关卡图修改工具/bin/来源说明.md</code> 的规程重拷一次 bin 副本。</div>';
      return;
    }
    if (!it || !it.blocks || !it.blocks.length) {
      fragState = { result: null, assess: null, stale: true, key: null };
      box.innerHTML = '<div class="muted">先导入一张目标图</div>';
      var pc0 = $('fragPerColor'); if (pc0) pc0.innerHTML = '';
      return;
    }
    var t0 = Date.now();
    var frag = window.AntFragment.computeFragmentation(it.blocks, {});
    if (!frag) { box.innerHTML = '<div class="muted">碎色计算失败（生成器模块未就绪）</div>'; return; }
    fragState.result = frag;
    fragState.assess = window.AntFragment.assess(frag, currentFragGate());
    fragState.stale = false;
    fragState.key = it.key;
    renderFragPanel();
    if (!silent) {
      var a = fragState.assess;
      log('碎色率检查：' + a.ratePct + '%（' + a.grade + '）　阈值 ' + a.limitPct + '% → ' +
        (a.pass ? '达标' : '超出 ' + a.gapPp + ' 个百分点，至少需把 ' + a.needFixPixels + ' 个碎色像素并入邻近同色块') +
        '　耗时 ' + ((Date.now() - t0) / 1000).toFixed(2) + 's');
    }
    if ($('fragHighlight') && $('fragHighlight').checked) draw();
  }

  /**
   * 渲染碎色面板。给美术的信息按「先看结论、再看该修哪里」排：
   *   达标与否 → 差多少 → 至少要救回多少像素 → 哪个颜色最碎 → 该等级的线上表现参考。
   */
  function renderFragPanel() {
    var box = $('fragInfo'), pcBox = $('fragPerColor');
    if (!box) return;
    var frag = fragState.result, a = fragState.assess;
    if (!frag || !a) { box.innerHTML = '<div class="muted">点「重新计算」查看当前目标图的碎色率</div>'; if (pcBox) pcBox.innerHTML = ''; return; }
    var it = cur();
    var otherLevel = it && fragState.key && it.key !== fragState.key;
    var staleTag = otherLevel
      ? '<span class="tag warn">这是「' + fragState.key + '」的结果，不是当前关卡</span>'
      : (fragState.stale ? '<span class="tag warn">目标图已改动，数值已过期</span>' : '');
    var verdict = a.pass
      ? '<span class="tag ok">达标</span> 已在阈值 ' + a.limitPct + '% 以内'
      : '<span class="tag warn">超标</span> 超出阈值 ' + a.gapPp + ' 个百分点';
    var rows = [
      ['碎色率', '<b style="font-size:15px" class="' + a.gradeCls + '">' + a.ratePct + '%</b>　等级 <b class="' +
        a.gradeCls + '">' + a.grade + '</b>　' + verdict + (staleTag ? '<br>' + staleTag : '')],
      ['该改到什么程度', a.pass
        ? '当前已达标，无需为碎色率继续修改。'
        : '至少要把 <b>' + a.needFixPixels + '</b> 个碎色像素并入邻近同色块（把碎色像素数从 ' +
          frag.fragPixels + ' 降到 ' + a.allowFragPixels + ' 以内）。<br>' +
          '<span class="hint">这是下界：实际把一个孤立像素接到旁边的同色块上，常会连带把同簇的其它小块一起救回，' +
          '所以真正要动的像素通常比这个数少。改完点「重新计算」看最新值。</span>'],
      ['碎色构成', '孤立块(≤' + window.AntFragment.DEFAULTS.fragmentIsoMax + '像素) ' +
        (frag.isoRate * 100).toFixed(2) + '%　小色块(≤' + window.AntFragment.DEFAULTS.fragmentSmallMax + '像素) ' +
        (frag.smallRate * 100).toFixed(2) + '%　共 ' + frag.fragBlocks + ' 个碎块 / ' + frag.blocks + ' 个色块'],
      ['最碎的单色', frag.perColor.length
        ? '<i class="sw2" style="background:' + window.AntSolver.getColorCSS(frag.perColor[0].color) + '"></i> ' +
          window.AntSolver.getColorName(frag.perColor[0].color) + '(' + frag.perColor[0].color + ')　' +
          (frag.perColor[0].rate * 100).toFixed(1) + '% 碎（' + frag.perColor[0].frag + '/' + frag.perColor[0].total + ' 像素）'
        : '—'],
      ['碎色平均消除轮次', frag.avgFragDepth + ' / 全图 ' + frag.rounds + ' 轮' +
        '<br><span class="hint">碎色落在越靠后的消除轮次，越容易在后期把订单卡住。这一项只作观察记录，不参与达标判定。</span>'],
      ['该等级的线上表现（参考）', '差关率 ' + a.gradeStats.bad + '%　严重差关率 ' + a.gradeStats.severe +
        '%　好关率 ' + a.gradeStats.good + '%' +
        '<br><span class="hint">来自 08-24 对上线 345 关的现象观察（按碎色率五等分）。' +
        '这是<b>相关性观察</b>，不是"碎色导致差关"的因果结论——差关成因是多维的，碎色只是其中一个可观测现象。</span>'],
      ['阈值来源', '<b>18%（当前采用）</b>：与生产端碎色闸门是同一个值，这里达标的图生产时不会因碎色被卡。' +
        '<br>11.47% = 新口径下按碎色率四等分后<b>好关率最高那一档(Q1)</b>的上界（好关率 32.6%、严重差关率 3.5%）。' +
        '<br>10.54% = 新口径五等分最整档上界（严重差关率仅 1.5%）。' +
        '<br>18.79% / 20.47% = 旧口径（小色块≤10）时期的 Q2 上界与差关率断点，保留为备选。' +
        '<br><span class="hint">⚠ 2026-08-25 小色块判定放宽到「小于 8 像素」后，同一张图的碎色率' +
        '比之前低约 <b>4.3 个百分点</b>（344 关实测中位 18.92% → 14.53%），' +
        '所以 <b>18% 在新口径下比较宽松</b>：放过约 79% 的图，过闸集的好关率 28.7% 已接近全样本基础率 27.0%。' +
        '想要原来那种筛选强度，选 11.47%。' +
        '<br>口径与生产端<b>同源</b>（js/fragment.js 直接调用 bin/js/generator.js 的同一个函数），' +
        '两边算出来的碎色率必然是同一个数。</span>']
    ];
    box.innerHTML = kvTable(rows);

    if (pcBox) {
      var top = frag.perColor.filter(function (x) { return x.frag > 0; }).slice(0, 10);
      // 2026-08-25 起分色明细与画布高亮都取自正式函数的块级明细，与碎色率同口径
      //   （此前是包装层按块大小近似，会把视觉上连续的条带误标，用户实机发现后已修）。
      var apNote = frag.detailUnavailable
        ? '<div class="hint">⚠ 当前 bin 副本版本较旧，取不到块级明细，分色明细与高亮暂不可用。' +
          '请按 <code>关卡图修改工具/bin/来源说明.md</code> 重拷一次 bin 副本。</div>'
        : '<div class="hint">分色明细与画布高亮与上方碎色率<b>同口径</b>：已经把"靠得够近、' +
          '并簇后总量够大"的小块救回了，所以这里标出来的都是<b>正式判定为碎色</b>的像素，' +
          '视觉上连续的条带不会被误标。</div>';
      pcBox.innerHTML = top.length
        ? '<div class="editSubhead">分色碎色明细（碎色率降序，先修排在前面的）</div>' + apNote +
          top.map(function (x) {
            return '<div class="closeHit"><i class="sw2" style="background:' + window.AntSolver.getColorCSS(x.color) + '"></i> ' +
              window.AntSolver.getColorName(x.color) + '(' + x.color + ')　碎 ' + x.frag + ' / 共 ' + x.total +
              ' 像素　<b>' + (x.rate * 100).toFixed(1) + '%</b></div>';
          }).join('')
        : '<div class="muted">没有碎色像素</div>';
    }
  }

  /**
   * 汇总刷新编辑相关的全部面板（每次改色/替换/框选变化后统一调用）。
   * 色库的「已有颜色 / 未使用颜色」分组就在 renderEditPalette 里重新识别，
   * 所以只要走到这里，分组一定跟着目标图当前内容刷新（需求 08.03 §二.3）。
   * 原来的「当前目标图颜色」独立面板已按需求删除，其全局替换入口搬进了色库边框内。
   */
  function refreshEditPanels() {
    renderEditPalette();
    renderSelectionColorsPanel();
    renderCloseCheckPanels();
    renderExtractPanel();
    // 碎色率不跟着每次落笔重算：55×55 全图一次约 0.1~0.3s（含消除轮次），
    //   拖动绘制时逐格重算会明显卡手。改为标记「已过期」，由用户点「重新计算」或松开笔刷后手动触发。
    markFragStale();
  }

  function toggleEditMode(on) {
    var it = cur();
    S.edit.on = on;
    $('cv').classList.toggle('editing', on);
    if (!it) return;
    if (on) {
      if (!S.edit.original) S.edit.original = JSON.parse(JSON.stringify(it.blocks));
      demoPause();
      if (S.viewMode !== 'before') { S.viewMode = 'before'; var r0 = document.querySelector('input[name="viewMode"][value="before"]'); if (r0) r0.checked = true; }
      var toolCN = { paint: '拖动绘制', select: '矩形框选', lasso: '套索', region: '同色块', color: '按色选' };
      log('编辑模式已开启：当前工具「' + (toolCN[S.edit.tool] || S.edit.tool) + '」，当前颜色 ' +
        window.AntSolver.getColorName(S.edit.color) + '(' + S.edit.color + ')');
    } else {
      S.edit.dragging = false; S.edit.paintDragging = false; S.edit.replacing = null;
      S.edit.lassoPath = null;
      renderReplaceStatus();
      log('编辑模式已关闭');
    }
    syncCanvasToolClass();
    refreshEditPanels();
    draw();
  }

  /** 点选/框选内绘制的批量应用：记一次撤销批次，刷新画面与统计。 */
  function editApplyColor(cells) {
    var it = cur();
    if (!it || !cells.length) return;
    var batch = [];
    for (var i = 0; i < cells.length; i++) {
      var r = cells[i].r, c = cells[i].c;
      var before = it.blocks[r][c];
      if (before === S.edit.color) continue;
      it.blocks[r][c] = S.edit.color;
      batch.push({ r: r, c: c, before: before, after: S.edit.color });
    }
    if (batch.length) {
      S.edit.undoStack.push(batch);
      it._editedAt = new Date().toISOString();   // 记录修改时间，供待导出库与导出包注明
      $('btnEditUndo').disabled = false;
      $('btnEditReset').disabled = false;
      draw();
      renderEditInfo();
      refreshEditPanels();
    }
  }

  /**
   * 进入替换流程：记住要替换哪个颜色（全局或选区内），等待用户在色库里点目标色完成替换。
   * 再点同一个替换按钮 = 取消（切换语义），避免误触后卡在待替换状态。
   */
  function startColorReplace(scope, oldId) {
    if (!cur()) return;
    var rp = S.edit.replacing;
    if (rp && rp.scope === scope && rp.oldId === oldId) { cancelColorReplace('再次点击同一个替换按钮'); return; }
    S.edit.replacing = { scope: scope, oldId: oldId };
    log((scope === 'global' ? '整图替换' : '选区内替换') + '：请点击你要换成的颜色，把 ' +
      window.AntSolver.getColorName(oldId) + '(' + oldId + ') 换掉。' +
      '不想换了就点空白处、按 Esc、或再点一次这个替换按钮。');
    renderReplaceStatus();
    refreshEditPanels();
  }

  /**
   * 取消待替换状态（用户 2026-08-03 微调第 2 项）。
   * 触发方式有四种：点空白处、点目标图、按 Esc、再点一次同一个替换按钮。
   * 取消不产生任何像素改动，因此**不需要用撤销来回退**——这正是本次要解决的问题。
   */
  function cancelColorReplace(how) {
    if (!S.edit.replacing) return;
    var old = S.edit.replacing.oldId;
    S.edit.replacing = null;
    renderReplaceStatus();
    refreshEditPanels();
    log('已取消替换 ' + window.AntSolver.getColorName(old) + '(' + old + ')' +
      (how ? '（' + how + '）' : '') + '，目标图没有任何改动。');
  }

  /** 待替换状态条：把「现在正等你点目标色」这件事显式摆出来，并给一个取消按钮。 */
  function renderReplaceStatus() {
    var box = $('editReplaceStatus');
    if (!box) return;
    var rp = S.edit.replacing;
    if (!rp) { box.style.display = 'none'; box.innerHTML = ''; return; }
    var name = window.AntSolver.getColorName(rp.oldId);
    box.style.display = '';
    box.innerHTML = '<i class="sw2" style="background:' + window.AntSolver.getColorCSS(rp.oldId) + '"></i>' +
      '<span>正在' + (rp.scope === 'global' ? '整图替换' : '选区内替换') + '：' + name + '(' + rp.oldId + ')' +
      '　请点击你要换成的颜色</span>' +
      '<button id="btnCancelReplace" class="btn tiny">取消替换</button>' +
      '<span class="muted">也可以点空白处或按 Esc 取消</span>';
    var b = $('btnCancelReplace');
    if (b) b.onclick = function (ev) { ev.stopPropagation(); cancelColorReplace('点了取消按钮'); };
  }

  /** 完成替换：把 replacing.oldId 替换为 newId（全局或仅选区内），记一次撤销批次。 */
  function performColorReplace(newId) {
    var it = cur();
    var rp = S.edit.replacing;
    if (!it || !rp) return;
    if (newId === rp.oldId) { cancelColorReplace('点回了原来那个颜色'); return; }   // 点回原色 = 取消
    // 走 selCells()（掩码）而不是外接矩形：套索/同色块的选区是不规则的，
    // 按矩形替换会连「矩形内但选区外」的像素一起改掉。
    var cells = rp.scope === 'selection' ? selCells() : null;   // null = 全局（内部遍历全图）
    var result = C.replaceColorInBlocks(it.blocks, rp.oldId, newId, cells);
    if (result.count > 0) {
      var batch = result.cells.map(function (p) { return { r: p.r, c: p.c, before: rp.oldId, after: newId }; });
      S.edit.undoStack.push(batch);
      $('btnEditUndo').disabled = false;
      $('btnEditReset').disabled = false;
      log((rp.scope === 'global' ? '全局' : '选区内') + '替换完成：' + window.AntSolver.getColorName(rp.oldId) + '(' + rp.oldId + ') → ' +
        window.AntSolver.getColorName(newId) + '(' + newId + ')，共 ' + result.count + ' 像素');
    } else {
      log('替换范围内没有找到该颜色，未作改动');
    }
    S.edit.replacing = null;
    renderReplaceStatus();
    draw();
    renderEditInfo();
    refreshEditPanels();
  }

  function editUndo() {
    var it = cur();
    if (!it || !S.edit.undoStack.length) return;
    var batch = S.edit.undoStack.pop();
    for (var i = 0; i < batch.length; i++) it.blocks[batch[i].r][batch[i].c] = batch[i].before;
    $('btnEditUndo').disabled = S.edit.undoStack.length === 0;
    draw();
    renderEditInfo();
    refreshEditPanels();
  }

  function editReset() {
    var it = cur();
    if (!it || !S.edit.original) return;
    it.blocks = JSON.parse(JSON.stringify(S.edit.original));
    S.edit.undoStack = [];
    clearSelection(); S.edit.replacing = null;
    $('btnEditUndo').disabled = true;
    draw();
    renderEditInfo();
    refreshEditPanels();
    log('已还原为原图');
  }

  /** 清除选区（不撤销已做的像素改动，只是取消框选范围本身）。 */
  function editClearSelection() {
    // 必须走 clearSelection() 一并清掉 mask —— 只清 selection(外接矩形) 会留下掩码，
    // 界面上选区消失了但「只在选区内绘制」「剔除」仍按旧掩码生效，是很难查的错。
    clearSelection();
    S.edit.replacing = null;
    draw();
    refreshEditPanels();
  }

  /**
   * 编辑改动统计（已改动像素 / 总量守恒 / 逐色变化）。
   * 用户 2026-08-03 微调：这块固定放在目标图右侧的位置，可点「悬浮」拖到任意位置；提示文字按要求去掉。
   * 逐色变化按要求带上中文颜色名（凡是出现颜色数量的地方都必须能看出是哪个颜色）。
   */
  function renderEditInfo() {
    var it = cur();
    var box = $('editInfo');
    if (!box) return;
    if (!it || !S.edit.original) { box.innerHTML = '<div class="muted">还没有改动。</div>'; return; }
    var d = C.diffBlocks(S.edit.original, it.blocks);
    var rows = [
      ['已改动像素', d.changedPixelCount + ' 个'],
      ['总量守恒', d.totalConserved ? '<span class="tag ok">守恒</span> ' + d.totalBefore + ' → ' + d.totalAfter
        : '<span class="tag warn">不一致</span> ' + d.totalBefore + ' → ' + d.totalAfter]
    ];
    var perColorLines = [];
    Object.keys(d.perColor).forEach(function (k) {
      var pc = d.perColor[k];
      if (pc.delta === 0) return;
      perColorLines.push('<i class="sw2" style="background:' + window.AntSolver.getColorCSS(+k) + '"></i> ' +
        window.AntSolver.getColorName(+k) + '(' + k + ')：' + pc.before + '→' + pc.after +
        '（' + (pc.delta > 0 ? '+' : '') + pc.delta + '）');
    });
    if (perColorLines.length) rows.push(['逐色变化', perColorLines.join('<br>')]);
    box.innerHTML = kvTable(rows);
  }

  function exportEditedTxt() {
    var it = cur();
    if (!it || !it.blocks) { log('没有可导出的目标图'); return; }
    var txt = C.serializeTxt(it.blocks);
    download(it.key + (S.edit.original ? '_已修改' : '') + '.txt', new Blob([txt], { type: 'text/plain' }));
    log('已导出目标图 TXT' + (S.edit.original ? '（含改动）' : ''));
  }

  function exportEditReport() {
    var it = cur();
    if (!it || !S.edit.original) { log('尚未做任何编辑，无对比可导出'); return; }
    var d = C.diffBlocks(S.edit.original, it.blocks);
    var lines = [
      '# ' + it.key + ' 美术编辑对比报告',
      '',
      '- 已改动像素：' + d.changedPixelCount + ' 个',
      '- 总量守恒：' + (d.totalConserved ? '守恒（' + d.totalBefore + ' → ' + d.totalAfter + '）' : '不一致（' + d.totalBefore + ' → ' + d.totalAfter + '）'),
      '- 重构策略：本版本（阶段二基础版）未接入自动重构，改动只落在目标图 TXT',
      '',
      '## 逐色变化',
      ''
    ];
    Object.keys(d.perColor).forEach(function (k) {
      var pc = d.perColor[k];
      // 报告里凡是出现颜色数量的地方都带上中文颜色名（用户 2026-08-03 微调第 6 项）
      lines.push('- ' + colorLabel(+k) + '：' + pc.before + ' → ' + pc.after + '（' + (pc.delta > 0 ? '+' : '') + pc.delta + '）');
    });
    lines.push('', '## 改动像素坐标（行,列：原色→新色）', '');
    d.changedPixels.forEach(function (p) {
      lines.push('- (' + p.r + ',' + p.c + ')：' + colorLabel(p.from) + ' → ' + colorLabel(p.to));
    });
    download(it.key + '_编辑对比报告.md', new Blob([lines.join('\n') + '\n'], { type: 'text/markdown' }));
    log('已导出编辑对比报告');
  }

  // ==================== 完整导出打包（ZIP） ====================
  // bin/js/zip.js（AntSolver.Zip）只支持纯文本条目（内部用 TextEncoder 编码），
  // 完整导出需要打包 PNG（二进制），故本工具自行实现一个同样走 store（不压缩）格式的二进制 ZIP 打包函数。
  // 这不是游戏算法，是通用的归档打包工具，写在 app.js 里（只在页面用，不需要放进 core.js 的口径层）。
  // ZIP 格式与 bin/js/zip.js 完全一致（本地文件头 + 中央目录 + EOCD，CRC32 表也用同一套标准算法），
  // 唯一区别是条目内容既支持字符串（自动转 UTF-8 字节）也支持 Uint8Array（PNG 等二进制直接收）。

  var ZIP_CRC_TABLE = (function () {
    var t = new Uint32Array(256);
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[n] = c >>> 0;
    }
    return t;
  })();
  function zipCrc32(bytes) {
    var c = 0xFFFFFFFF;
    for (var i = 0; i < bytes.length; i++) c = ZIP_CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }
  /** files: [{name, bytes:Uint8Array}] 或 [{name, text:string}]（二选一） */
  function zipCreateBinary(files) {
    var chunks = [], central = [], offset = 0;
    files.forEach(function (f) {
      var nameBytes = new TextEncoder().encode(f.name);
      var data = f.bytes ? f.bytes : new TextEncoder().encode(f.text || '');
      var crc = zipCrc32(data), size = data.length;
      var lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true);
      lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true);
      lh.setUint16(8, 0, true); lh.setUint16(10, 0, true); lh.setUint16(12, 0, true);
      lh.setUint32(14, crc, true); lh.setUint32(18, size, true); lh.setUint32(22, size, true);
      lh.setUint16(26, nameBytes.length, true); lh.setUint16(28, 0, true);
      chunks.push(new Uint8Array(lh.buffer), nameBytes, data);

      var ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true);
      ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true);
      ch.setUint16(10, 0, true); ch.setUint16(12, 0, true); ch.setUint16(14, 0, true);
      ch.setUint32(16, crc, true); ch.setUint32(20, size, true); ch.setUint32(24, size, true);
      ch.setUint16(28, nameBytes.length, true); ch.setUint16(30, 0, true); ch.setUint16(32, 0, true);
      ch.setUint16(34, 0, true); ch.setUint16(36, 0, true); ch.setUint32(38, 0, true);
      ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), nameBytes);
      offset += 30 + nameBytes.length + size;
    });
    var centralSize = central.reduce(function (s, a) { return s + a.length; }, 0);
    var eocd = new DataView(new ArrayBuffer(22));
    eocd.setUint32(0, 0x06054b50, true);
    eocd.setUint16(4, 0, true); eocd.setUint16(6, 0, true);
    eocd.setUint16(8, files.length, true); eocd.setUint16(10, files.length, true);
    eocd.setUint32(12, centralSize, true); eocd.setUint32(16, offset, true);
    eocd.setUint16(20, 0, true);
    return new Blob(chunks.concat(central, [new Uint8Array(eocd.buffer)]), { type: 'application/zip' });
  }

  /** 把当前 canvas 的当前画面转成 PNG 的 Uint8Array（供打包用；比 toBlob 更方便同步收集多张图）。 */
  function canvasToPngBytes(cv) {
    return new Promise(function (resolve) {
      cv.toBlob(function (blob) {
        var reader = new FileReader();
        reader.onload = function () { resolve(new Uint8Array(reader.result)); };
        reader.readAsArrayBuffer(blob);
      });
    });
  }

  /**
   * 完整导出：一关的全部内容打包成 ZIP，目录按「给游戏用」和「给工具用」分开
   * （需求 §七第5点：明确区分正式游戏端关卡文件与工具内部关卡数据）。
   *   正式游戏端关卡文件/：原关卡_官方格式.json、新关卡_官方格式.json（可直接进游戏端）
   *   工具内部数据/：原关卡_内部结构.json、新关卡_内部结构.json、原求解数据、新求解数据
   *   目标图/：原图.txt、新图.txt
   *   对比/：暂存压力图.png、进度区域专用对比图.png、对比分析报告.md
   * 工具内部数据里的 TXT/关卡/求解数据字段与本工具的导入格式一致，可直接重新导入核验。
   */
  function exportFullPackage() {
    var it = cur();
    if (!it || !it.reconResult || !it.reconResult.ok) { log('需要先重构成功才能导出完整对比包'); return; }
    var rr = it.reconResult;
    if (!rr.tl) rr.tl = C.reconstructToTimeline(rr);
    busy(true); overlay(true, '打包中…');
    var oldBlocksForTxt = S.edit.original || it.blocks;

    Promise.resolve().then(function () {
      var files = [];

      // 正式游戏端关卡文件（可直接进游戏端）与工具内部数据分开放，避免拿错文件（需求 §七第5点）
      files.push({ name: '正式游戏端关卡文件/说明.txt',
        text: '这个目录里的 JSON 是正式游戏端格式的关卡文件，可以直接交给游戏端使用。\n' +
              '工具内部结构（带完整棋盘、便于重新导入本工具继续修改）放在「工具内部数据」目录，两者不要混用。\n' });
      if (it.level) files.push({ name: '正式游戏端关卡文件/原关卡_官方格式.json', text: JSON.stringify(C.toGameFormatLevel(it.level), null, 1) });
      files.push({ name: '正式游戏端关卡文件/新关卡_官方格式.json', text: JSON.stringify(C.toGameFormatLevel(rr.level), null, 1) });

      // 目标图/
      files.push({ name: '目标图/原图.txt', text: C.serializeTxt(oldBlocksForTxt) });
      files.push({ name: '目标图/新图.txt', text: C.serializeTxt(rr.level.blocks) });

      // 工具内部数据/
      if (it.level) files.push({ name: '工具内部数据/原关卡_内部结构.json', text: JSON.stringify(it.level, null, 1) });
      files.push({ name: '工具内部数据/新关卡_内部结构.json', text: JSON.stringify(rr.level, null, 1) });
      if (it.tl) {
        files.push({ name: '工具内部数据/原求解数据.solve.json', text: JSON.stringify({
          meta: { sourceName: it.key, note: '基于正式关卡 JSON 重新求解/回放的标准复核路线' },
          summary: { completed: it.tl.completed, steps: it.tl.steps_count, totalBoxes: it.tl.totalBoxes, totalPixels: it.tl.totalPixels },
          pickOrder: it.tl.steps.map(function (s) { return { step: s.step, r: s.r, c: s.c, color: s.color, count: s.count }; })
        }, null, 1) });
      }
      if (rr.solveResult && rr.solveResult.pickOrder) {
        files.push({ name: '工具内部数据/新求解数据.solve.json', text: JSON.stringify({
          meta: { sourceName: it.key + '_重构后', strategy: rr.strategy, note: '重构后关卡的标准复核路线' },
          summary: { completed: true, steps: rr.solveResult.steps, totalBoxes: rr.solveResult.totalBoxes, totalPixels: rr.solveResult.totalPixels },
          pickOrder: rr.solveResult.pickOrder
        }, null, 1) });
      }
      // 玩家结果与生效参数（批量包里也有同名文件，两处口径一致）
      files.push({ name: '工具内部数据/玩家结果对比.json', text: JSON.stringify({
        说明: '原关卡为固定种子单次；重构后为生成器内部正式单次 + 多轮随机种子。playerHealth 为玩家模拟有效性检查结果。',
        before: it._playerOne || null,
        afterOfficial: rr.playerOfficial || null,
        // 只导出摘要，不导出每一拍的暂存轨迹（那份数据是画图用的，几万个数字对报告没有意义）
        afterMulti: C.stripPlayerTraces(rr.playerMulti) || null,
        playerHealth: rr.playerHealth || null
      }, null, 1) });
      files.push({ name: '生效的生成器参数.json', text: JSON.stringify({
        方案文件: (rr.genParamsUsed && rr.genParamsUsed.fileName) || '未导入方案（使用工具默认参数）',
        原始识别参数: (rr.genParamsUsed && rr.genParamsUsed.recognized) || null,
        未识别字段: (rr.genParamsUsed && rr.genParamsUsed.unrecognized) || [],
        字段冲突: (rr.genParamsUsed && rr.genParamsUsed.conflicts) || [],
        最终采用参数说明: '网页方案文件的正式生效参数以 config 为准，inputs 只是页面历史输入记录，不参与生成。',
        生成器实际生效参数: rr.effectiveConfig || null,
        暂存上限说明: '暂存上限是玩法固定口径 ' + C.BUFFER_LIMIT + '，方案给了不同值也不采用。',
        障碍参数核对: rr.obstacleCheck || null,
        障碍参数容差说明: C.OBSTACLE_TOLERANCE_NOTE,
        重构方式: RECON_STRATEGY_NAME,
        目标图修改时间: it._editedAt || null,
        重构时间: rr.reconstructedAt || null,
        版本说明: TOOL_VERSION_NOTE
      }, null, 1) });

      // 对比分析报告.md（先文本部分，图片异步后追加）
      // 报告直接写全所有指标，不让读者「详见页面某个表」。
      // 数据来自 collectCompareMetrics —— 与页面对比表同一个来源，两处结论不会各算一套。
      var m = collectCompareMetrics(it);
      var reportLines = [
        '# ' + it.key + ' 修改前后对比分析报告', '',
        '- 重构方式：' + RECON_STRATEGY_NAME + '（2026-07-31 起只保留此一种）',
        '- 目标图修改时间：' + (it._editedAt || '本次未在美术编辑里改色'),
        '- 重构时间：' + (rr.reconstructedAt || '—'),
        '- 版本说明：' + TOOL_VERSION_NOTE,
        '',
        '## 用户选择的进度区间与实际吸附区间',
        it.interval ? ('- 要求：' + it.interval.requested.lo + '%–' + it.interval.requested.hi + '%，实际：' +
          it.interval.snapped.lo + '%–' + it.interval.snapped.hi + '%') : '- 未定位区间',
        '', '## 方案参数',
        '- 方案文件：' + (rr.genParamsUsed && rr.genParamsUsed.fileName ? rr.genParamsUsed.fileName : '未导入方案（使用工具默认参数）')
      ];
      if (rr.genParamsUsed && rr.genParamsUsed.unrecognized && rr.genParamsUsed.unrecognized.length) {
        reportLines.push('- 未识别字段（如实列出，未参与生成）：' + rr.genParamsUsed.unrecognized.join('、'));
      }
      if (rr.genParamsUsed && rr.genParamsUsed.conflicts && rr.genParamsUsed.conflicts.length) {
        reportLines.push('- 字段冲突（正式生效值一律取 config，历史输入值不参与生成）：');
        rr.genParamsUsed.conflicts.forEach(function (x) {
          reportLines.push('  - ' + x.paramKey + '：历史输入值 ' + x.inputValue + ' → 正式生效值 ' + x.configValue);
        });
      }
      if (rr.effectiveConfig) {
        var ec = rr.effectiveConfig;
        reportLines.push('- 生成器实际生效参数：底部消除 ' + (ec.bottomOnly ? '开启' : '关闭') +
          '，盒容量 ' + ec.boxSizeMin + '–' + ec.boxSizeMax + '，暂存 ' + ec.bufferLimit +
          '，黑块 ' + ec.blackPercent + '%，冰块 ' + ec.icePercent + '%，锁链 ' + ec.chainCount +
          '，问号 ' + ec.questionPercent + '%，棋盘范围 ' + ec.boardRowsMin + '–' + ec.boardRowsMax +
          ' 行 × ' + ec.boardColsMin + '–' + ec.boardColsMax + ' 列，窄路缺口 ' +
          ec.narrowPathGapsMin + '–' + ec.narrowPathGapsMax);
      }
      if (rr.board) {
        var bb = rr.board;
        reportLines.push('', '## 重构后棋盘实况',
          '- 棋盘：' + bb.rows + ' 行 × ' + bb.cols + ' 列，共 ' + bb.capacity + ' 格' +
          '（列-行=' + bb.shapeDiff + '，' + (bb.shapeOk ? '形态合规' : '**形态不合规**') + '）',
          '- 构成：盒 ' + bb.boxCells + '，黑块 ' + bb.blackCells + '，管道 ' + bb.pipeCells + '，空格 ' + bb.emptyCells);
      }
      // 黑块不再单独写一行，改为并入障碍参数核对表（目标/实际/偏差/容差判定，含容差来源）
      obstacleCheckMarkdown(rr.obstacleCheck).forEach(function (l) { reportLines.push(l); });
      if (rr.playerHealth && !rr.playerHealth.ok) {
        reportLines.push('', '## ⚠ 玩家验证接口异常',
          '- ' + rr.playerHealth.detail,
          '- 本次玩家相关数值不可用，不能据此判断关卡难度，也不得视为「0% 通关率」。');
      } else if (rr.playerMulti) {
        reportLines.push('', '## 多轮玩家验证（随机种子）', '',
          '| 种子 | 是否通关 | 暂存峰值 | 复活次数/上限 | 完成盒数/总盒数 |', '| --- | --- | --- | --- | --- |');
        rr.playerMulti.rounds.forEach(function (x) {
          if (x.error) { reportLines.push('| ' + x.seed + ' | 本轮异常 | — | — | — |'); return; }
          reportLines.push('| ' + x.seed + ' | ' + (x.won ? '通关' : '未通关') + ' | ' + x.bufferPeak +
            ' | ' + x.revivesUsed + '/' + x.reviveCap + ' | ' + x.completedBoxes + '/' + x.totalBoxes + ' |');
        });
        reportLines.push('', '- 总通关率：' + (rr.playerMulti.successRate * 100).toFixed(0) + '%（' + rr.playerMulti.roundCount + ' 轮）',
          '- 平均暂存峰值：' + rr.playerMulti.avgPeak,
          '- 平均复活次数：' + rr.playerMulti.avgRevives);
      }
      if (m) {
        reportLines.push('', '## 修改前后完整指标对比', '',
          '| 指标 | 修改前 | 重构后 |', '| --- | --- | --- |');
        m.rows.forEach(function (r) { reportLines.push('| ' + r.label + ' | ' + r.before + ' | ' + r.after + ' |'); });
        reportLines.push('', '## 守恒 / 结构 / 区域结论');
        Object.keys(m.extra).forEach(function (k) {
          reportLines.push('- ' + k.replace(/_/g, '·') + '：' + m.extra[k]);
        });
      }
      files.push({ name: '对比/对比分析报告.md', text: reportLines.join('\n') + '\n' });

      // 对比/*.png
      var pngPromises = [];
      pngPromises.push(canvasToPngBytes($('cvPressure')).then(function (bytes) { files.push({ name: '对比/暂存压力图.png', bytes: bytes }); }));
      // 进度区域专用对比图：用专门绘制的对比画布（需求 §七第1点），不再截取主画布 $('cv') 冒充。
      // 没做过区域对比时如实缺这张图，并在报告里说明原因，不拿别的图充数。
      var regionCv = buildRegionCompareCanvas(it);
      if (regionCv) {
        pngPromises.push(canvasToPngBytes(regionCv).then(function (bytes) { files.push({ name: '对比/进度区域专用对比图.png', bytes: bytes }); }));
      } else {
        files.push({ name: '对比/进度区域专用对比图_缺失说明.txt',
          text: '本次导出没有这张图：需要先定位进度区间，再点「对比当前区间（修改前后）」生成区域对比结果。\n' });
      }
      return Promise.all(pngPromises).then(function () { return files; });
    }).then(function (files) {
      var blob = zipCreateBinary(files);
      download(it.key + '_完整对比包_' + exportStamp() + '.zip', blob);
      busy(false); overlay(false);
      log('已导出完整对比包 ZIP（' + files.length + ' 个文件），可重新导入本工具核验新图/新关卡/新求解数据。');
    }).catch(function (e) {
      busy(false); overlay(false);
      log('导出失败：' + (e && e.message));
    });
  }

  // ==================== 待导出库（需求 07.30 §六） ====================
  // 加入/查看/重新编辑/持久化/单项移除/批量导出。只存纯 JSON 可序列化数据（关卡本体/目标图/pickOrder/
  // 参数摘要等），不存 canvas、DOM 元素等不可序列化对象；对比图 PNG 留到批量导出时才现场生成。

  /**
   * 读库 + 【历史条目迁移】。
   * 任务 ANT-ARTTOOL-FRAGMENT-QUOTA-20260825：老条目里存着 464 KB/条 的 `tickTrajectory`，
   * 不迁移的话即使新入库的条目已瘦身，整数组一写还是超限（save 是整数组覆盖写）。
   * 迁移只剥大数组、不动任何导出会用到的字段，且迁移后立刻回写一次。
   */
  function loadExportLibFromStorage() {
    try {
      var raw = localStorage.getItem(EXPORT_LIB_STORAGE_KEY);
      if (raw) S.exportLib = JSON.parse(raw) || [];
    } catch (e) { S.exportLib = []; log('待导出库读取失败（' + (e && e.message) + '），已重置为空'); return; }
    if (!S.exportLib.length) return;
    var before = JSON.stringify(S.exportLib).length;
    var migrated = 0;
    S.exportLib.forEach(function (e) {
      var hit = false;
      ['playerAfterOfficial', 'playerBefore'].forEach(function (k) {
        if (!e[k]) return;
        var heavy = (C.PLAYER_HEAVY_KEYS || []).some(function (hk) { return e[k][hk] && e[k][hk].length; });
        if (!heavy) return;
        e[k] = C.slimPlayerResult(e[k]);
        hit = true;
      });
      if (hit) migrated++;
    });
    if (migrated) {
      var after = JSON.stringify(S.exportLib).length;
      var r = saveExportLibToStorage();
      log('待导出库：已为 ' + migrated + ' 个历史条目剥掉逐 tick 轨迹等大数组（' +
        kb(before) + ' → ' + kb(after) + '，省 ' + Math.round((1 - after / before) * 100) + '%）。' +
        '导出内容不受影响（导出只用其中的通关/峰值/复活次数）。' + (r.ok ? '' : '⚠ 回写失败：' + r.error));
    }
  }

  function kb(chars) { return (chars / 1024).toFixed(0) + ' KB'; }

  /**
   * 写库。**返回写入结果而不是静默 log** —— 调用方必须据此决定要不要回滚内存。
   *
   * 原实现只 try/catch 打一行日志、不回滚：写失败时内存里那条已经 push 进去了，
   * 列表照常显示「已加入，当前共 6 关」，用户以为成功，但 localStorage 里还是上一次成功的 5 关，
   * **刷新后那条静默消失**。而且因为是整数组覆盖写，一旦超限，后续任何更新都会持续失败。
   * 这是本次「攒够 5 个就加不进去」体验最恶劣的一半，必须一起修。
   */
  function saveExportLibToStorage() {
    try {
      localStorage.setItem(EXPORT_LIB_STORAGE_KEY, JSON.stringify(S.exportLib));
      return { ok: true };
    } catch (e) {
      return { ok: false, error: (e && e.message) || String(e), quota: !!(e && /quota/i.test(e.name + ' ' + e.message)) };
    }
  }

  /** 当前库占用（字符数）。用于在列表上如实显示水位，别等爆了才知道。 */
  function exportLibBytes() {
    try { return JSON.stringify(S.exportLib).length; } catch (e) { return 0; }
  }

  /**
   * 添加/更新待导出库条目（需求 §六.1/§六.2）：只有重构通过验证（it.reconResult.ok）才能加入；
   * 同一原关卡（用 key 判重）再次加入时更新原条目，不生成重复副本。
   */
  function addCurrentToExportLibrary() {
    var it = cur();
    if (!it || !it.reconResult || !it.reconResult.ok) { log('需要先重构成功并通过验证才能加入待导出库'); return; }
    var rr = it.reconResult;
    if (!rr.tl) rr.tl = C.reconstructToTimeline(rr);
    var entry = {
      key: it.key,                                             // 原关卡标识
      sourceFiles: { txtName: it.txtName || null, levelName: it.levelName || null, solveName: it.solveName || null },
      originalBlocks: S.edit.original || it.blocks,             // 原目标图（编辑前快照；未编辑过时就是当前图）
      editedBlocks: it.blocks,                                  // 修改后目标图
      originalLevel: it.level,                                  // 原关卡（工具内部无损数据）
      reconstructedLevel: rr.level,                             // 重构后关卡（工具内部无损数据）
      strategy: rr.strategy,
      genParamsUsed: rr.genParamsUsed || null,                  // 使用的生成器参数（识别到的字段）
      effectiveConfig: rr.effectiveConfig || null,              // 实际生效参数
      originalPickOrder: it.tl ? it.tl.steps.map(function (s) { return { step: s.step, r: s.r, c: s.c, color: s.color, count: s.count }; }) : null,
      reconstructedPickOrder: rr.solveResult && rr.solveResult.pickOrder ? rr.solveResult.pickOrder : null,
      interval: it.interval ? { requested: it.interval.requested, snapped: it.interval.snapped } : null,
      pressureBefore: it.pressureCurve ? { peak: it.pressureCurve.peak, avg: it.pressureCurve.avg } : null,
      pressureAfter: rr.pressureCurve ? { peak: rr.pressureCurve.peak, avg: rr.pressureCurve.avg } : null,
      // 单次玩家结果入库前剥掉逐步大数组（任务 ANT-ARTTOOL-FRAGMENT-QUOTA-20260825）。
      //   `playerAfterOfficial` 来自 generationEval.player，自带 464 KB 的 tickTrajectory；
      //   `playerBefore` 走 officialPlayerResult 那条分支（关卡没带导入求解数据时）同样自带。
      //   两者都只被导出流程用来取 won/peak/revives/reviveCap 四个标量，剥掉不影响任何产物。
      playerBefore: C.slimPlayerResult(it._playerOne),
      playerAfterOfficial: C.slimPlayerResult(rr.playerOfficial),   // 生成器内部正式单次结果
      // 多轮随机种子结果（含逐轮明细）。逐步暂存轨迹只在内存里用来画玩家压力曲线，
      // 存进浏览器本地时剥掉，避免几关就把本地存储塞满。
      playerAfterMulti: C.stripPlayerTraces(rr.playerMulti) || null,
      playerHealth: rr.playerHealth || null,            // 玩家模拟有效性检查
      board: rr.board || null,                          // 重构后棋盘实况
      obstacleCheck: rr.obstacleCheck || null,          // 障碍参数目标/实际/偏差 + 容差判定
      // 进度区域专用对比图的原始数据（紧凑下标形式）。存数据而不存 PNG：PNG 转 base64 体积太大，
      // localStorage 装不下几关；批量导出时用这份数据离屏重绘同一张图。
      regionCompare: compactRegionCompare(it._lastRegionCompare, it._regionCompareMeta),
      validationStatus: (rr.playerHealth && !rr.playerHealth.ok) ? 'playerSimError' : 'ok',
      // 修改时间与重构时间分开记录（需求 §七第8点：列表与导出包需注明）
      editedAt: it._editedAt || null,
      reconstructedAt: rr.reconstructedAt || null,
      lastModified: new Date().toISOString()
    };
    // 写盘失败必须回滚内存，不能让 UI 显示"已加入"而实际没存（刷新就丢）。
    var idx = S.exportLib.findIndex(function (e) { return e.key === entry.key; });
    var prev = idx >= 0 ? S.exportLib[idx] : null;
    if (idx >= 0) S.exportLib[idx] = entry; else S.exportLib.push(entry);
    var res = saveExportLibToStorage();
    if (!res.ok) {
      // 回滚：更新则还原旧条目，新增则弹出
      if (idx >= 0) S.exportLib[idx] = prev; else S.exportLib.pop();
      saveExportLibToStorage();          // 把回滚后的状态写回去（此时体积没变大，应能成功）
      renderExportLibrary();
      log('⚠ 待导出库加入失败，已取消本次加入（内存与本地保存均未改变，避免刷新后静默丢失）。' +
        '原因：' + res.error +
        (res.quota
          ? '。这是浏览器本地存储容量上限（每个站点约 5 MB）。当前库 ' + S.exportLib.length + ' 关、占用 ' +
            kb(exportLibBytes()) + '。请先「批量导出」把已攒的关卡下载下来，再「清空待导出库」腾出空间。'
          : ''));
      return;
    }
    if (idx >= 0) log('待导出库：已更新原条目「' + entry.key + '」，当前共 ' + S.exportLib.length + ' 关（占用 ' + kb(exportLibBytes()) + '）');
    else log('待导出库：已加入「' + entry.key + '」，当前共 ' + S.exportLib.length + ' 关（占用 ' + kb(exportLibBytes()) + '）');
    renderExportLibrary();
  }

  function removeFromExportLibrary(key) {
    S.exportLib = S.exportLib.filter(function (e) { return e.key !== key; });
    var r = saveExportLibToStorage();
    renderExportLibrary();
    log('待导出库：已移除「' + key + '」' + (r.ok ? '' : '　⚠ 本地保存失败：' + r.error));
  }

  function clearExportLibrary() {
    S.exportLib = [];
    var r = saveExportLibToStorage();
    renderExportLibrary();
    log('待导出库已清空' + (r.ok ? '' : '　⚠ 本地保存失败：' + r.error));
  }

  /** 打开待导出库中的某一关继续编辑：定位到已导入的同名 item（若已在列表中），否则提示需要先导入该关。 */
  function openExportLibEntry(key) {
    var idx = -1;
    for (var i = 0; i < S.items.length; i++) if (S.items[i].key === key) { idx = i; break; }
    var ent = S.exportLib.filter(function (x) { return x.key === key; })[0] || null;
    if (idx < 0) {
      log('待导出库「' + key + '」对应的关卡不在当前导入列表中。刷新页面后需要重新导入该关的 TXT/关卡文件才能继续修图；' +
        '库里已保存的修改结果与重构结果不会丢失。');
      if (ent) renderExportLibEntryDetail(ent);
      return;
    }
    var it = S.items[idx];
    // 调取后把库里保存的「修改后目标图」恢复到画面上，让用户能接着改（需求 §七第2/3点）。
    // 但不自动重构、不自动导出：只有用户再次点「重新生成关卡」/「导出」才产生新结果（§七第4/5/6点）。
    if (ent && ent.editedBlocks && ent.editedBlocks.length) {
      if (!S.edit.original) S.edit.original = it.blocks.map(function (row) { return row.slice(); });
      it.blocks = ent.editedBlocks.map(function (row) { return row.slice(); });
    }
    select(idx);
    if (ent) renderExportLibEntryDetail(ent);
    log('已调取「' + key + '」并恢复库里保存的修改后目标图，可继续修图。' +
      '本次不会自动重新生成、也不会自动导出——需要新结果时请再点「重新生成关卡」，需要新导出包时再点导出。');
  }

  /** 调取待导出库条目后，展示该条目已保存的重构结果摘要（只读，不触发任何重算）。 */
  function renderExportLibEntryDetail(e) {
    var box = $('reconInfo');
    if (!box) return;
    var healthy = !e.playerHealth || e.playerHealth.ok;
    var pa = normalizePlayerResult(e.playerAfterOfficial);
    var rows = [
      ['来自待导出库', e.key + '（以下是库里已保存的结果，不是本次新生成的）'],
      ['重构方式', RECON_STRATEGY_NAME],
      ['验证状态', e.validationStatus],
      ['方案文件', (e.genParamsUsed && e.genParamsUsed.fileName) || '未导入方案（使用工具默认参数）'],
      ['修改时间', e.editedAt || '—'],
      ['重构时间', e.reconstructedAt || '—'],
      ['版本说明', TOOL_VERSION_NOTE]
    ];
    if (e.board) {
      rows.push(['重构后棋盘', e.board.rows + ' 行 × ' + e.board.cols + ' 列，共 ' + e.board.capacity + ' 格' +
        (e.board.shapeOk ? '' : '　<span class="tag warn">形态不合规</span>')]);
    }
    if (e.obstacleCheck) renderObstacleCheckRows(rows, e.obstacleCheck);
    else if (e.board) {
      // 07-31 整改前入库的老条目没有 obstacleCheck，如实说明而不是拿黑块一项冒充完整核对
      rows.push(['黑块比例', '目标 ' + (e.effectiveConfig ? e.effectiveConfig.blackPercent + '%' : '—') +
        '　实际 ' + e.board.blackCells + ' 格 = ' + e.board.blackPercent + '%' +
        '<br><span class="hint">这条记录是障碍参数核对上线前入库的，只有黑块一项；' +
        '需要完整核对请重新点「重新生成关卡」后再次加入待导出库。</span>']);
    }
    if (!healthy) {
      rows.push(['<span class="tag bad">玩家验证接口异常</span>', (e.playerHealth && e.playerHealth.detail) || '玩家数值不可用']);
    } else if (e.playerAfterMulti) {
      rows.push(['多轮玩家通关率', (e.playerAfterMulti.successRate * 100).toFixed(0) + '%（' +
        e.playerAfterMulti.roundCount + ' 轮）　平均峰值 ' + e.playerAfterMulti.avgPeak +
        '　平均复活 ' + e.playerAfterMulti.avgRevives]);
    } else if (pa) {
      rows.push(['玩家结果', (pa.won ? '通关' : '未通关') + '，峰值 ' + pa.peak + '，复活 ' + pa.revives + '/' + pa.reviveCap]);
    }
    rows.push(['提示', '继续修图后如需新的重构结果，请再点「重新生成关卡」；导出包不会自动生成，旧导出包也不会被覆盖。']);
    box.innerHTML = kvTable(rows);
  }

  function renderExportLibrary() {
    var infoBox = $('exportLibInfo'), listBox = $('exportLibList');
    // 如实显示占用水位（任务 ANT-ARTTOOL-FRAGMENT-QUOTA-20260825）：
    //   浏览器每站点约 5 MB，按 UTF-16 计费 ≈ 字符数 × 2。以前不显示，用户只能等爆了才发现。
    var chars = exportLibBytes();
    var usedMB = chars * 2 / 1024 / 1024;          // UTF-16 实际占用
    var LIMIT_MB = 5;
    var pct = Math.round(usedMB / LIMIT_MB * 100);
    var perEntry = S.exportLib.length ? chars / S.exportLib.length : 0;
    var room = perEntry > 0 ? Math.max(0, Math.floor((LIMIT_MB * 1024 * 1024 / 2 - chars) / perEntry)) : '—';
    var lvl = pct >= 85 ? '<span class="tag warn">接近上限</span> ' : (pct >= 60 ? '<span class="tag">偏高</span> ' : '');
    infoBox.innerHTML = kvTable([
      ['当前待导出库', S.exportLib.length + ' 关（本地保存，刷新页面不丢失）'],
      ['本地存储占用', lvl + usedMB.toFixed(2) + ' MB / 约 ' + LIMIT_MB + ' MB（' + pct + '%）' +
        (S.exportLib.length ? '　单关约 ' + kb(perEntry) + '　按当前体积还能放约 ' + room + ' 关' : '') +
        '<br><span class="hint">上限是浏览器给每个站点的配额，不是本工具设的。快满时先「批量导出」下载，再「清空待导出库」。</span>']
    ]);
    if (!S.exportLib.length) { listBox.innerHTML = '<div class="item muted">暂无</div>'; return; }
    var h = S.exportLib.map(function (e) {
      return '<div class="item" data-key="' + e.key + '">' +
        '<label style="flex:0 0 auto"><input type="checkbox" class="libCheck" data-key="' + e.key + '"></label>' +
        '<span class="nm">' + e.key + '</span>' +
        '<span class="tag ok">' + e.strategy + '</span>' +
        '<button class="btn tiny libOpen" data-key="' + e.key + '">打开</button>' +
        '<button class="btn tiny ghost libRemove" data-key="' + e.key + '">移除</button>' +
        '</div>';
    }).join('');
    listBox.innerHTML = h;
    Array.prototype.forEach.call(listBox.querySelectorAll('.libOpen'), function (el) {
      el.onclick = function () { openExportLibEntry(el.getAttribute('data-key')); };
    });
    Array.prototype.forEach.call(listBox.querySelectorAll('.libRemove'), function (el) {
      el.onclick = function () { removeFromExportLibrary(el.getAttribute('data-key')); };
    });
  }

  /** 批量导出：把待导出库里选中的（或全部）条目逐关打包进同一个 ZIP，每关一个子目录。 */
  function exportLibraryBatch(onlyChecked) {
    var entries = S.exportLib;
    if (onlyChecked) {
      var checkedKeys = Array.prototype.filter.call(document.querySelectorAll('.libCheck'), function (el) { return el.checked; })
        .map(function (el) { return el.getAttribute('data-key'); });
      entries = S.exportLib.filter(function (e) { return checkedKeys.indexOf(e.key) >= 0; });
      if (!entries.length) { log('未勾选任何待导出库条目'); return; }
    }
    if (!entries.length) { log('待导出库为空'); return; }
    // 条目类型守卫（任务 ANT-ARTTOOL-SUBJECT-EXTRACT-20260902）。
    //   本工具自本轮起有两类条目：关卡条目（本库）与图纸条目（type='artPiece'，另一个 localStorage key）。
    //   两库物理隔离，正常使用下图纸进不了这里。但下面的打包逻辑**无条件**读
    //   `e.originalLevel` / `e.reconstructedLevel`，一旦有条目缺这两项（手改过 localStorage、
    //   旧版残留、或将来新增第三类条目），整次导出会带着一个看不懂的报错全挂。
    //   所以这里先筛一遍：能打包的照常，不能打包的**跳过并如实报出来**，不静默丢也不整批失败。
    var skipped = entries.filter(function (e) {
      return !e || e.type === C.ART_PIECE_TYPE || !e.originalLevel || !e.reconstructedLevel;
    });
    if (skipped.length) {
      entries = entries.filter(function (e) { return skipped.indexOf(e) < 0; });
      log('⚠ 跳过 ' + skipped.length + ' 个不是「关卡条目」的项：' +
        skipped.map(function (e) {
          return (e && e.key ? e.key : '(无名)') +
            (e && e.type === C.ART_PIECE_TYPE ? '(图纸条目，请用「12. 主体提取」里的导出图纸库)' : '(缺关卡数据)');
        }).join('、'));
      if (!entries.length) { log('筛掉之后没有可导出的关卡条目了'); return; }
    }
    busy(true); overlay(true, '批量打包中（' + entries.length + ' 关）…');
    var files = [];
    var pngPromises = [];
    var manifestRows = [['关卡名', '验证状态', '重构方式', '玩家通关率(重构后)', '暂存峰值(重构后)',
      '复活次数(重构后)', '棋盘与黑块', '障碍参数容差', '方案文件', '重构时间']];
    // ===== 分类汇总层（2026-08-05 需求）=====
    // 原实现只按 e.key 每关一个子目录，跨关没有归纳，取「所有新关卡」得逐个目录翻。
    // 这里在同一个 ZIP 内并列增加 汇总/ 一层：按数据类型跨关归并、新旧各自一个目录、
    // 文件名一律用【原关卡名】（不再是 新关卡_官方格式.json 这类固定名）。
    // 单关目录保持原样不动，便于逐关下钻与回溯；代价是包内文件数约翻倍（纯文本，压缩后可接受）。
    var DIGEST = '汇总/';
    function digest(sub, key, ext, text) {
      files.push({ name: DIGEST + sub + '/' + key + ext, text: text });
    }
    entries.forEach(function (e) {
      var dir = e.key + '/';
      // 各项内容只序列化一次，同时写进「单关目录」与「汇总层」，避免两处内容漂移。
      var txtOfficialOld = JSON.stringify(C.toGameFormatLevel(e.originalLevel), null, 1);
      var txtOfficialNew = JSON.stringify(C.toGameFormatLevel(e.reconstructedLevel), null, 1);
      var txtInnerOld = JSON.stringify(e.originalLevel, null, 1);
      var txtInnerNew = JSON.stringify(e.reconstructedLevel, null, 1);
      var txtMapNew = C.serializeTxt(e.editedBlocks);
      var txtMapOld = C.serializeTxt(e.originalBlocks);
      var txtPickOld = JSON.stringify(e.originalPickOrder || [], null, 1);
      var txtPickNew = JSON.stringify(e.reconstructedPickOrder || [], null, 1);
      var txtPlayerCmp = JSON.stringify({
        说明: '原关卡为固定种子单次；重构后为生成器内部正式单次 + 多轮随机种子。playerHealth 为玩家模拟有效性检查结果。',
        before: e.playerBefore || null,
        afterOfficial: e.playerAfterOfficial || null,
        afterMulti: e.playerAfterMulti || null,
        playerHealth: e.playerHealth || null
      }, null, 1);

      // 正式游戏端关卡文件（与工具内部无损数据明确区分，需求 §七第5点）
      files.push({ name: dir + '正式游戏端关卡文件/原关卡_官方格式.json', text: txtOfficialOld });
      files.push({ name: dir + '正式游戏端关卡文件/新关卡_官方格式.json', text: txtOfficialNew });
      // 工具内部无损数据
      files.push({ name: dir + '工具内部数据/原关卡_内部结构.json', text: txtInnerOld });
      files.push({ name: dir + '工具内部数据/新关卡_内部结构.json', text: txtInnerNew });
      // 修改后目标图 TXT
      files.push({ name: dir + '修改后目标图.txt', text: txtMapNew });
      files.push({ name: dir + '原目标图.txt', text: txtMapOld });
      // 求解与玩家结果
      files.push({ name: dir + '求解与玩家结果/原关卡pickOrder.json', text: txtPickOld });
      files.push({ name: dir + '求解与玩家结果/新关卡pickOrder.json', text: txtPickNew });
      files.push({ name: dir + '求解与玩家结果/玩家结果对比.json', text: txtPlayerCmp });

      // ---- 汇总层：按类型跨关归并，新旧分目录，文件名用原关卡名 ----
      digest('正式游戏端关卡文件/新关卡', e.key, '.json', txtOfficialNew);
      digest('正式游戏端关卡文件/原关卡', e.key, '.json', txtOfficialOld);
      digest('工具内部数据/新关卡', e.key, '.json', txtInnerNew);
      digest('工具内部数据/原关卡', e.key, '.json', txtInnerOld);
      digest('目标图/新关卡', e.key, '.txt', txtMapNew);
      digest('目标图/原关卡', e.key, '.txt', txtMapOld);
      digest('求解与玩家结果/新关卡pickOrder', e.key, '.json', txtPickNew);
      digest('求解与玩家结果/原关卡pickOrder', e.key, '.json', txtPickOld);
      digest('求解与玩家结果/玩家结果对比', e.key, '.json', txtPlayerCmp);

      // 生效的生成器参数
      var txtGenParams = JSON.stringify({
        方案文件: (e.genParamsUsed && e.genParamsUsed.fileName) || '未导入方案（使用工具默认参数）',
        原始识别参数: (e.genParamsUsed && e.genParamsUsed.recognized) || null,
        未识别字段: (e.genParamsUsed && e.genParamsUsed.unrecognized) || [],
        字段冲突: (e.genParamsUsed && e.genParamsUsed.conflicts) || [],
        最终采用参数说明: '网页方案文件的正式生效参数以 config 为准，inputs 只是页面历史输入记录，不参与生成。',
        生成器实际生效参数: e.effectiveConfig || null,
        暂存上限说明: '暂存上限是玩法固定口径 ' + C.BUFFER_LIMIT + '，方案给了不同值也不采用。',
        障碍参数核对: e.obstacleCheck || null,
        障碍参数容差说明: C.OBSTACLE_TOLERANCE_NOTE,
        重构方式: RECON_STRATEGY_NAME,
        修改时间: e.editedAt || null,
        重构时间: e.reconstructedAt || null,
        版本说明: TOOL_VERSION_NOTE
      }, null, 1);
      files.push({ name: dir + '生效的生成器参数.json', text: txtGenParams });
      digest('生效的生成器参数', e.key, '.json', txtGenParams);
      // 前后对比分析报告
      var pAfter = normalizePlayerResult(e.playerAfterOfficial);
      var pBefore = normalizePlayerResult(e.playerBefore);
      var healthy = !e.playerHealth || e.playerHealth.ok;
      var reportLines = [
        '# ' + e.key + ' 批量导出对比报告', '',
        '- 重构方式：' + RECON_STRATEGY_NAME,
        '- 验证状态：' + e.validationStatus,
        '- 方案文件：' + ((e.genParamsUsed && e.genParamsUsed.fileName) || '未导入方案（使用工具默认参数）'),
        '- 修改时间：' + (e.editedAt || '—'),
        '- 重构时间：' + (e.reconstructedAt || '—'),
        '- 条目最后更新：' + e.lastModified,
        '- 版本说明：' + TOOL_VERSION_NOTE,
        '- 进度区间：' + (e.interval ? (e.interval.requested.lo + '%-' + e.interval.requested.hi + '%') : '未定位'),
        '- 暂存峰值：修改前 ' + (e.pressureBefore ? e.pressureBefore.peak : '—') + ' → 重构后 ' + (e.pressureAfter ? e.pressureAfter.peak : '—')
      ];
      if (e.board) {
        reportLines.push('- 重构后棋盘：' + e.board.rows + ' 行 × ' + e.board.cols + ' 列，共 ' + e.board.capacity + ' 格' +
          '（列-行=' + e.board.shapeDiff + '，' + (e.board.shapeOk ? '形态合规' : '**形态不合规**') + '）',
          '- 棋盘构成：盒 ' + e.board.boxCells + '，黑块 ' + e.board.blackCells +
          '，管道 ' + e.board.pipeCells + '，空格 ' + e.board.emptyCells);
      }
      if (e.obstacleCheck) {
        obstacleCheckMarkdown(e.obstacleCheck).forEach(function (l) { reportLines.push(l); });
      } else if (e.board) {
        reportLines.push('- 黑块：目标 ' + (e.effectiveConfig ? e.effectiveConfig.blackPercent + '%' : '—') +
          '，实际 ' + e.board.blackCells + ' 格 = ' + e.board.blackPercent + '%',
          '- 说明：这条记录是障碍参数核对上线（2026-07-31）前入库的，只有黑块一项，没有冰块/问号/锁链的目标与实际对比。');
      }
      if (!healthy) {
        reportLines.push('- ⚠ 玩家验证接口异常：' + (e.playerHealth && e.playerHealth.detail) +
          '。玩家相关数值不可用，不得视为「0% 通关率」。');
      } else {
        reportLines.push('- 玩家是否通关：修改前 ' + (pBefore ? (pBefore.won ? '通关' : '未通关') : '—') +
          ' → 重构后 ' + (pAfter ? (pAfter.won ? '通关' : '未通关') : '—'),
          '- 玩家复活次数：修改前 ' + (pBefore ? (pBefore.revives + '/' + pBefore.reviveCap) : '—') +
          ' → 重构后 ' + (pAfter ? (pAfter.revives + '/' + pAfter.reviveCap) : '—'));
        var em = e.playerAfterMulti;
        if (em && em.rounds) {
          reportLines.push('', '## 多轮玩家验证（随机种子）', '',
            '| 种子 | 是否通关 | 暂存峰值 | 复活次数/上限 | 完成盒数/总盒数 |', '| --- | --- | --- | --- | --- |');
          em.rounds.forEach(function (x) {
            if (x.error) { reportLines.push('| ' + x.seed + ' | 本轮异常 | — | — | — |'); return; }
            reportLines.push('| ' + x.seed + ' | ' + (x.won ? '通关' : '未通关') + ' | ' + x.bufferPeak +
              ' | ' + x.revivesUsed + '/' + x.reviveCap + ' | ' + x.completedBoxes + '/' + x.totalBoxes + ' |');
          });
          reportLines.push('', '- 总通关率：' + (em.successRate * 100).toFixed(0) + '%（' + em.roundCount + ' 轮）',
            '- 平均暂存峰值：' + em.avgPeak, '- 平均复活次数：' + em.avgRevives, '');
        }
      }
      // 进度区域专用对比图（需求 §六.4）：用条目里存的区域数据离屏重绘专用画布，
      // 不是主画布截屏；条目没做过区域对比时如实放缺失说明，不拿别的图充数。
      var rcCv = buildRegionCompareCanvasFromEntry(e);
      if (rcCv) {
        pngPromises.push(canvasToPngBytes(rcCv).then(function (bytes) {
          files.push({ name: dir + '进度区域专用对比图.png', bytes: bytes });
        }));
        reportLines.push('- 进度区域变化：共同 ' + e.regionCompare.common.length + ' 像素，只在修改前 ' +
          e.regionCompare.onlyBefore.length + ' 像素，只在修改后 ' + e.regionCompare.onlyAfter.length + ' 像素');
      } else {
        files.push({ name: dir + '进度区域专用对比图_缺失说明.txt',
          text: '这一关加入待导出库时没有做过区间区域对比，所以没有这张图。\n' +
                '补做方法：打开这一关 → 定位进度区间 → 重构成功 → 点「对比当前区间（修改前后）」→ 再次点「添加为待导出库」更新条目。\n' });
        reportLines.push('- 进度区域变化：加入待导出库时未做区间区域对比，无数据');
      }
      var txtReport = reportLines.join('\n') + '\n';
      files.push({ name: dir + '对比分析报告.md', text: txtReport });
      digest('对比分析报告', e.key, '.md', txtReport);
      manifestRows.push([e.key, e.validationStatus, RECON_STRATEGY_NAME,
        !healthy ? '接口异常' : (e.playerAfterMulti ? ((e.playerAfterMulti.successRate * 100).toFixed(0) + '%') :
          (pAfter ? (pAfter.won ? '通关' : '未通关') : '—')),
        e.pressureAfter ? e.pressureAfter.peak : '—',
        !healthy ? '接口异常' : (pAfter ? (pAfter.revives + '/' + pAfter.reviveCap) : '—'),
        e.board ? (e.board.rows + '×' + e.board.cols + '，黑块 ' + e.board.blackPercent + '%') : '—',
        e.obstacleCheck ? e.obstacleCheck.overallText : '无核对数据',
        e.genParamsUsed && e.genParamsUsed.fileName ? e.genParamsUsed.fileName : '工具默认参数',
        e.reconstructedAt || '—']);
    });
    // 总清单（需求 §六.4：批量包同时提供总清单）
    var manifestMd = '# 批量导出总清单\n\n共 ' + entries.length + ' 关\n\n' +
      '- 导出时间：' + new Date().toISOString() + '\n' +
      '- 版本说明：' + TOOL_VERSION_NOTE + '\n' +
      '- 本包文件名带导出时间戳，多次导出不会互相覆盖，旧导出包请自行保留。\n\n' +
      '| ' + manifestRows[0].join(' | ') + ' |\n' + '| ' + manifestRows[0].map(function () { return '---'; }).join(' | ') + ' |\n' +
      manifestRows.slice(1).map(function (r) { return '| ' + r.join(' | ') + ' |'; }).join('\n') + '\n';
    files.push({ name: '总清单.md', text: manifestMd });
    // 汇总层：同一份清单再出一份 CSV（便于直接进表格筛选/排序），与上面 md 同源同轮
    var csvEsc = function (v) { var s = String(v == null ? '' : v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
    files.push({ name: DIGEST + '总清单.csv',
      text: '\ufeff' + manifestRows.map(function (r) { return r.map(csvEsc).join(','); }).join('\n') + '\n' });
    files.push({ name: DIGEST + '说明.txt', text:
      '本目录是按【数据类型】跨关归并的汇总视图，文件名一律用原关卡名。\n' +
      '包根目录下每关一个同名子目录的结构仍然保留，两者内容完全一致，只是组织方式不同：\n' +
      '  · 想批量拿某一类数据（例如全部新关卡的官方格式）→ 用本汇总目录\n' +
      '  · 想看某一关的全部产物 → 用包根目录下该关的子目录\n\n' +
      '目录含义：\n' +
      '  正式游戏端关卡文件/新关卡、原关卡   可直接进游戏端的官方格式\n' +
      '  工具内部数据/新关卡、原关卡         带完整棋盘，可重新导入本工具继续修改\n' +
      '  目标图/新关卡、原关卡               TXT 目标图\n' +
      '  求解与玩家结果/新关卡pickOrder、原关卡pickOrder、玩家结果对比\n' +
      '  生效的生成器参数/                   每关一份实际生效参数与障碍核对\n' +
      '  对比分析报告/                       每关一份修改前后对比报告\n' +
      '  总清单.csv                          全部关卡的一行式汇总（与包根 总清单.md 同源）\n\n' +
      '注意：「新关卡」= 重构后，「原关卡」= 修改前的原始关卡。\n' +
      '进度区域专用对比图（PNG）只放在单关目录，未纳入汇总层（二进制图不便于跨关批量使用）。\n' });

    // PNG 是 canvas.toBlob 异步产出的，必须等全部图片都收进 files 再打包，否则 ZIP 会少图。
    Promise.all(pngPromises).then(function () {
      var blob = zipCreateBinary(files);
      download('待导出库批量导出_' + entries.length + '关_' + exportStamp() + '.zip', blob);
      busy(false); overlay(false);
      log('批量导出完成：' + entries.length + ' 关，共 ' + files.length + ' 个文件（含「汇总/」分类归并视图：新旧关卡分目录、文件名用原关卡名）。');
    }).catch(function (err) {
      busy(false); overlay(false);
      log('批量导出失败：' + (err && err.message));
    });
  }

  // ==================== 重新生成关卡（唯一策略：完全重新生成） ====================
  // 2026-07-31 起只保留「完全重新生成」：策略①保障碍布局换色重配、③保结构重切盒 已按需求
  // 07.31-关卡重构单策略与方案参数纠正 §三 从页面入口与工具调用中移除。
  // 走 core.js 包装的正式公开入口 Generator.produce()，不复制算法、不直接调内部 produceFixed。
  // 失败原样展示 core.js 返回的 reason/detail，不伪造成功。

  var RECON_STRATEGY_NAME = '完全重新生成';

  /**
   * 障碍参数核对的统一渲染（页面 kv 表用）。
   * 口径与容差都来自 core.js 的 obstacleCheckOf —— 页面、单关报告、批量报告三处同源，
   * 不各自算一套；容差是用户 2026-07-31 批准的，必须连来源一起显示出来。
   */
  function renderObstacleCheckRows(rows, oc) {
    if (!oc || !oc.items) return;
    var lines = oc.items.map(function (x) {
      var unit = x.kind === 'percent' ? '%' : ' 组';
      var unitDev = x.kind === 'percent' ? ' 个百分点' : ' 组';
      var dev = (x.deviation > 0 ? '+' : '') + x.deviation + unitDev;
      var detail = x.kind === 'percent'
        ? ('（' + x.actualCount + ' / ' + x.denom + ' ' + x.denomLabel + '）')
        : '';
      var verdict;
      if (x.judged === false) {
        verdict = '　<span class="tag warn">本次不做判定</span><br><span class="hint">' + x.unjudgedReason + '</span>';
      } else if (x.withinTolerance) {
        verdict = '　<span class="tag ok">在容差内</span>';
      } else {
        verdict = '　<span class="tag bad">超出容差 ±' + x.tolerance + unitDev + '</span>';
      }
      return x.label + '：目标 ' + x.target + unit + '　实际 ' + x.actual + unit + detail +
        '　偏差 ' + dev + verdict +
        (x.belowNote ? '<br><span class="hint">' + x.belowNote + '</span>' : '');
    });
    if (oc.narrowChainNote) lines.push('<span class="hint">' + oc.narrowChainNote + '</span>');
    // 整体状态三态，直接用核对结果给出的中文结论，页面不另写一套措辞。
    var head;
    if (oc.overall === 'outOfTolerance') head = '<span class="tag bad">障碍参数存在超出容差</span>';
    else if (oc.overall === 'hasUnjudged') head = '<span class="tag warn">障碍参数存在未判定项</span>';
    else head = '<span class="tag ok">障碍参数全部在容差内</span>';
    lines.push('<b>整体结论：' + oc.overallText + '</b>' +
      (oc.complete ? '' : '　<span class="hint">未达到「完整通过」，请按上面逐项看是哪一项。</span>'));
    rows.push([head, lines.join('<br>') + '<br><span class="hint">' + oc.toleranceNote + '</span>']);
  }

  /** 障碍参数核对的 Markdown 版（导出报告用，与页面同源同口径）。 */
  function obstacleCheckMarkdown(oc) {
    if (!oc || !oc.items) return [];
    var out = ['', '## 障碍参数核对（目标 / 实际 / 偏差）', '',
      '| 参数 | 目标 | 实际 | 分母 | 偏差 | 是否在容差内 |', '| --- | --- | --- | --- | --- | --- |'];
    oc.items.forEach(function (x) {
      var unit = x.kind === 'percent' ? '%' : ' 组';
      var unitDev = x.kind === 'percent' ? ' 个百分点' : ' 组';
      var dev = (x.deviation > 0 ? '+' : '') + x.deviation + unitDev;
      var verdict = x.judged === false ? '本次不做判定'
        : (x.withinTolerance ? '是' : '**否，超出 ±' + x.tolerance + unitDev + '**');
      out.push('| ' + x.label + ' | ' + x.target + unit + ' | ' + x.actual + unit +
        (x.kind === 'percent' ? '（' + x.actualCount + ' 个）' : '') + ' | ' +
        (x.kind === 'percent' ? x.denom + ' ' + x.denomLabel : '—') + ' | ' + dev + ' | ' + verdict + ' |');
    });
    out.push('', '- 容差口径：' + oc.toleranceNote,
      '- **整体状态：' + oc.overallText + '**' +
      (oc.complete ? '（四项全部判定且全部在容差内，算完整通过）'
        : '（未达到完整通过：只有四项全部判定且全部在容差内才算通过）'),
      '- 分母与正式生成器一致：黑块按棋盘容量算，冰块与问号按棋盘盒格数算，锁链按组数算。');
    if (oc.unjudged && oc.unjudged.length) {
      out.push('- 本次未做判定的项：' + oc.unjudged.join('、') + '。原因：' +
        oc.items.filter(function (x) { return !x.judged; }).map(function (x) { return x.unjudgedReason; }).join(' / '));
    }
    oc.items.forEach(function (x) { if (x.belowNote) out.push('- ' + x.label + '：' + x.belowNote); });
    if (oc.narrowChainNote) out.push('- ' + oc.narrowChainNote);
    return out;
  }
  // 导出包与列表记录里注明的版本说明（需求 07.31 §七第8点）。
  var TOOL_VERSION_NOTE = '关卡图修改工具 2026-07-31 版：重构只保留「完全重新生成」一种方式，走正式生成器的正常生产入口；' +
    '方案文件的正式生效参数取方案本体、不取页面历史输入；玩家验证 = 生成器内部正式单次 + 5 个固定随机种子多轮。';
  // 导出文件名带时间戳：同一关多次导出会得到不同文件名，新导出不会覆盖旧导出（需求 §七第7点）。
  function exportStamp() {
    var d = new Date();
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return String(d.getFullYear()) + p(d.getMonth() + 1) + p(d.getDate()) + '-' +
      p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
  }

  /**
   * 玩家结果字段归一化。两种来源的字段名不同，必须统一后再展示/导出，否则会显示成空值：
   *   PlayerSim.run 直接返回：won / bufferPeak / revivesUsed / reviveCap（原关卡走这条）
   *   生成器 generationEval.player：won / peak / revives / reviveCap（重构后关卡走这条）
   */
  function normalizePlayerResult(p) {
    if (!p) return null;
    return {
      won: !!p.won,
      peak: p.bufferPeak != null ? p.bufferPeak : (p.peak != null ? p.peak : 0),
      revives: p.revivesUsed != null ? p.revivesUsed : (p.revives != null ? p.revives : 0),
      reviveCap: p.reviveCap != null ? p.reviveCap : 2
    };
  }

  /** 导入生成器标准参数文件（需求 §四）：解析、识别字段，未识别字段列出不丢弃，供重构调用时传入。 */
  function loadGenParamsFile(file) {
    var reader = new FileReader();
    reader.onload = function () {
      var r = C.parseGeneratorParamsFile(reader.result);
      if (!r.ok) {
        log('导入生成器参数失败：' + r.detail);
        $('genParamsInfo').innerHTML = kvTable([['导入失败', r.detail]]);
        return;
      }
      // 网页方案文件里 inputs 只是页面历史输入状态，正式生效参数一律以 config 为准（需求 §四.1）。
      // 这里额外把两者不一致的字段挑出来展示，便于核对，但不会用 inputs 覆盖 config。
      var conflicts = detectSchemeConflicts(reader.result, r.recognized);
      S.genParams = {
        recognized: r.recognized, unrecognized: r.unrecognized, source: r.source,
        fileName: file.name, conflicts: conflicts
      };
      renderGenParamsInfo();
      renderReconParamPreview();
      $('btnClearGenParams').style.display = '';
      log('已导入生成器参数：' + file.name + '（' + r.source + '），识别 ' + Object.keys(r.recognized).length + ' 项' +
        (r.unrecognized.length ? '，未识别 ' + r.unrecognized.length + ' 项（不丢弃，见下方列表）' : '') +
        (conflicts.length ? '；其中 ' + conflicts.length + ' 项与文件里的历史输入值不同，正式生效值取 config' : ''));
    };
    reader.readAsText(file);
  }

  // 网页方案文件里 inputs 的输入框 id ↔ 正式参数名 的对应关系（只用于「展示冲突」，不参与取值）。
  var SCHEME_INPUT_MAP = {
    'gen-boxmin': 'boxSizeMin', 'gen-boxmax': 'boxSizeMax', 'gen-boxmode': 'boxSizeMode',
    'gen-buffer': 'bufferLimit', 'gen-ice': 'icePercent', 'gen-black': 'blackPercent',
    'gen-chain': 'chainCount', 'gen-question': 'questionPercent',
    'gen-rowsmin': 'boardRowsMin', 'gen-rowsmax': 'boardRowsMax',
    'gen-colsmin': 'boardColsMin', 'gen-colsmax': 'boardColsMax',
    'gen-candidate': 'candidateCount', 'gen-budget': 'timeBudgetMs'
  };

  /**
   * 找出网页方案文件里 inputs 与 config 取值不同的字段（需求 §四.1/§四.2：
   * 冲突要能看见，但不得把 inputs 覆盖到生效参数上）。
   */
  function detectSchemeConflicts(text, recognized) {
    var out = [];
    var json = null;
    try { json = JSON.parse(String(text).replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/.*$/gm, '$1')); }
    catch (e) { return out; }
    if (!json || !json.inputs || typeof json.inputs !== 'object') return out;
    Object.keys(SCHEME_INPUT_MAP).forEach(function (inKey) {
      var cfgKey = SCHEME_INPUT_MAP[inKey];
      if (!(inKey in json.inputs)) return;
      if (!(cfgKey in recognized)) return;
      var iv = json.inputs[inKey], cv = recognized[cfgKey];
      if (String(iv) !== String(cv)) out.push({ inputKey: inKey, paramKey: cfgKey, inputValue: iv, configValue: cv });
    });
    return out;
  }

  /**
   * 点重构前的关键参数确认区（需求 §四.2）：用中文列出这次真正会生效的参数。
   * 没导入方案时显示工具默认值，并注明来源。
   */
  function renderReconParamPreview() {
    var box = $('reconParamPreview');
    if (!box) return;
    var Gen = window.AntSolver && window.AntSolver.Generator;
    var base = (Gen && Gen.DEFAULT_CONFIG) || {};
    var eff = Object.assign({}, base, (S.genParams && S.genParams.recognized) || {});
    var src = S.genParams ? ('导入方案 ' + S.genParams.fileName) : '工具默认参数（未导入方案）';
    // 暂存上限是玩法固定口径（用户已确认为 5），重构时一律按固定值执行；
    // 方案若给了不同值，不能在这里显示成方案值，否则展示与实际生效不一致（需求 §四.2）。
    var fixedBuffer = C.BUFFER_LIMIT;
    var rows = [
      ['参数来源', src],
      ['底部消除', eff.bottomOnly ? '开启' : '关闭'],
      ['盒容量', eff.boxSizeMin + '—' + eff.boxSizeMax],
      ['暂存上限', String(fixedBuffer) + '（玩法固定口径）'],
      ['黑块', eff.blackPercent + '%'],
      ['冰块', eff.icePercent + '%'],
      ['锁链', eff.chainCount + ' 组'],
      ['问号', eff.questionPercent + '%'],
      ['棋盘范围', eff.boardRowsMin + '—' + eff.boardRowsMax + ' 行 × ' + eff.boardColsMin + '—' + eff.boardColsMax + ' 列'],
      ['窄路', (eff.narrowPath ? '开启' : '关闭') + '，缺口 ' + eff.narrowPathGapsMin + '—' + eff.narrowPathGapsMax],
      ['障碍参数容差', C.OBSTACLE_TOLERANCE_NOTE + '　重构后会逐项给出目标/实际/偏差与是否在容差内。']
    ];
    var cf = (S.genParams && S.genParams.conflicts) || [];
    if (cf.length) {
      rows.push(['<span class="tag warn">字段冲突</span>',
        cf.map(function (x) {
          return x.paramKey + '：方案里的历史输入值 ' + x.inputValue + '，正式生效值取 ' + x.configValue;
        }).join('<br>') + '<br>正式生效值一律取 config，历史输入值不参与生成。']);
    }
    var schemeBuffer = S.genParams && S.genParams.recognized ? S.genParams.recognized.bufferLimit : null;
    if (schemeBuffer != null && Number(schemeBuffer) !== Number(fixedBuffer)) {
      rows.push(['<span class="tag warn">被工具强制覆盖</span>',
        '方案里的暂存上限是 ' + schemeBuffer + '，本工具一律按玩法固定口径 ' + fixedBuffer +
        ' 执行，不采用方案值。若确需改这个口径，属于玩法规则变更，需另行确认。']);
    }
    box.innerHTML = kvTable(rows);
  }

  /** 显示已导入参数的简洁中文摘要 + 未识别字段列表（需求 §五第3、6点：不得悄悄丢弃未识别字段）。 */
  function renderGenParamsInfo() {
    var box = $('genParamsInfo');
    if (!S.genParams) { box.innerHTML = ''; return; }
    var gp = S.genParams;
    var rows = [
      ['来源文件', gp.fileName + '（' + gp.source + '）'],
      ['已识别参数', Object.keys(gp.recognized).map(function (k) { return k + '=' + gp.recognized[k]; }).join('，')]
    ];
    if (gp.unrecognized.length) {
      rows.push(['<span class="tag warn">未识别字段</span>', gp.unrecognized.join('、') + '（不属于正式生成器标准参数，已忽略，未静默丢弃——如实列出）']);
    }
    box.innerHTML = kvTable(rows);
  }

  function runReconstruct() {
    var it = cur();
    if (!it || !it.blocks) { log('请先选择一关'); return; }
    var newBlocks = it.blocks;   // 若用户在「8. 美术编辑」改过色，it.blocks 已是改后的目标图
    // 需求 §四：导入了生成器标准参数时，重构必须按该参数执行，不得用工具默认值静默覆盖。
    var genCfg = S.genParams ? S.genParams.recognized : {};
    busy(true); overlay(true, '重新生成关卡中' + (S.genParams ? '（已应用导入方案参数）' : '') + '…可能需要较长时间');
    var t0 = Date.now();
    setTimeout(function () {
      var res = null, err = null;
      try { res = C.reconstructFullRegenerate(newBlocks, genCfg); }
      catch (e) { err = e; }
      busy(false); overlay(false);
      var elapsedMs = Date.now() - t0;
      if (err) {
        log('重新生成异常：' + (err && err.message));
        renderReconInfo({ ok: false, strategy: 'fullRegenerate', reason: 'exception', detail: err && err.message }, elapsedMs);
        return;
      }
      it.reconResult = res;
      it.reconResult.genParamsUsed = S.genParams ? {
        fileName: S.genParams.fileName, recognized: S.genParams.recognized,
        unrecognized: S.genParams.unrecognized, conflicts: S.genParams.conflicts || []
      } : null;
      it.reconResult.reconstructedAt = new Date().toISOString();
      renderReconInfo(res, elapsedMs);
      if (res.ok) {
        // 不自动覆盖原关卡，只标出「有可用的重构后视图」，用户通过下方单选切换查看/回放。
        $('reconViewSwitch').style.display = '';
        $('reconRegionRow').style.display = it.interval ? '' : 'none';
        $('reconExportRow').style.display = '';
        renderReconCompareTable(it);
        var ph = res.playerHealth;
        if (ph && !ph.ok) {
          // 需求 §六.2：接口异常时禁止把它当成 0% 通关率，必须显式报异常。
          log('⚠ 重新生成成功，但玩家验证接口异常（' + ph.detail + '）。玩家相关数值本次不可用，请勿据此判断关卡难度。');
        } else {
          var m = res.playerMulti;
          log('重新生成成功，耗时 ' + (elapsedMs / 1000).toFixed(1) + 's' +
            (m ? ('；多轮玩家通关率 ' + (m.successRate * 100).toFixed(0) + '%（' + m.roundCount + ' 轮），平均暂存峰值 ' + m.avgPeak) : '') +
            '。可在下方切换查看原关卡/重构后关卡。');
        }
      } else {
        $('reconViewSwitch').style.display = 'none';
        $('reconRegionRow').style.display = 'none';
        $('reconExportRow').style.display = 'none';
        log('重新生成失败：' + res.reason + (res.detail ? '（' + res.detail + '）' : '') +
          '，耗时 ' + (elapsedMs / 1000).toFixed(1) + 's');
      }
    }, 30);
  }

  /** 切关/清空时复位重构闭环相关的显示状态，避免带着上一关的重构结果误导当前关。 */
  function resetReconView() {
    S.viewMode = 'before';
    var vs = document.querySelectorAll('input[name="viewMode"]');
    for (var i = 0; i < vs.length; i++) vs[i].checked = (vs[i].value === 'before');
    $('reconViewSwitch').style.display = 'none';
    $('reconRegionRow').style.display = 'none';
    $('reconExportRow').style.display = 'none';
    $('reconCompareTable').innerHTML = '';
    $('reconRegionInfo').innerHTML = '';
    $('regionCompareBox').style.display = 'none';
    $('reconInfo').innerHTML = '';
    $('optPressureOverlay').checked = false;
    // 切关后压力图回到全知轨迹，避免带着上一关的玩家轮次选择继续看
    S.pressureTrack = 'omni';
    var bo = $('btnTrackOmni'), bp = $('btnTrackPlayer');
    if (bo && bp) { bo.className = 'btn primary'; bp.className = 'btn ghost'; }
    $('playerSeedRow').style.display = 'none';
    $('pressureTrackInfo').innerHTML = '';
  }

  function renderReconInfo(res, elapsedMs) {
    var box = $('reconInfo');
    var rows = [
      ['方式', RECON_STRATEGY_NAME],
      ['耗时', (elapsedMs / 1000).toFixed(1) + 's']
    ];
    if (S.genParams) rows.push(['参数来源', '导入方案「' + S.genParams.fileName + '」']);
    else rows.push(['参数来源', '工具默认参数（未导入方案）']);

    if (!res.ok) {
      rows.push(['结果', '<span class="tag bad">失败</span>']);
      rows.push(['失败阶段', res.stage || res.reason || '未知']);
      if (res.detail) rows.push(['原因', res.detail]);
      if (res.solveResult) rows.push(['求解进度', (res.solveResult.progress || 0) + '%' + (res.solveResult.completed ? '（已通关）' : '（未通关）')]);
      if (res.timedOut) rows.push(['提示', '已超时兜底，仍无合法候选']);
      if (res.effectiveConfig) rows.push(['尝试时实际使用参数', '盒容量 ' + res.effectiveConfig.boxSizeMin + '—' + res.effectiveConfig.boxSizeMax]);
      box.innerHTML = kvTable(rows);
      return;
    }

    rows.push(['结果', '<span class="tag ok">成功</span>']);
    if (res.retries != null) rows.push(['重试轮次', res.retries]);

    // 棋盘实况与最终黑块（需求 §五：报告需显示目标黑块、实际黑块与实际比例）
    var b = res.board;
    if (b) {
      rows.push(['重构后棋盘', b.rows + ' 行 × ' + b.cols + ' 列（共 ' + b.capacity + ' 格）' +
        (b.shapeOk ? '' : '　<span class="tag warn">形态不合规：列-行=' + b.shapeDiff + '</span>')]);
      rows.push(['棋盘构成', '盒 ' + b.boxCells + '　黑块 ' + b.blackCells + '　管道 ' + b.pipeCells + '　空格 ' + b.emptyCells]);
    }
    // 障碍参数核对：逐项列出目标/实际/偏差，并写明容差是谁批准的。
    // 以前这里是隐式的「实际 > 目标+5 就标超标」，读者看不到容差本身，已改为显式展示。
    if (res.obstacleCheck) renderObstacleCheckRows(rows, res.obstacleCheck);

    if (res.solveResult) {
      rows.push(['全知求解', '通关，步数 ' + res.solveResult.steps + '，暂存峰值 ' + (res.solveResult.maxBuffer || 0)]);
    }
    if (res.difficulty) {
      rows.push(['难度分 / 档', (res.difficulty.score != null ? res.difficulty.score : '—') + ' / ' + (res.difficulty.grade || '—')]);
    }

    // 玩家验证（需求 §六）：接口异常时必须报异常，不得显示成 0% 通关率
    var ph = res.playerHealth;
    if (ph && !ph.ok) {
      rows.push(['<span class="tag bad">玩家验证接口异常</span>',
        ph.detail + '<br>本次玩家相关数值不可用，请勿据此判断关卡难度。']);
    } else {
      if (res.playerOfficial) {
        var p = res.playerOfficial;
        rows.push(['玩家结果(生成器正式单次)', (p.won ? '通关' : '未通关') +
          '，暂存峰值 ' + p.peak + '，复活 ' + p.revives + '/' + p.reviveCap]);
      }
      var m = res.playerMulti;
      if (m) {
        rows.push(['多轮玩家通关率', '通关率 ' + (m.successRate * 100).toFixed(0) + '%（' + m.roundCount +
          ' 轮随机种子）　平均暂存峰值 ' + m.avgPeak + '　平均复活 ' + m.avgRevives]);
        rows.push(['多轮逐轮明细', m.rounds.map(function (x) {
          if (x.error) return '种子 ' + x.seed + '：本轮异常';
          return '种子 ' + x.seed + '：' + (x.won ? '通关' : '未通关') +
            '，峰值 ' + x.bufferPeak + '，复活 ' + x.revivesUsed + '/' + x.reviveCap +
            '，完成盒 ' + x.completedBoxes + '/' + x.totalBoxes;
        }).join('<br>')]);
      }
    }

    if (res.effectiveConfig) {
      var ec = res.effectiveConfig;
      rows.push(['实际生效参数', '底部消除 ' + (ec.bottomOnly ? '开启' : '关闭') +
        '　盒容量 ' + ec.boxSizeMin + '—' + ec.boxSizeMax +
        '　暂存 ' + ec.bufferLimit +
        '　黑块 ' + ec.blackPercent + '%　冰块 ' + ec.icePercent + '%' +
        '　锁链 ' + ec.chainCount + ' 组　问号 ' + ec.questionPercent + '%' +
        '　棋盘范围 ' + ec.boardRowsMin + '—' + ec.boardRowsMax + ' 行 × ' + ec.boardColsMin + '—' + ec.boardColsMax + ' 列' +
        '　窄路缺口 ' + ec.narrowPathGapsMin + '—' + ec.narrowPathGapsMax]);
    }
    var cf = S.genParams && S.genParams.conflicts;
    if (cf && cf.length) {
      rows.push(['方案字段冲突', cf.map(function (x) {
        return x.paramKey + '：历史输入值 ' + x.inputValue + '，正式生效值 ' + x.configValue;
      }).join('<br>') + '<br>正式生效值取 config，历史输入值不参与生成。']);
    }
    if (res.reconstructedAt) rows.push(['生成时间', res.reconstructedAt]);
    box.innerHTML = kvTable(rows);
  }

  /**
   * 修改前后完整指标对比表（需求 §3.1 要求的11项）：是否可解/求解步数/暂存峰值/暂存均值/
   * 前中后压力/卡点位置/难度分档/玩家是否通关/玩家复活次数。压力曲线的峰值/均值/卡点复用
   * pressureCurveFromTl 的口径，前中后压力借用 Analysis.chokepointAudit 已算出的 early/mid/late 峰窗均值。
   */
  function renderReconCompareTable(it) {
    var m = collectCompareMetrics(it);
    if (!m) { $('reconCompareTable').innerHTML = ''; return; }
    var h = '<table><tr><td class="k">指标</td><td class="v">修改前</td><td class="v">重构后</td></tr>';
    m.rows.forEach(function (r) {
      h += '<tr><td class="k">' + r.label + '</td><td class="v">' + r.before + '</td><td class="v">' + r.after + '</td></tr>';
    });
    $('reconCompareTable').innerHTML = h + '</table>';
  }

  /**
   * 汇总修改前后的完整指标。页面对比表和导出报告都只从这里取数，
   * 保证两处永远是同一份结论，不会各算一套（需求 §七第2点：报告要直接写全这些字段）。
   * @returns {{rows: Array<{label:string, before:*, after:*}>, extra: object}|null} 未重构成功时返回 null
   */
  function collectCompareMetrics(it) {
    var rr = it && it.reconResult;
    if (!rr || !rr.ok) return null;
    if (!rr.tl) rr.tl = C.reconstructToTimeline(rr);
    // 修改前（原关卡）压力口径：走真实压力样本（officialSamplesOf），不反推；
    // 修改前的原关卡没有导入求解数据的 audit 字段时（现场求解），用样本现算，
    // 口径与需求 §三.2 一致（正式审核必须来自 pressureSamples，不能来自点击时间线）。
    var curveBefore = it.pressureCurve ||
      (it.pressureCurve = C.pressureCurveFromTl(it.tl, {
        officialAuditPrecomputed: it.solve && it.solve.audit ? it.solve.audit : null,
        officialSamples: officialSamplesOf(it)
      }));
    var curveAfter = rr.tl ? (rr.pressureCurve ||
      (rr.pressureCurve = C.pressureCurveFromTl(rr.tl, { officialAuditPrecomputed: rr.audit || null }))) : null;
    var ab = curveBefore.audit, aa = curveAfter && curveAfter.audit;
    // 原关卡玩家结果：优先用导入求解数据里已有的真实玩家结果（it.solve.player），
    // 没有时现场跑一次固定种子模拟（需求 §三.3：「原关卡优先读取已有求解数据中的玩家结果；
    // 没有时执行一次固定种子的玩家模拟」）。结果缓存在 it._playerOne，避免每次刷新都重新模拟。
    if (it._playerOne === undefined) {
      if (it.solve && it.solve.player) {
        it._playerOne = { won: it.solve.player.won, bufferPeak: it.solve.player.bufferPeak, revivesUsed: it.solve.player.revivesUsed, reviveCap: it.solve.player.reviveCap };
      } else if (it.level) {
        it._playerOne = C.officialPlayerResult(it.level);
      } else {
        it._playerOne = null;
      }
    }
    // 两侧字段名不同，统一归一化后再比较（详见 normalizePlayerResult 注释）
    var pb = normalizePlayerResult(it._playerOne);
    var pa = normalizePlayerResult(rr.playerOfficial);
    var paHealthy = !rr.playerHealth || rr.playerHealth.ok;
    var NO_AUDIT = '正式压力审核暂无数据';
    function afterAudit(v) { return aa ? v : (curveAfter ? NO_AUDIT : '—'); }
    var rows = [
      { label: '是否可解', before: it.tl.completed ? '可解' : '未通关', after: rr.solveResult ? (rr.solveResult.completed ? '可解' : '未通关') : '未知' },
      { label: '求解步数', before: it.tl.steps_count, after: rr.solveResult ? rr.solveResult.steps : '—' },
      { label: '暂存峰值', before: curveBefore.peak, after: curveAfter ? curveAfter.peak : '—' },
      { label: '暂存均值', before: curveBefore.avg, after: curveAfter ? curveAfter.avg : '—' },
      { label: '前期压力(0-20%)', before: ab ? ab.earlyMax : NO_AUDIT, after: afterAudit(aa && aa.earlyMax) },
      { label: '中期压力(20-50%)', before: ab ? ab.midMax : NO_AUDIT, after: afterAudit(aa && aa.midMax) },
      { label: '后期压力(50-100%)', before: ab ? ab.lateMax : NO_AUDIT, after: afterAudit(aa && aa.lateMax) },
      { label: '卡点位置', before: ab ? (ab.hasChoke ? ab.lateAt + '%' : '无') : NO_AUDIT,
        after: afterAudit(aa && (aa.hasChoke ? aa.lateAt + '%' : '无')) },
      { label: '难度分/档', before: '—（原关卡未重跑难度评分，避免与生产口径产生第二套结论）',
        after: rr.difficulty ? (rr.difficulty.score + '/' + rr.difficulty.grade) : '—' },
      { label: '玩家是否通关', before: pb ? (pb.won ? '通关' : '未通关') : '—',
        after: !paHealthy ? '玩家验证接口异常' : (pa ? (pa.won ? '通关' : '未通关') : '—') },
      { label: '玩家暂存峰值', before: pb ? pb.peak : '—',
        after: !paHealthy ? '玩家验证接口异常' : (pa ? pa.peak : '—') },
      { label: '玩家复活次数', before: pb ? (pb.revives + '/' + pb.reviveCap) : '—',
        after: !paHealthy ? '玩家验证接口异常' : (pa ? (pa.revives + '/' + pa.reviveCap) : '—') },
      { label: '多轮玩家通关率', before: '—（原关卡只跑固定种子单次，未做多轮）',
        after: !paHealthy ? '玩家验证接口异常' :
          (rr.playerMulti ? ((rr.playerMulti.successRate * 100).toFixed(0) + '%（' + rr.playerMulti.roundCount +
            ' 轮），平均峰值 ' + rr.playerMulti.avgPeak + '，平均复活 ' + rr.playerMulti.avgRevives) : '—') }
    ];
    // 报告还要写的非「前后对比」类结论（守恒 / 结构 / 区域数量 / 盒数），单独放 extra。
    var d = S.edit.original ? C.diffBlocks(S.edit.original, it.blocks) : null;
    var consAll = rr.conservation || [];
    var consFailed = consAll.filter(function (c) { return c && c.ok === false; });
    var cmp = it._lastRegionCompare;
    return {
      rows: rows,
      extra: {
        像素守恒: d ? (d.totalConserved ? '守恒（修改前后像素总数一致）' : '不一致（修改前 ' + d.totalBefore + ' → 修改后 ' + d.totalAfter + '）')
          : '未经过美术编辑，目标图与导入时一致',
        改动像素数: d ? d.changedPixelCount : 0,
        生成器守恒校验: consAll.length ? (consFailed.length ? ('未通过 ' + consFailed.length + '/' + consAll.length + ' 项') : ('通过（' + consAll.length + ' 项全过）')) : '无校验记录',
        结构死锁检查: '通过（重构成功即已通过正式生成器的结构死锁检查，未通过时不会产出结果）',
        重构后棋盘: rr.board ? (rr.board.rows + ' 行 × ' + rr.board.cols + ' 列，共 ' + rr.board.capacity + ' 格' +
          (rr.board.shapeOk ? '（形态合规）' : '（形态不合规，列-行=' + rr.board.shapeDiff + '）')) : '—',
        棋盘构成: rr.board ? ('盒 ' + rr.board.boxCells + '，黑块 ' + rr.board.blackCells +
          '，管道 ' + rr.board.pipeCells + '，空格 ' + rr.board.emptyCells) : '—',
        障碍参数目标与实际: rr.obstacleCheck
          ? (rr.obstacleCheck.items.map(function (x) {
              var unit = x.kind === 'percent' ? '%' : ' 组';
              return x.label + ' 目标 ' + x.target + unit + ' / 实际 ' + x.actual + unit +
                '（偏差 ' + (x.deviation > 0 ? '+' : '') + x.deviation + '，' +
                (x.judged === false ? '本次不做判定' : (x.withinTolerance ? '在容差内' : '超出容差')) + '）';
            }).join('；') + '。整体状态：' + rr.obstacleCheck.overallText + '。' + rr.obstacleCheck.toleranceNote)
          : (rr.board && rr.effectiveConfig
            ? ('目标黑块 ' + rr.effectiveConfig.blackPercent + '%，实际 ' + rr.board.blackCells + ' 格 = ' + rr.board.blackPercent + '%（无完整障碍核对数据）')
            : '—'),
        区间连通区域数: it.interval && it.interval.comps ? it.interval.comps.length : '—',
        区间像素数: it.interval ? it.interval.diffPixelCount : '—',
        区域对比_共同: cmp ? cmp.common.length : '未做区间区域对比',
        区域对比_只在修改前: cmp ? cmp.onlyBefore.length : '未做区间区域对比',
        区域对比_只在修改后: cmp ? cmp.onlyAfter.length : '未做区间区域对比'
      }
    };
  }

  /** 「对比当前区间（修改前后）」：沿用已定位区间的用户要求百分比，分别在原/重构后关卡上重新吸附，按坐标对比消除区域。 */
  function runReconRegionCompare() {
    var it = cur();
    if (!it || !it.interval || !it.reconResult || !it.reconResult.ok) { log('需要先定位区间并重构成功'); return; }
    var rr = it.reconResult;
    if (!rr.tl) rr.tl = C.reconstructToTimeline(rr);
    if (!rr.tl || !rr.tl.completed) { log('重构后关卡时间线不可用或未通关，无法对比区域'); return; }
    var ivAfter = C.snapInterval(rr.tl.steps, rr.tl.totalBoxes, it.interval.requested.lo / 100, it.interval.requested.hi / 100);
    if (!ivAfter) { log('重构后关卡区间计算失败'); return; }
    var cmp = C.regionCompare(it.interval.diffPixels, it.tl.cols, ivAfter.diffPixels, rr.tl.cols);
    var rows = [
      ['修改前区域', it.interval.diffPixelCount + ' 像素'],
      ['修改后区域', ivAfter.diffPixelCount + ' 像素'],
      ['共同区域', cmp.common.length + ' 像素'],
      ['只在修改前出现', cmp.onlyBefore.length + ' 像素'],
      ['只在修改后出现', cmp.onlyAfter.length + ' 像素']
    ];
    $('reconRegionInfo').innerHTML = kvTable(rows);
    it._lastRegionCompare = cmp;
    // 画到专用画布（不是主画布），并记下重画所需的最小数据，供加入待导出库/批量导出时离屏重绘。
    it._regionCompareMeta = { rows: Math.max(it.tl.rows, rr.tl.rows), cols: Math.max(it.tl.cols, rr.tl.cols) };
    renderRegionComparePanel(it);
    log('区间区域对比完成：共同 ' + cmp.common.length + '，只在修改前 ' + cmp.onlyBefore.length + '，只在修改后 ' + cmp.onlyAfter.length);
  }

  // 进度区域专用对比图配色（需求 §七第1点）。三类区域各用一种颜色，和主画布高亮各画各的，互不复用画布。
  var REGION_CMP = {
    common: '#3BFF9E',
    onlyBefore: '#FFD400',
    onlyAfter: '#00E5FF',
    silhouette: 'rgba(255,255,255,0.10)'
  };

  /**
   * 在指定画布上绘制「进度区域专用对比图」（需求 §六.4「进度区域专用对比图」/§七第1点）。
   * 这是一张独立绘制的图，不是主画布 $('cv') 的截屏：
   *   ① 底层用极淡灰画出目标图轮廓，只作定位参考，不参与三类区域配色；
   *   ② 共同区域 / 只在修改前 / 只在修改后 三类各用一种颜色实心填充（三类互不相交）；
   *   ③ 图内自带文字图例和像素数，单独拿出这张 PNG 也能读懂。
   * @param {HTMLCanvasElement} cv 目标画布，可以是页面上的，也可以是离屏 canvas（批量导出用）
   * @param {object} cmp C.regionCompare() 的返回值 { common, onlyBefore, onlyAfter }
   * @param {number[][]|null} silhouetteBlocks 目标图，用于画底层轮廓；传 null 则不画轮廓
   * @param {number} rows @param {number} cols 画布网格尺寸
   * @param {number} cell 单格像素边长
   */
  function drawRegionCompareTo(cv, cmp, silhouetteBlocks, rows, cols, cell) {
    var padL = 8, padT = 8, headH = 30;
    var gridW = cols * cell, gridH = rows * cell;
    cv.width = Math.max(gridW + padL * 2, 460);
    cv.height = gridH + padT * 2 + headH;
    var ctx = cv.getContext('2d');
    ctx.fillStyle = '#0f1216'; ctx.fillRect(0, 0, cv.width, cv.height);

    // ③ 图内图例（先画，位置在顶部预留的 headH 带内，不会压到网格）
    var items = [
      [REGION_CMP.common, '共同区域 ' + cmp.common.length + ' 像素'],
      [REGION_CMP.onlyBefore, '只在修改前 ' + cmp.onlyBefore.length + ' 像素'],
      [REGION_CMP.onlyAfter, '只在修改后 ' + cmp.onlyAfter.length + ' 像素']
    ];
    ctx.font = '12px sans-serif'; ctx.textBaseline = 'middle';
    var lx = padL;
    for (var i = 0; i < items.length; i++) {
      ctx.fillStyle = items[i][0];
      ctx.fillRect(lx, headH / 2 - 5, 10, 10);
      ctx.fillStyle = '#e6d2ba';
      ctx.fillText(items[i][1], lx + 15, headH / 2);
      lx += 15 + ctx.measureText(items[i][1]).width + 16;
    }

    var oy = padT + headH;
    // ① 目标图轮廓
    if (silhouetteBlocks) {
      ctx.fillStyle = REGION_CMP.silhouette;
      for (var r = 0; r < silhouetteBlocks.length; r++) {
        var rowArr = silhouetteBlocks[r] || [];
        for (var c = 0; c < rowArr.length; c++) if (rowArr[c]) ctx.fillRect(padL + c * cell, oy + r * cell, cell, cell);
      }
    }
    // ② 三类区域
    fillRegionCells(ctx, cmp.common, REGION_CMP.common, padL, oy, cell);
    fillRegionCells(ctx, cmp.onlyBefore, REGION_CMP.onlyBefore, padL, oy, cell);
    fillRegionCells(ctx, cmp.onlyAfter, REGION_CMP.onlyAfter, padL, oy, cell);

    ctx.strokeStyle = 'rgba(255,255,255,0.18)'; ctx.lineWidth = 1;
    ctx.strokeRect(padL - .5, oy - .5, gridW + 1, gridH + 1);
  }

  function fillRegionCells(ctx, list, color, padL, oy, cell) {
    if (!list || !list.length) return;
    ctx.fillStyle = color;
    for (var k = 0; k < list.length; k++) ctx.fillRect(padL + list[k].c * cell, oy + list[k].r * cell, cell, cell);
  }

  /** 把区域对比结果画到页面上的专用画布并显示图例。 */
  function renderRegionComparePanel(it) {
    var cmp = it._lastRegionCompare, meta = it._regionCompareMeta;
    if (!cmp || !meta) { $('regionCompareBox').style.display = 'none'; return; }
    var cell = parseInt($('cellSize').value, 10) || 11;
    drawRegionCompareTo($('cvRegionCompare'), cmp, it.blocks, meta.rows, meta.cols, cell);
    $('regionCompareBox').style.display = '';
    $('regionCompareLegend').innerHTML = [
      [REGION_CMP.common, '共同区域（修改前后同一进度区间都会消除）' + cmp.common.length + ' 像素'],
      [REGION_CMP.onlyBefore, '只在修改前消除 ' + cmp.onlyBefore.length + ' 像素'],
      [REGION_CMP.onlyAfter, '只在修改后消除 ' + cmp.onlyAfter.length + ' 像素']
    ].map(function (l) {
      return '<span><i class="sw" style="border-top-color:' + l[0] + ';border-top-style:solid"></i>' + l[1] + '</span>';
    }).join('');
  }

  /**
   * 为「导出完整对比包」生成一张离屏的进度区域专用对比图画布。
   * 没做过区域对比（it._lastRegionCompare 为空）时返回 null，由调用方如实说明缺图原因。
   */
  function buildRegionCompareCanvas(it) {
    if (!it || !it._lastRegionCompare || !it._regionCompareMeta) return null;
    var cv = document.createElement('canvas');
    drawRegionCompareTo(cv, it._lastRegionCompare, it.blocks,
      it._regionCompareMeta.rows, it._regionCompareMeta.cols, 11);
    return cv;
  }

  /**
   * 把区域对比结果压成待导出库可以放进 localStorage 的紧凑形式：坐标存成扁平下标（r*cols+c），
   * 比存 {r,c} 对象数组省一多半体积。批量导出时再用 expandRegionCompare 还原成坐标。
   */
  function compactRegionCompare(cmp, meta) {
    if (!cmp || !meta) return null;
    var cols = meta.cols;
    function flat(list) { return list.map(function (p) { return p.r * cols + p.c; }); }
    return { rows: meta.rows, cols: cols, common: flat(cmp.common), onlyBefore: flat(cmp.onlyBefore), onlyAfter: flat(cmp.onlyAfter) };
  }

  function expandRegionCompare(rc) {
    if (!rc) return null;
    var cols = rc.cols;
    function un(list) { return (list || []).map(function (i) { return { r: Math.floor(i / cols), c: i % cols }; }); }
    return { common: un(rc.common), onlyBefore: un(rc.onlyBefore), onlyAfter: un(rc.onlyAfter) };
  }

  /** 批量导出用：从待导出库条目还原出进度区域专用对比图画布。条目没存区域对比时返回 null。 */
  function buildRegionCompareCanvasFromEntry(e) {
    if (!e || !e.regionCompare) return null;
    var cmp = expandRegionCompare(e.regionCompare);
    var cv = document.createElement('canvas');
    drawRegionCompareTo(cv, cmp, e.editedBlocks, e.regionCompare.rows, e.regionCompare.cols, 11);
    return cv;
  }

  /** 未夹边：坐标落在画布外时返回 null（点在画布外应视为无效点击，不是夹到边缘格）。 */
  function eventToCell(ev, it) {
    var cell = parseInt($('cellSize').value, 10) || 11;
    var rect = $('cv').getBoundingClientRect();
    var c = Math.floor((ev.clientX - rect.left) / cell), r = Math.floor((ev.clientY - rect.top) / cell);
    var rows = it.blocks.length, cols = it.blocks[0].length;
    if (r < 0 || c < 0 || r >= rows || c >= cols) return null;
    return { r: r, c: c };
  }

  /** 框选拖拽用：坐标夹到画布边界内（拖出画布也能继续定义选区，而不是直接判无效）。 */
  function eventToCellClamped(ev, it) {
    var cell = parseInt($('cellSize').value, 10) || 11;
    var rect = $('cv').getBoundingClientRect();
    var rows = it.blocks.length, cols = it.blocks[0].length;
    var c = Math.floor((ev.clientX - rect.left) / cell), r = Math.floor((ev.clientY - rect.top) / cell);
    r = Math.max(0, Math.min(rows - 1, r)); c = Math.max(0, Math.min(cols - 1, c));
    return { r: r, c: c };
  }

  function normalizeRect(a, b) {
    return { r0: Math.min(a.r, b.r), c0: Math.min(a.c, b.c), r1: Math.max(a.r, b.r), c1: Math.max(a.c, b.c) };
  }

  function inRect(p, rect) { return p.r >= rect.r0 && p.r <= rect.r1 && p.c >= rect.c0 && p.c <= rect.c1; }

  /* ==================== 选区（掩码）助手 ====================
   * 任务 ANT-ARTTOOL-SUBJECT-EXTRACT-20260902
   *
   * 为什么要这一层：原来选区只有矩形，`S.edit.selection` 就够用。新增套索/同色块/按色选之后
   * 选区可能是任意形状，矩形表达不了。做法是：
   *   · `S.edit.mask` 成为选区**权威**；
   *   · `S.edit.selection` 继续维护，但语义收窄为「mask 的外接矩形」，只供既有面板显示尺寸用；
   *   · 所有「取选区内格子」的地方统一走 `selCells()`，不再直接 `cellsInRect(selection)`。
   * 这样既支持不规则选区，又不必把既有三处显示逻辑全部重写。
   */

  /** 按当前工具给画布加样式类（CSS 里 #cv.selecting / #cv.lassoing 会描边提示）。 */
  function syncCanvasToolClass() {
    var cv = $('cv');
    if (!cv) return;
    var t = S.edit.on ? S.edit.tool : null;
    cv.classList.toggle('selecting', t === 'select' || t === 'region' || t === 'color');
    cv.classList.toggle('lassoing', t === 'lasso');
  }

  /** 当前选区掩码（可能为 null）。 */
  function selMask() { return S.edit.mask; }

  /** 当前选区的格子 [{r,c}]；没有选区返回 null（调用方按「全图」处理，与改动前一致）。 */
  function selCells() {
    var m = S.edit.mask;
    if (!m) return null;
    return C.maskToCells(m);
  }

  /** 选区格数（不含「原图这格是不是 0」的判断，纯粹是选了多少格）。 */
  function selCount() { return S.edit.mask ? C.maskCount(S.edit.mask) : 0; }

  /**
   * 设置选区掩码，并把 `S.edit.selection` 同步成它的外接矩形。
   * 传 null = 清空选区。
   */
  function setSelectionMask(m) {
    if (!m || C.maskCount(m) === 0) {
      S.edit.mask = null; S.edit.selection = null; return;
    }
    S.edit.mask = m;
    // 外接矩形：给既有面板显示「选区 W×H / 行 a–b 列 c–d」用。
    var r0 = -1, c0 = -1, r1 = -1, c1 = -1;
    for (var i = 0; i < m.bits.length; i++) {
      if (!m.bits[i]) continue;
      var r = Math.floor(i / m.cols), c = i % m.cols;
      if (r0 < 0 || r < r0) r0 = r;
      if (c0 < 0 || c < c0) c0 = c;
      if (r > r1) r1 = r;
      if (c > c1) c1 = c;
    }
    S.edit.selection = { r0: r0, c0: c0, r1: r1, c1: c1 };
  }

  /** 鼠标事件 → 掩码合成方式：Shift 加选、Alt 减选，都不按就是替换。 */
  /**
   * 这次选取要怎么并进当前选区。
   *
   * 优先级：**修饰键 > 界面单选**。理由：
   *   - 界面单选（2026-09-15 新增）让「交集」可见可发现 —— 上一轮只做 Shift/Alt 隐式快捷键，
   *     用户反馈里明确说「shift和alt的加减工具只能加减不同的颜色」，说明隐藏的组合键既难发现、
   *     也表达不了「区域内同色」这种需要第三种运算的意图；
   *   - 但已经习惯 Shift/Alt 的手感不能破坏，所以按住修饰键时**临时覆盖**界面选择，松手即恢复。
   *
   * 没有给「交集」配修饰键：mac 上 Ctrl+click 会被系统当右键菜单，Cmd 与浏览器快捷键冲突，
   * 两者都不适合当拖拽期间长按的键。交集只走界面单选。
   */
  function combineModeOf(ev) {
    if (ev && ev.shiftKey) return 'add';
    if (ev && (ev.altKey || ev.metaKey)) return 'subtract';
    return selCombineMode();
  }

  /** 界面上「叠加方式」单选的当前值；控件不存在时回退 replace（与本功能上线前的行为一致）。 */
  function selCombineMode() {
    var el = document.querySelector('input[name="selCombine"]:checked');
    var v = el ? el.value : 'replace';
    return (v === 'add' || v === 'subtract' || v === 'intersect') ? v : 'replace';
  }

  /** 把一个新掩码按 Shift/Alt 合成进当前选区。 */
  function applySelection(newMask, ev, label) {
    var mode = combineModeOf(ev);

    // 「交集」在没有当前选区时是个陷阱：maskCombine 的 base=null 分支会直接返回新掩码，
    // 于是「交集 + 按色选」会静默变成**全图该色**——正好是用户想避免的那个结果
    // （实测熊猫图深灰全图 573 格，主体轮廓 505 格会被一起选中）。
    // 与其让它悄悄退化，不如明确拒绝并说清下一步该干什么，选区保持原样不动。
    if (mode === 'intersect' && !S.edit.mask) {
      log('⚠ 叠加方式是「交集」，但当前还没有选区 —— 交集需要先有一个范围才能相交。' +
        '请先用套索或矩形框出要清理的一带，再用这次的选法取交集。（本次未改动选区）');
      return;
    }

    var merged;
    try {
      merged = C.maskCombine(S.edit.mask, newMask, mode);
    } catch (e) {
      // 尺寸不一致：通常是换了关卡但选区没清。如实提示并清掉旧选区，不静默算错。
      log('选区尺寸与当前图不一致（' + e.message + '），已清空旧选区');
      merged = newMask;
    }
    var before = selCount();
    setSelectionMask(merged);
    draw();
    refreshEditPanels();
    renderExtractPanel();
    var n = selCount();
    log((label || '选区') + '：' +
      (mode === 'add' ? '加选' : mode === 'subtract' ? '减选' :
        mode === 'intersect' ? '取交集（' + before + ' → ' + n + ' 格）' : '设定') +
      ' → 当前共 ' + n + ' 格' + (n ? '（' + selRectText() + '）' : ''));
    if (mode === 'intersect' && n === 0) {
      log('　交集为空：这次选的东西与原选区没有重叠部分。选区已变空，可点「取消选区」重来。');
    }
  }

  function selRectText() {
    var s = S.edit.selection;
    if (!s) return '无选区';
    return '行 ' + s.r0 + '–' + s.r1 + '，列 ' + s.c0 + '–' + s.c1 +
      '，外接 ' + (s.c1 - s.c0 + 1) + '×' + (s.r1 - s.r0 + 1);
  }

  /** 清空选区（含套索轨迹与拖拽态）。 */
  function clearSelection() {
    S.edit.mask = null; S.edit.selection = null;
    S.edit.lassoPath = null; S.edit.dragging = false;
    S.edit.dragStart = null; S.edit.dragCurrent = null;
  }

  /**
   * 编辑模式下的画布交互（2026-08-03 微调后）：
   *   工具「拖动绘制」（默认，取代原来的「点选改色」）：按下即落笔，按住拖动连续改色，松开结束。
   *     单击一下仍然只改一格，所以原来点一格改一格的用法没有丢。
   *   工具「框选编辑」：拖拽用于定义/重新定义矩形选区。
   *   「只在选区内绘制」开关已上移到工具行，两种工具下都生效：勾上且已有选区时，
   *     落笔一律限制在选区内，选区外像素不受影响；此时框选工具下的拖拽也变成在选区内绘制。
   *   待替换状态下点画布 = 取消替换而不落笔，避免误触后只能靠撤销回退。
   */
  /** 当前是否只允许在选区内落笔（开关已上移到工具行，两种工具下都生效）。 */
  function paintLimitedToSelection() {
    var el = $('editPaintInSelection');
    return !!(el && el.checked && S.edit.mask);
  }
  /**
   * 落笔前的选区过滤：限制在选区内时，选区外一律不改（选区外像素不受影响）。
   *
   * ⚠ 本轮起按 **掩码** 判定而不是外接矩形。套索/同色块选出来的是不规则形状，
   * 若按外接矩形判，会允许在「矩形内但选区外」的地方落笔 —— 那是错的。
   */
  function paintAllowed(p) {
    if (!p) return false;
    if (!paintLimitedToSelection()) return true;
    var m = S.edit.mask;
    if (m) return C.maskHas(m, p.r, p.c);
    var s = S.edit.selection;
    return !!s && inRect(p, { r0: s.r0, c0: s.c0, r1: s.r1, c1: s.c1 });
  }

  function onCanvasMouseDown(ev) {
    if (!S.edit.on) return;
    var it = cur();
    if (!it || !it.blocks) return;
    // 待替换状态下点画布 = 取消替换，不落笔。避免误触替换后又在图上乱点、只能靠撤销回退。
    if (S.edit.replacing) { cancelColorReplace('在目标图上点击'); return; }

    // ===== 主体提取的三种新选法（任务 ANT-ARTTOOL-SUBJECT-EXTRACT-20260902）=====
    // 这三种都是「一次点击即出选区」或「拖出轨迹」，不落笔改色，所以放在绘制分支之前。
    var rowsN = it.blocks.length, colsN = it.blocks[0] ? it.blocks[0].length : 0;
    if (S.edit.tool === 'region') {
      var pr = eventToCell(ev, it);
      if (!pr) return;
      applySelection(C.maskFromSameColorRegion(it.blocks, pr.r, pr.c), ev,
        '同色块 (' + pr.r + ',' + pr.c + ') 色' + it.blocks[pr.r][pr.c]);
      return;
    }
    if (S.edit.tool === 'color') {
      var pc = eventToCell(ev, it);
      if (!pc) return;
      var cid = it.blocks[pc.r][pc.c];
      applySelection(C.maskFromColor(it.blocks, cid), ev, '按色选 色' + cid);
      return;
    }
    if (S.edit.tool === 'lasso') {
      var pl = eventToCellClamped(ev, it);
      S.edit.dragging = true;
      S.edit.lassoPath = [pl];
      S.edit.dragStart = pl; S.edit.dragCurrent = pl;
      draw();
      return;
    }
    if (S.edit.tool === 'select' && !paintLimitedToSelection()) {
      var p0 = eventToCellClamped(ev, it);
      S.edit.dragging = true; S.edit.lassoPath = null;
      S.edit.dragStart = p0; S.edit.dragCurrent = p0;
      draw();
      return;
    }
    // 拖动绘制（默认工具）：按下即落笔并进入拖拽状态，移动时连续改色。
    // 原「点选改色」工具已按用户 2026-08-03 微调要求删除，改色一律走拖动绘制这一套。
    var p = eventToCell(ev, it);
    if (!paintAllowed(p)) return;
    S.edit.paintDragging = true;
    editApplyColor([{ r: p.r, c: p.c }]);
  }

  function onCanvasMouseMove(ev) {
    if (!S.edit.on) return;
    var it = cur();
    if (!it || !it.blocks) return;
    if (S.edit.dragging) {
      var pm = eventToCellClamped(ev, it);
      S.edit.dragCurrent = pm;
      // 套索：把移动轨迹逐格记下来。同一格连续移动不重复 push，否则轨迹会膨胀到几千点、
      // 射线法逐点算会明显卡（20×20 的图不明显，55×55 会）。
      if (S.edit.lassoPath) {
        var last = S.edit.lassoPath[S.edit.lassoPath.length - 1];
        if (!last || last.r !== pm.r || last.c !== pm.c) S.edit.lassoPath.push(pm);
      }
      draw();
      return;
    }
    if (!S.edit.paintDragging) return;
    var p = eventToCell(ev, it);
    if (paintAllowed(p)) editApplyColor([p]);
  }

  function finishSelectionDrag(ev) {
    if (!S.edit.dragging) return;
    S.edit.dragging = false;
    var it = cur();
    if (!it || !it.blocks) { S.edit.lassoPath = null; return; }
    var rowsN = it.blocks.length, colsN = it.blocks[0].length;

    if (S.edit.lassoPath) {
      var path = S.edit.lassoPath;
      S.edit.lassoPath = null;
      applySelection(C.maskFromPolygon(rowsN, colsN, path), ev,
        '套索（轨迹 ' + path.length + ' 格）');
      return;
    }
    var rect = normalizeRect(S.edit.dragStart, S.edit.dragCurrent);
    applySelection(C.maskFromRect(rowsN, colsN, rect.r0, rect.c0, rect.r1, rect.c1), ev,
      '矩形框选 行 ' + rect.r0 + '–' + rect.r1 + '，列 ' + rect.c0 + '–' + rect.c1);
  }

  function onCanvasMouseUp(ev) {
    finishSelectionDrag(ev);
    S.edit.paintDragging = false;
  }

  /* ==================== 12. 主体提取 ====================
   * 任务 ANT-ARTTOOL-SUBJECT-EXTRACT-20260902
   *
   * 用户目的：把主体人工提取出来、去掉边缘杂物，输出只含主体的像素图纸；
   * 之后要能再导入回来**拼接**，让一关有多个主体去做目标引导趋势。
   * 因此：剔除**保持原尺寸**、空位写 **0** —— 拼接时行列坐标才对得上。
   */

  /** 当前是否具备剔除条件（有图 + 有选区）。 */
  function extractReady() {
    var it = cur();
    return !!(it && it.blocks && S.edit.mask && C.maskCount(S.edit.mask) > 0);
  }

  /**
   * 执行剔除。mode: 'outside' 只保留选区内 / 'inside' 挖空选区内。
   * 整张图快照进 S.extract.undo（剔除一次可能动几百格，逐像素记反而更大）。
   */
  function doExtract(mode) {
    var it = cur();
    if (!extractReady()) { log('请先框出选区（在「8. 美术编辑」里选一种选区工具）'); return; }
    var before = it.blocks.map(function (r) { return r.slice(); });
    var res;
    try { res = C.applyExtract(it.blocks, S.edit.mask, mode); }
    catch (e) { log('剔除失败：' + e.message); return; }
    if (res.removed === 0) {
      log('这一步没有剔掉任何像素（' + (mode === 'inside' ? '选区内本来就是空的' : '选区已覆盖全部非空像素') + '），未改动');
      return;
    }
    S.extract.undo.push(before);
    S.extract.lastResult = res;
    it.blocks = res.blocks;
    // 编辑模式的「还原为原图」也要能把提取一并还原，所以这里补上原图快照
    if (!S.edit.original) S.edit.original = before.map(function (r) { return r.slice(); });
    invalidateAfterBlocksChange();
    log('已' + (mode === 'inside' ? '挖空选区内' : '剔掉选区外') +
      '：剔除 ' + res.removed + ' 像素，剩余 ' + res.after + ' 像素（尺寸仍是 ' + res.rows + '×' + res.cols + '，空位写 0）');
  }

  function undoExtract() {
    if (!S.extract.undo.length) return;
    var it = cur();
    if (!it) return;
    it.blocks = S.extract.undo.pop();
    S.extract.lastResult = null;
    invalidateAfterBlocksChange();
    log('已撤销上一步剔除（剩 ' + S.extract.undo.length + ' 步可撤销）');
  }

  function resetExtract() {
    var it = cur();
    if (!it || !S.edit.original) { log('没有可还原的原图快照'); return; }
    it.blocks = S.edit.original.map(function (r) { return r.slice(); });
    S.extract.undo = [];
    S.extract.lastResult = null;
    invalidateAfterBlocksChange();
    log('已还原为原图');
  }

  /**
   * 目标图被改动后，需要一起失效/刷新的东西。
   * 剔除会大幅改变像素，任何基于旧图算出来的结论（碎色率、时间线、区间、重构结果）
   * 都不能继续显示，否则用户会看到与当前图不符的数字。
   */
  function invalidateAfterBlocksChange() {
    var it = cur();
    if (it) {
      it.tl = null;                 // 时间线（求解路线）失效：像素变了，旧路线不成立
      it.interval = null;
      it.reconResult = null;
      fragState.result = null; fragState.key = null;   // 碎色率要重算
    }
    draw();
    renderEditInfo();
    refreshEditPanels();
    renderExtractPanel();
    refreshPressureChart();
  }

  /** 自动选法辅助①：四个角各自的同色连通块合并成选区。 */
  function pickBgCorners() {
    var it = cur();
    if (!it || !it.blocks) return;
    var rowsN = it.blocks.length, colsN = it.blocks[0].length;
    var corners = [[0, 0], [0, colsN - 1], [rowsN - 1, 0], [rowsN - 1, colsN - 1]];
    var m = C.maskNew(rowsN, colsN);
    corners.forEach(function (p) {
      m = C.maskCombine(m, C.maskFromSameColorRegion(it.blocks, p[0], p[1]), 'add');
    });
    setSelectionMask(m);
    draw(); refreshEditPanels(); renderExtractPanel();
    var n = C.maskCount(m), tot = rowsN * colsN;
    log('已选四角同色块：' + n + ' 格（占全图 ' + (n / tot * 100).toFixed(0) + '%）。' +
      '若比例很低说明这张图的边缘是杂色或密铺纹理，自动选法帮不上，请手动框选或套索');
  }

  /** 自动选法辅助②：非 0 像素的最大四连通块 → 选区（配「只保留选区内」用）。 */
  function selectLargestComponent() {
    var it = cur();
    if (!it || !it.blocks) return;
    var comps = C.nonZeroComponents(it.blocks);
    if (!comps.length) { log('图里没有非 0 像素'); return; }
    var rowsN = it.blocks.length, colsN = it.blocks[0].length;
    setSelectionMask(C.maskFromIndices(comps[0], rowsN, colsN));
    draw(); refreshEditPanels(); renderExtractPanel();
    log('已选最大连通块：' + comps[0].length + ' 格（全图共 ' + comps.length + ' 块，' +
      '各块大小 ' + comps.slice(0, 6).map(function (x) { return x.length; }).join('/') +
      (comps.length > 6 ? '…' : '') + '）。' +
      (comps.length === 1 ? '⚠ 只有 1 块 —— 说明全图连通，这一招对这张图没用' : ''));
  }

  /**
   * 选中所有「不超过阈值格」的零碎小块（2026-09-15 需求①②的收尾手段）。
   *
   * 与 selectLargestComponent 的分工：
   *   - 只留最大连通块：只认第 1 块，第 2 大块再有用也一起清掉 —— 图上只有一个部件时才合适；
   *   - 选中零碎小块：按**尺寸阈值**判，能留下次大的有效部件，只清真正的碎渣。
   * 实测熊猫图（已剔掉背景）非 0 共 24 块：主体 2206 格，其余 23 块合计 103 格、单块最大 37 格，
   * 阈值 40 正好一次清净且不碰主体。
   *
   * 注意这一招只对**已经剔出空白**的图有效：蜗牛图与财神爷图非 0 像素仍连成 1 块，
   * 此时任何按连通块的手段都无从下手，只能靠套索 + 区域内同色。故这里如实提示，不假装有效。
   */
  function selectSmallComponents() {
    var it = cur();
    if (!it || !it.blocks) return;
    var maxEl = $('inSmallCompMax');
    var lim = maxEl ? parseInt(maxEl.value, 10) : 40;
    if (!isFinite(lim) || lim < 1) { log('「不超过 N 格」需要填一个 ≥1 的整数'); return; }
    var comps = C.nonZeroComponents(it.blocks);
    if (!comps.length) { log('图里没有非 0 像素'); return; }
    if (comps.length === 1) {
      log('⚠ 全图非 0 像素只有 1 块（' + comps[0].length + ' 格）—— 没有独立的零碎块可清。' +
        '这一招要等你先剔掉背景、图上出现空白之后才用得上。' +
        '现在请用套索圈边缘 + 叠加方式「交集」+ 按色选来去毛边。');
      return;
    }
    var rowsN = it.blocks.length, colsN = it.blocks[0].length;
    var m = C.maskFromSmallComponents(it.blocks, lim);
    var n = C.maskCount(m);
    var hit = comps.filter(function (x) { return x.length <= lim; }).length;
    if (!n) {
      log('没有不超过 ' + lim + ' 格的小块（当前各块大小：' +
        comps.slice(0, 8).map(function (x) { return x.length; }).join('/') +
        (comps.length > 8 ? '…' : '') + '）。可以把阈值调大一点。');
      return;
    }
    // 阈值过大把主体也圈进来时必须说清，否则一剔就把图清空了
    var takesMain = m.bits[comps[0][0]] === 1;
    setSelectionMask(m);
    draw(); refreshEditPanels(); renderExtractPanel();
    log('已选中 ' + hit + ' 个小块、共 ' + n + ' 格（阈值 ≤' + lim + ' 格；全图 ' + comps.length +
      ' 块，最大块 ' + comps[0].length + ' 格）。' +
      (takesMain
        ? '⚠ 阈值太大，**最大块也被选中了** —— 这样剔除会把主体一起清掉，请把阈值调小到 ' +
        comps[0].length + ' 以下'
        : '主体（最大块 ' + comps[0].length + ' 格）不在选区内，可以直接「挖空选区内」'));
  }

  /** 主体提取面板。 */
  function renderExtractPanel() {
    var box = $('extractInfo');
    if (!box) return;
    var it = cur();
    if (!it || !it.blocks) { box.innerHTML = '<div class="muted">请先选一关</div>'; syncExtractButtons(); return; }
    var rowsN = it.blocks.length, colsN = it.blocks[0].length;
    var nz = 0;
    for (var r = 0; r < rowsN; r++) for (var c = 0; c < colsN; c++) if (it.blocks[r][c] > 0) nz++;
    var tot = rowsN * colsN;
    var selN = selCount();
    var selNz = 0;
    if (S.edit.mask) {
      var cells = selCells();
      for (var i = 0; i < cells.length; i++) if (it.blocks[cells[i].r][cells[i].c] > 0) selNz++;
    }
    var rows = [
      ['画布尺寸', rowsN + ' × ' + colsN + '（' + tot + ' 格，<b>剔除不改变尺寸</b>）'],
      ['当前非空像素', '<span class="num">' + nz + '</span> / ' + tot +
        '（空位 ' + (tot - nz) + ' 格 = 值为 0）'],
      ['选区', selN ? '<span class="num">' + selN + '</span> 格，其中有像素的 ' + selNz + ' 格　' + selRectText()
        : '<span class="warnText">未选</span> —— 在「8. 美术编辑」里勾「开启编辑模式」并选一种选区工具']
    ];
    if (S.edit.mask) {
      rows.push(['剔掉框外会剩', '<span class="num">' + selNz + '</span> 像素（剔除 ' + (nz - selNz) + '）']);
      rows.push(['挖空框内会剩', '<span class="num">' + (nz - selNz) + '</span> 像素（剔除 ' + selNz + '）']);
    }
    var lr = S.extract.lastResult;
    if (lr) {
      rows.push(['上一步', (lr.mode === 'inside' ? '挖空选区内' : '剔掉选区外') +
        '，剔除 ' + lr.removed + ' → 剩 ' + lr.after + ' 像素']);
    }
    var bb = C.bboxOfBlocks(it.blocks);
    rows.push(['主体外接矩形', bb
      ? '行 ' + bb.r0 + '–' + bb.r1 + '，列 ' + bb.c0 + '–' + bb.c1 + '（' + bb.rows + '×' + bb.cols + '）' +
        '<br><span class="hint">拼接时用它做平移。画布仍是 ' + rowsN + '×' + colsN + '，坐标口径不变</span>'
      : '<span class="badText">全空</span>']);
    box.innerHTML = kvTable(rows);
    syncExtractButtons();
  }

  function syncExtractButtons() {
    var ok = extractReady();
    var it = cur();
    if ($('btnExtractOutside')) $('btnExtractOutside').disabled = !ok;
    if ($('btnExtractInside')) $('btnExtractInside').disabled = !ok;
    if ($('btnExtractUndo')) $('btnExtractUndo').disabled = !S.extract.undo.length;
    if ($('btnExtractReset')) $('btnExtractReset').disabled = !(S.edit.original && it && it.blocks);
    if ($('btnAddPiece')) $('btnAddPiece').disabled = !(it && it.blocks && C.bboxOfBlocks(it.blocks));
  }

  /* ==================== 图纸库 ====================
   * 与「11. 待导出库」（关卡条目）**分开存放**，单独一个 localStorage key。
   * 理由（实读确认）：批量导出关卡时会无条件读 `e.originalLevel` / `e.reconstructedLevel`，
   * 一个只有像素矩阵的图纸条目混进那个数组会让批量导出直接抛错。分开存最省事也最安全。
   */

  /** HTML 转义（图纸名是用户输入的，直接拼进 innerHTML 会有注入风险）。 */
  function escHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  /** 文件名安全化（去掉路径分隔符与 Windows 非法字符）。 */
  function safeFileName(s) {
    return String(s == null || s === '' ? 'piece' : s).replace(/[\\/:*?"<>|]/g, '_');
  }

  function loadPieceLib() {
    try {
      var raw = localStorage.getItem(PIECE_LIB_STORAGE_KEY);
      S.pieceLib = raw ? (JSON.parse(raw) || []) : [];
    } catch (e) {
      S.pieceLib = [];
      log('图纸库读取失败（' + (e && e.message) + '），已重置为空');
    }
    // 只留结构完整的条目，坏条目如实报出来而不是静默丢
    var bad = S.pieceLib.filter(function (e) { return !e || e.type !== C.ART_PIECE_TYPE || !e.blocks; });
    if (bad.length) {
      S.pieceLib = S.pieceLib.filter(function (e) { return e && e.type === C.ART_PIECE_TYPE && e.blocks; });
      log('图纸库里有 ' + bad.length + ' 条结构不完整，已跳过（其余 ' + S.pieceLib.length + ' 条正常）');
    }
  }

  function savePieceLib() {
    try {
      localStorage.setItem(PIECE_LIB_STORAGE_KEY, JSON.stringify(S.pieceLib));
      return { ok: true };
    } catch (e) {
      var quota = /quota|exceeded/i.test(String(e && e.name) + String(e && e.message));
      return { ok: false, error: (e && e.message) || String(e), quota: quota };
    }
  }

  function pieceLibBytes() {
    try { return JSON.stringify(S.pieceLib).length; } catch (e) { return 0; }
  }

  /** 把当前目标图作为一张图纸入库。 */
  function addCurrentAsPiece() {
    var it = cur();
    if (!it || !it.blocks) { log('请先选一关'); return; }
    var nameInput = $('inPieceName');
    var base = (nameInput && nameInput.value.trim()) || String(it.key || 'piece');
    // 同名自动加序号，避免静默覆盖用户已攒的图纸
    var key = base, n = 2;
    while (S.pieceLib.some(function (e) { return e.key === key; })) { key = base + '_' + n; n++; }
    var piece;
    try {
      piece = C.toArtPiece(it.blocks, {
        key: key,
        sourceName: it.key || null,
        ops: S.extract.lastResult
          ? [{ mode: S.extract.lastResult.mode, removed: S.extract.lastResult.removed }]
          : []
      });
    } catch (e) { log('入库失败：' + e.message); return; }

    S.pieceLib.push(piece);
    var res = savePieceLib();
    if (!res.ok) {
      S.pieceLib.pop();
      savePieceLib();
      renderPieceLib();
      log('⚠ 图纸库加入失败，已取消本次加入（内存与本地保存都没变，避免刷新后静默丢失）。原因：' + res.error +
        (res.quota ? '。这是浏览器本地存储配额（每站点约 5 MB），当前图纸库 ' + kb(pieceLibBytes()) +
          '，关卡待导出库 ' + kb(exportLibBytes()) + '。请先导出再清空腾空间。' : ''));
      return;
    }
    if (nameInput) nameInput.value = '';
    renderPieceLib();
    log('图纸库：已加入「' + key + '」（' + piece.pixelCount + ' 像素，' +
      piece.rows + '×' + piece.cols + '，外接 ' + piece.bbox.rows + '×' + piece.bbox.cols +
      '），当前共 ' + S.pieceLib.length + ' 张');
  }

  function removePiece(key) {
    S.pieceLib = S.pieceLib.filter(function (e) { return e.key !== key; });
    savePieceLib();
    renderPieceLib();
    log('图纸库：已移除「' + key + '」');
  }

  /** 把某张图纸载回当前关的目标图（供检查，也是「再导入回来」的第一步）。 */
  function loadPieceIntoCurrent(key) {
    var it = cur();
    if (!it) { log('请先选一关'); return; }
    var p = S.pieceLib.filter(function (e) { return e.key === key; })[0];
    if (!p) return;
    if (p.rows !== it.blocks.length || p.cols !== it.blocks[0].length) {
      log('⚠ 图纸尺寸 ' + p.rows + '×' + p.cols + ' 与当前关目标图 ' +
        it.blocks.length + '×' + it.blocks[0].length + ' 不一致，没有载入。' +
        '拼接需要同尺寸画布，请换一关或换一张图纸');
      return;
    }
    if (!S.edit.original) S.edit.original = it.blocks.map(function (r) { return r.slice(); });
    S.extract.undo.push(it.blocks.map(function (r) { return r.slice(); }));
    it.blocks = p.blocks.map(function (r) { return r.slice(); });
    clearSelection();
    invalidateAfterBlocksChange();
    log('已把图纸「' + key + '」载入当前关的目标图（' + p.pixelCount + ' 像素）。可用「撤销上一步剔除」退回');
  }

  /** 图纸库面板：水位 + 列表（含缩略图）。 */
  function renderPieceLib() {
    var info = $('pieceLibInfo'), list = $('pieceLibList');
    if (!info || !list) return;
    var st = C.artPieceStats(S.pieceLib);
    var chars = pieceLibBytes();
    var usedMB = chars * 2 / 1024 / 1024;      // localStorage 按 UTF-16 计费
    var rows = [
      ['图纸数', st.count + ' 张（本地保存，刷新不丢）'],
      ['本地占用', usedMB.toFixed(3) + ' MB（图纸库自己；关卡待导出库另占 ' +
        (exportLibBytes() * 2 / 1024 / 1024).toFixed(2) + ' MB，两者共用每站点约 5 MB 配额）']
    ];
    if (st.count) {
      rows.push(['尺寸分布', Object.keys(st.sizes).map(function (k) { return k + '×' + st.sizes[k] + '张'; }).join('　')]);
      rows.push(['像素数', '最少 ' + st.pixel.min + '　中位 ' + st.pixel.median + '　最多 ' + st.pixel.max +
        '　合计 ' + st.pixel.sum]);
      rows.push(['用到的颜色', st.colorUnion.length + ' 种：' + st.colorUnion.join(' ')]);
    }
    info.innerHTML = kvTable(rows);

    if (!S.pieceLib.length) {
      list.innerHTML = '<div class="item muted">还没有图纸。框出主体 → 剔除 → 「加入图纸库」</div>';
      return;
    }
    list.innerHTML = S.pieceLib.map(function (e) {
      return '<div class="item" data-key="' + escHtml(e.key) + '">' +
        '<canvas class="pieceThumb" data-key="' + escHtml(e.key) + '" width="34" height="34"></canvas>' +
        '<span class="nm" title="' + escHtml(e.key) + '">' + escHtml(e.key) + '</span>' +
        '<span class="px">' + e.pixelCount + 'px</span>' +
        '<span class="bb">' + e.rows + '×' + e.cols + '</span>' +
        '<button class="btn tiny pieceLoad" data-key="' + escHtml(e.key) + '" title="把这张图纸载入当前关的目标图">载入</button>' +
        '<button class="btn tiny ghost pieceDel" data-key="' + escHtml(e.key) + '">移除</button>' +
        '</div>';
    }).join('');
    // 缩略图：逐格画，尺寸小所以直接画不做缓存
    Array.prototype.forEach.call(list.querySelectorAll('.pieceThumb'), function (cv) {
      var e = S.pieceLib.filter(function (x) { return x.key === cv.getAttribute('data-key'); })[0];
      if (!e) return;
      var ctx = cv.getContext('2d');
      var cell = Math.max(1, Math.floor(Math.min(cv.width / e.cols, cv.height / e.rows)));
      ctx.fillStyle = '#241a12'; ctx.fillRect(0, 0, cv.width, cv.height);
      for (var r = 0; r < e.rows; r++) for (var c = 0; c < e.cols; c++) {
        var v = e.blocks[r][c];
        if (v <= 0) continue;
        ctx.fillStyle = window.AntSolver.getColorCSS(v);
        ctx.fillRect(c * cell, r * cell, cell, cell);
      }
    });
    Array.prototype.forEach.call(list.querySelectorAll('.pieceDel'), function (el) {
      el.onclick = function () { removePiece(el.getAttribute('data-key')); };
    });
    Array.prototype.forEach.call(list.querySelectorAll('.pieceLoad'), function (el) {
      el.onclick = function () { loadPieceIntoCurrent(el.getAttribute('data-key')); };
    });
  }

  /** 导出图纸库 ZIP：图纸/<名>.txt + 清单.csv + 说明.md。 */
  function exportPieceLibZip() {
    if (!S.pieceLib.length) { log('图纸库是空的'); return; }
    var files = [];
    var head = ['图纸名', '画布行', '画布列', '非空像素', '外接行起', '外接行止', '外接列起', '外接列止',
      '外接高', '外接宽', '颜色数', '来源图', '提取操作', '入库时间'];
    var csv = [head.join(',')];
    S.pieceLib.forEach(function (e) {
      files.push({ name: '图纸/' + safeFileName(e.key) + '.txt', text: C.serializeTxt(e.blocks) });
      var bb = e.bbox || {};
      csv.push([
        '"' + String(e.key).replace(/"/g, '""') + '"',
        e.rows, e.cols, e.pixelCount,
        bb.r0, bb.r1, bb.c0, bb.c1, bb.rows, bb.cols,
        e.colorCount,
        '"' + String((e.source && e.source.sourceName) || '').replace(/"/g, '""') + '"',
        '"' + ((e.source && e.source.ops) || []).map(function (o) {
          return (o.mode === 'inside' ? '挖空选区内' : o.mode === 'outside' ? '剔掉选区外' : (o.mode || '')) +
            (o.removed != null ? '(' + o.removed + ')' : '');
        }).join(';') + '"',
        (e.source && e.source.extractedAt) || ''
      ].join(','));
    });
    files.push({ name: '清单.csv', text: csv.join('\n') + '\n' });

    var st = C.artPieceStats(S.pieceLib);
    var L = [];
    L.push('# 主体图纸库导出');
    L.push('');
    L.push('- 导出时间：' + new Date().toISOString());
    L.push('- 图纸数：' + st.count);
    L.push('- 尺寸分布：' + Object.keys(st.sizes).map(function (k) { return k + ' × ' + st.sizes[k] + ' 张'; }).join('、'));
    if (st.pixel) L.push('- 非空像素：最少 ' + st.pixel.min + '　中位 ' + st.pixel.median + '　最多 ' + st.pixel.max + '　合计 ' + st.pixel.sum);
    L.push('- 用到的颜色：' + st.colorUnion.join(' '));
    L.push('');
    L.push('## 目录');
    L.push('');
    L.push('```');
    L.push('图纸/    <名>.txt   只含主体的像素图纸（首行「像素矩阵」+ 空格分隔色号）');
    L.push('清单.csv            逐张一行，含画布尺寸、非空像素、外接矩形、来源与提取操作');
    L.push('说明.md             本文件');
    L.push('```');
    L.push('');
    L.push('## 口径');
    L.push('');
    L.push('- **画布保持原尺寸**，被剔除的位置写 `0`。这样多张图纸的行列坐标是同一套，');
    L.push('  之后再导入回来做**拼接**时能直接叠加，不需要平移换算。');
    L.push('- `0` 在本项目里就是「空、不参与」：正式 `parseLevel` 只统计 `> 0` 的像素。');
    L.push('- 清单里的**外接矩形**是主体的实际占位，拼接时判断两个部件会不会重叠、要不要平移，看它。');
    L.push('- 本工具只做美术侧提取，**不生成关卡**。关卡生产侧的适配另行处理。');
    files.push({ name: '说明.md', text: L.join('\n') + '\n' });

    download('主体图纸库_' + S.pieceLib.length + '张_' + exportStamp() + '.zip', zipCreateBinary(files));
    log('已导出图纸库 ZIP：' + S.pieceLib.length + ' 张，' + files.length + ' 个文件');
  }

  function exportPieceLibJson() {
    if (!S.pieceLib.length) { log('图纸库是空的'); return; }
    download('主体图纸库_' + S.pieceLib.length + '张_' + exportStamp() + '.json',
      new Blob([JSON.stringify({
        type: 'antArtPieceLibrary', version: 1,
        count: S.pieceLib.length, exported: new Date().toISOString(),
        pieces: S.pieceLib
      }, null, 1)], { type: 'application/json' }));
    log('已导出图纸库 JSON（' + S.pieceLib.length + ' 张）');
  }

  function importPieceLibJson(file) {
    var fr = new FileReader();
    fr.onload = function () {
      var j = null;
      try { j = JSON.parse(fr.result); } catch (e) { log('图纸库 JSON 解析失败：' + (e && e.message)); return; }
      var arr = (j && Array.isArray(j.pieces)) ? j.pieces : (Array.isArray(j) ? j : null);
      if (!arr) { log('这个文件里找不到 pieces 数组，没有导入'); return; }
      var okN = 0, skip = 0, renamed = 0;
      arr.forEach(function (p) {
        if (!p || p.type !== C.ART_PIECE_TYPE || !p.blocks || !p.blocks.length) { skip++; return; }
        var key = p.key || 'piece', n = 2;
        while (S.pieceLib.some(function (e) { return e.key === key; })) { key = (p.key || 'piece') + '_' + n; n++; renamed++; }
        p.key = key;
        S.pieceLib.push(p); okN++;
      });
      var res = savePieceLib();
      renderPieceLib();
      log('图纸库导入：成功 ' + okN + ' 张' + (renamed ? '（其中 ' + renamed + ' 张同名已改名）' : '') +
        (skip ? '，跳过 ' + skip + ' 条结构不完整' : '') +
        (res.ok ? '' : '　⚠ 本地保存失败：' + res.error));
    };
    fr.readAsText(file);
  }

  function clearPieceLib() {
    if (!S.pieceLib.length) return;
    if (!window.confirm('清空图纸库？共 ' + S.pieceLib.length + ' 张，此操作不可撤销。建议先「导出图纸库」。')) return;
    S.pieceLib = [];
    savePieceLib();
    renderPieceLib();
    log('图纸库已清空');
  }

  // ==================== 绑定 ====================
  function init() {
    if (!window.AntSolver || !window.AntSolver.Solver) {
      // 页面上只说清「要怎么做」，不写脚本路径（需求 §七第6点）
      $('envInfo').innerHTML = '<span style="color:#ff8080">没有载入正式求解器与生成器：请用「一键启动.command」从项目根目录打开本工具</span>';
      log('无法启动：没有载入正式求解器与生成器，请用「一键启动.command」从项目根目录打开本工具');
      return;
    }
    $('envInfo').textContent = '求解与生成使用工具自带的正式代码副本 · 生成器流程 ' +
      (window.AntSolver.Generator ? window.AntSolver.Generator.FLOW : '未载入') +
      ' · 冰耐久 ' + C.ICE_DURABILITY + ' · 暂存上限 ' + C.BUFFER_LIMIT;

    $('fileInput').onchange = function (e) { readFiles(e.target.files, false); e.target.value = ''; };
    $('dirInput').onchange = function (e) { readFiles(e.target.files, true); e.target.value = ''; };
    $('listFilter').oninput = renderList;
    $('btnClear').onclick = function () {
      demoPause();
      S.items = []; S.index = {}; S.cur = -1;
      S.demo.idx = 0; S.edit.on = false; S.edit.original = null; S.edit.undoStack = [];
      clearSelection(); S.edit.replacing = null; S.edit.paintDragging = false;
      if ($('optEdit')) $('optEdit').checked = false;
      $('cv').classList.remove('editing');
      $('boardCompareWrap').classList.add('hidden'); $('boardCompareWrap').innerHTML = '';
      renderList(); renderSolveInfo(); refreshEditPanels(); renderEditInfo();
      $('intervalInfo').innerHTML = ''; $('routeInfo').innerHTML = ''; $('demoInfo').innerHTML = '';
      resetReconView();
      $('importStat').textContent = '未导入';
      $('readout').textContent = '把鼠标移到目标图上可查看该像素的颜色、消除步序与所属区间。';
      refreshBoardPanel();
      refreshPressureChart();
      draw();
    };
    $('btnSolve').onclick = function () { ensureTimeline(function () { draw(); }, true); };
    $('btnLocate').onclick = locate;
    $('btnRoutes').onclick = runRoutes;
    $('btnPng').onclick = exportPng;
    $('btnJson').onclick = exportJson;
    Array.prototype.forEach.call(document.querySelectorAll('.presets .btn'), function (b) {
      b.onclick = function () {
        $('loPct').value = b.getAttribute('data-lo');
        $('hiPct').value = b.getAttribute('data-hi');
        if (cur() && cur().tl) locate();
      };
    });
    ['optComp', 'optDim', 'optGrid', 'optA', 'showStable', 'showFrequent', 'showFloating'].forEach(function (id) { $(id).onchange = draw; });
    $('cellSize').oninput = function () { draw(); if (S.demo.idx > 0) demoRenderAtIdx(); };
    $('cv').onmousemove = function (ev) { onHover(ev); onCanvasMouseMove(ev); };
    $('cv').onmousedown = onCanvasMouseDown;
    $('cv').onmouseup = onCanvasMouseUp;
    // 拖拽框选中途移出画布再松开鼠标时，画布自身的 mouseup 不会触发（鼠标已经不在画布上），
    // 靠 document 级兜底监听结束选区，避免拖拽状态卡死（参考编辑器 ui.js 同样有这个兜底）。
    document.addEventListener('mouseup', function () { if (S.edit.dragging || S.edit.paintDragging) onCanvasMouseUp(); });

    // 6. 棋盘区 + 暂存对比
    $('optBoard').onchange = refreshBoardPanel;

    // 7. 自动演示
    $('btnDemoPlay').onclick = demoPlay;
    $('btnDemoPause').onclick = demoPause;
    $('btnDemoStepBack').onclick = function () { demoStep(-1); };
    $('btnDemoStepFwd').onclick = function () { demoStep(1); };
    // 跳到A/B/末尾统一按「当前正在查看的视图对象」（viewItem，随 S.viewMode 切原关卡/重构后关卡）处理，
    // 不再用 cur()（真实关卡条目）——否则查看重构后关卡时点这三个按钮，会跳到原关卡的区间/步数上去。
    $('btnDemoJumpA').onclick = function () { var it = viewItem(); if (it && it.interval) demoJump(it.interval.stepIndex.lo); };
    $('btnDemoJumpB').onclick = function () { var it = viewItem(); if (it && it.interval) demoJump(it.interval.stepIndex.hi); };
    $('btnDemoJumpEnd').onclick = function () { var it = viewItem(); if (it && it.tl) demoJump(it.tl.steps.length); };
    $('demoScrub').oninput = function () { demoJump(parseInt($('demoScrub').value, 10) || 0); };
    $('optDemoRegion').onchange = function () { if (S.demo.idx >= 0) demoRenderAtIdx(); };

    // 8. 美术编辑（点选改色 / 框选编辑 + 全局/局部替换 + 靠色检查）
    $('optEdit').onchange = function () { toggleEditMode($('optEdit').checked); };
    Array.prototype.forEach.call(document.querySelectorAll('input[name="editTool"]'), function (r) {
      r.onchange = function () {
        S.edit.tool = r.value;
        // 切工具时清掉进行中的拖拽与套索轨迹，否则残留状态会让下一次落笔或框选行为诡异
        S.edit.dragging = false; S.edit.paintDragging = false; S.edit.lassoPath = null;
        syncCanvasToolClass();
        draw();
        renderExtractPanel();
        var mo = selCombineMode();
        var moName = { replace: '替换', add: '加选', subtract: '减选', intersect: '交集' }[mo];
        var tips = {
          paint: '拖动绘制：按住在图上拖，连续改色',
          select: '矩形框选：拖出矩形',
          lasso: '套索：按住拖出任意形状，松手自动闭合',
          region: '同色块：点一下选中与该格同色且四连通的整块',
          color: '按色选：点一下选中该颜色的全部像素（不管连不连通）'
        };
        if (tips[r.value]) {
          var extra = '';
          if (r.value !== 'paint') {
            extra = '　当前叠加方式：' + moName + '（Shift 临时加选、Alt 临时减选）';
            // 「按色选 + 替换」是最容易毁主体的组合：会一次选中全图该色。这里主动点出来。
            if (r.value === 'color' && mo === 'replace') {
              extra += '。要只清边缘、保住主体轮廓，请先圈范围再把叠加方式改成「交集」';
            }
          }
          log(tips[r.value] + extra);
        }
      };
    });
    Array.prototype.forEach.call(document.querySelectorAll('input[name="selCombine"]'), function (r) {
      r.onchange = function () {
        if (!r.checked) return;
        var msg = {
          replace: '叠加方式：替换 —— 每次选取都丢掉旧选区',
          add: '叠加方式：加选 —— 每次选取都并到当前选区上',
          subtract: '叠加方式：减选 —— 每次选取都从当前选区里挖掉',
          intersect: '叠加方式：交集 —— 只留下与当前选区重叠的部分。' +
            '配「按色选」用就是「只选当前选区里的这个颜色」，主体其它地方的同色不受影响'
        }[r.value];
        if (msg) log(msg);
        if (r.value === 'intersect' && !S.edit.mask) {
          log('　提醒：交集需要先有一个选区。请先用套索或矩形框出范围。');
        }
        renderExtractPanel();
      };
    });
    $('editPaintInSelection').onchange = function () { }; // 只是读取用的勾选框，不需要额外动作
    initFloatPanels();
    // 待替换状态的取消途径（微调第 2 项）：点空白处、按 Esc。
    // 点色块/替换按钮/状态条本身不算「空白处」，否则会把正常的替换操作也取消掉。
    document.addEventListener('mousedown', function (ev) {
      if (!S.edit.replacing) return;
      var t = ev.target;
      if (!t.closest) return;
      if (t.closest('#editPalette') || t.closest('#editSelectionColors') || t.closest('#editReplaceStatus')) return;
      if (t === $('cv')) return;   // 画布由 onCanvasMouseDown 自己处理取消，避免重复提示
      cancelColorReplace('点了空白处');
    });
    document.addEventListener('keydown', function (ev) {
      // 拼接工作台：方向键逐格微调选中图层。鼠标拖到像素级很难对准，这一步是必需的。
      // 只在拼接模式且焦点不在输入框里时接管，否则会把输入框里的光标移动也吃掉。
      if (cpS().active) {
        var tag = (ev.target && ev.target.tagName || '').toLowerCase();
        if (tag !== 'input' && tag !== 'textarea' && tag !== 'select') {
          var step = ev.shiftKey ? 5 : 1;      // Shift = 一次挪 5 格，粗调更快
          var d = { ArrowUp: [-step, 0], ArrowDown: [step, 0], ArrowLeft: [0, -step], ArrowRight: [0, step] }[ev.key];
          if (d && composeNudge(d[0], d[1])) { ev.preventDefault(); return; }
        }
      }
      if (ev.key !== 'Escape') return;
      if (S.edit.replacing) cancelColorReplace('按了 Esc');
      // 二次确认的待确认态也用 Esc 取消（与上面的待替换状态同一套取消习惯）
      if (cancelArmedConfirms()) log('已取消二次确认，未执行任何操作。');
      // 拼接里 Esc 也用来取消图层选择（与点空白等效，手不用离开键盘）
      if (cpS().active && cpS().selected.length) { cpS().selected = []; renderComposeAll(); }
    });
    $('btnEditClearSelection').onclick = editClearSelection;

    // ===== 12. 主体提取（任务 ANT-ARTTOOL-SUBJECT-EXTRACT-20260902）=====
    $('btnExtractOutside').onclick = function () { doExtract('outside'); };
    $('btnExtractInside').onclick = function () { doExtract('inside'); };
    $('btnExtractUndo').onclick = undoExtract;
    // 还原是破坏性的（丢弃全部剔除），照既有「还原为原图」的做法加二次确认
    armConfirm('btnExtractReset', {
      confirmText: '确认还原？',
      hint: '「还原为原图」会丢弃本关全部剔除结果。再点一次按钮确认；点其它地方取消。',
      onConfirm: resetExtract
    });
    $('btnPickBgCorners').onclick = pickBgCorners;
    $('btnKeepLargest').onclick = selectLargestComponent;
    $('btnPickSmallComps').onclick = selectSmallComponents;

    // 界面偏好（需求④）：先读回上次的状态，再装事件，避免装了事件又被恢复动作触发一遍
    S.ui = loadUiPrefs();
    $('optArtOnly').onchange = function () {
      S.ui.artOnly = !!$('optArtOnly').checked;
      applyArtOnly(false);
      saveUiPrefs();
    };
    $('btnCollapseAll').onclick = toggleCollapseAll;
    initCardCollapse();
    applyArtOnly(true);   // quiet：启动时恢复状态不必往日志里刷一条

    // ---- 拼接工作台（任务 ANT-ARTTOOL-PIECE-COMPOSE-20260915）----
    $('btnComposeMode').onclick = function () { cpS().active ? exitCompose() : enterCompose(); };
    $('btnComposeExit').onclick = exitCompose;
    $('btnComposeNew').onclick = composeNewCanvas;
    armConfirm('btnComposeClear', {
      confirmText: '再点一次＝清空画布',
      guard: function () {
        if (!cpS().layers.length) { log('画布上还没有图层，不用清'); return false; }
        return true;
      },
      hint: function () {
        return '将移除画布上全部 ' + cpS().layers.length + ' 个图层（部件列表保留）。再点一次确认，点别处或按 Esc 取消。';
      },
      action: composeClearCanvas
    });
    $('fileComposeTxt').onchange = function (ev) {
      composeImportTxt(ev.target.files);
      ev.target.value = '';    // 允许同一文件再次导入
    };
    $('btnComposeFromLib').onclick = function () { composeAddFromLib(false); };
    $('btnComposeSrcClear').onclick = composeClearSources;
    $('composeCellSize').oninput = drawCompose;
    $('optComposeGrid').onchange = drawCompose;
    $('optComposeConflict').onchange = drawCompose;
    $('optComposeOutline').onchange = drawCompose;
    // 拖拽：mousemove/mouseup 挂在 document 上，这样拖出画布再松手也能正确收尾
    // （只挂在 canvas 上的话，鼠标移出画布后就收不到事件，图层会一直粘在手上）
    $('composeCv').addEventListener('mousedown', onComposeMouseDown);
    $('composeCv').addEventListener('mousemove', onComposeMouseMove);
    // canvas 自己也要收 mouseup：在画布内松手是最常见的情况，不该绕一圈靠 document 兜。
    $('composeCv').addEventListener('mouseup', onComposeMouseUp);
    // document 级兜底：鼠标拖到画布外再松手也要正确收尾。
    //
    // ⚠ 这里的判断条件必须覆盖**全部三种**拖拽态。原先只判了 `cpS().drag`（移动图层），
    // 于是：直线/边框（shapeDrag）永远收不到 mouseup → **永远不落笔**；
    //       涂色（paintDrag）永远不被清除 → 松手后鼠标一进画布就接着画，成了「跟随鼠标赋色」。
    // 这正是用户 2026-09-15 报的前两个缺陷。既有的目标图那套（app.js 里 onCanvasMouseUp 的兜底）
    // 本来就是把 dragging 与 paintDragging 都判上的，这里对齐同一口径。
    document.addEventListener('mousemove', function (ev) {
      if (composeDragging()) onComposeMouseMove(ev);
    });
    document.addEventListener('mouseup', function () {
      if (composeDragging()) onComposeMouseUp();
    });
    $('btnComposeCheck').onclick = function () { composeRunAudit(true); };
    $('btnComposeExportTxt').onclick = composeExportTxt;
    $('btnComposeToLib').onclick = composeToLib;
    $('btnComposeMerge').onclick = composeMergeSelected;
    // 绘制（需求⑥）
    $('btnComposeNewLayer').onclick = composeNewBlankLayer;
    $('btnComposeLayerExport').onclick = composeExportLayer;
    $('btnComposeBorderFull').onclick = composeBorderFull;
    $('btnComposeUndo').onclick = composeUndo;
    Array.prototype.forEach.call(document.querySelectorAll('input[name="composeTool"]'), function (r) {
      r.onchange = function () {
        if (!r.checked) return;
        // 切工具时清掉进行中的拖拽，否则残留状态会让下一次操作行为诡异
        cpS().drag = null; cpS().paintDrag = null; cpS().shapeDrag = null;
        var tips = {
          move: '移动图层：在画布上拖部件即可挪位；选中后方向键逐格微调',
          paint: '手动涂色：在画布上按住拖，经过的像素改成当前颜色（作用于选中的那一个图层）',
          line: '直线：按住拖出起点到终点，松手落笔。线宽在下面填，单位是格',
          fill: '填充：点一下，把与该点相连的同色（或空白）区域整片换成当前颜色',
          border: '边框：在画布上拖一个范围，松手即按所选形态生成；也可点「铺满整张画布」'
        };
        if (tips[r.value]) log(tips[r.value]);
        // 说明这一笔会画到哪里。空白画布上不再需要用户先建图层，所以这里只是**告知**，不是要求。
        if (r.value !== 'move') {
          var tgt = composeTargetLayer(true);
          if (tgt) {
            log('　这一笔会画在「' + tgt.name + '」上（当前选中的图层）。');
          } else if (cpS().selected.length > 1) {
            log('　注意：现在选中了 ' + cpS().selected.length + ' 个图层，画之前先单选一个。');
          } else if (cpS().selected.length === 1) {
            log('　注意：选中的图层已固定，画不上去 —— 先「解固」，或点「新建空白图层」另起一层。');
          } else if (cpHasCanvas()) {
            log('　画布上还没有图层，直接画即可 —— 会自动为你新建一张覆盖整张画布的绘制层。');
          }
        }
        drawCompose();
        syncComposeButtons();
      };
    });
    $('inComposeWidth').oninput = drawCompose;
    $('optComposeErase').onchange = drawCompose;
    $('selComposeBorder').onchange = drawCompose;
    ['optShowVoid', 'optShowMaskOutline'].forEach(function (id) {
      if ($(id)) $(id).onchange = draw;
    });

    // 图纸库
    $('btnAddPiece').onclick = addCurrentAsPiece;
    $('btnPieceExportAll').onclick = exportPieceLibZip;
    $('btnPieceExportJson').onclick = exportPieceLibJson;
    $('filePieceLib').onchange = function (e) {
      var f = e.target.files[0];
      if (f) importPieceLibJson(f);
      e.target.value = '';
    };
    $('btnPieceClear').onclick = clearPieceLib;
    loadPieceLib();
    renderPieceLib();
    renderExtractPanel();
    syncCanvasToolClass();
    $('btnEditUndo').onclick = editUndo;
    // 破坏性操作：一击丢弃本关全部像素修改 → 加二次确认（用户 2026-08-20）。
    // editReset 自身逻辑未改，只是改由确认后才调用。
    armConfirm('btnEditReset', {
      confirmText: '确认还原？',
      hint: '「还原为原图」会丢弃本关全部像素修改，撤销记录也一并清空。再点一次按钮确认；' +
        '4 秒内不点则自动取消，也可按 Esc 或点击别处取消。',
      guard: function () {
        var it = cur();
        if (!it || !S.edit.original) { log('当前没有可还原的原图。'); return false; }
        return true;
      },
      action: editReset
    });
    $('btnEditExportTxt').onclick = exportEditedTxt;
    $('btnEditExportReport').onclick = exportEditReport;
    renderEditPalette();

    // 9. 暂存压力图
    $('optPressureOverlay').onchange = refreshPressureChart;
    // 压力图轨迹切换（需求 08.03 §一.5：采用切换查看方式，由用户裁决「加上切换按钮即可」）
    $('btnTrackOmni').onclick = function () { setPressureTrack('omni'); };
    $('btnTrackPlayer').onclick = function () { setPressureTrack('player'); };
    $('selPlayerSeed').onchange = refreshPressureChart;
    $('optPlayerSource').onchange = refreshPressureChart;

    // 10. 重构关卡
    $('genParamsInput').onchange = function (e) { if (e.target.files[0]) loadGenParamsFile(e.target.files[0]); e.target.value = ''; };
    $('btnClearGenParams').onclick = function () {
      S.genParams = null;
      $('genParamsInfo').innerHTML = '';
      $('btnClearGenParams').style.display = 'none';
      renderReconParamPreview();
      log('已清除导入的生成器参数，重新生成将使用工具默认参数');
    };
    // 启动时先显示一次默认参数，让用户点按钮前就能看到会用什么参数
    renderReconParamPreview();
    $('btnReconstruct').onclick = runReconstruct;
    Array.prototype.forEach.call(document.querySelectorAll('input[name="viewMode"]'), function (r) {
      r.onchange = function () {
        S.viewMode = r.value;
        demoPause();
        refreshBoardPanel();
        draw();
        log('切换视图：' + (r.value === 'after' ? '重构后关卡' : '原关卡'));
      };
    });
    $('btnRegionCompare').onclick = runReconRegionCompare;
    $('btnFullExport').onclick = exportFullPackage;

    // 10b. 碎色率检查（任务 ANT-ARTTOOL-FRAGMENT-QUOTA-20260825）
    if ($('btnFragCheck')) $('btnFragCheck').onclick = function () { runFragCheck(false); };
    if ($('fragGateSel')) $('fragGateSel').onchange = function () {
      var custom = this.value === 'custom';
      if ($('fragGateCustom')) $('fragGateCustom').style.display = custom ? '' : 'none';
      onFragGateChanged();
    };
    if ($('fragGateCustom')) $('fragGateCustom').oninput = onFragGateChanged;
    restoreFragGate();
    if ($('fragHighlight')) $('fragHighlight').onchange = function () {
      if (this.checked && !fragState.result) runFragCheck(true);
      draw();
    };
    renderFragPanel();

    // 11. 待导出库
    $('btnAddToLibrary').onclick = addCurrentToExportLibrary;
    $('btnLibExportSelected').onclick = function () { exportLibraryBatch(true); };
    $('btnLibExportAll').onclick = function () { exportLibraryBatch(false); };
    // 破坏性操作：一击清空整个待导出库（含浏览器本地保存的记录）→ 加二次确认（用户 2026-08-20）。
    // clearExportLibrary 自身逻辑未改；库为空时与原先一样不做任何清空动作，只是多给一句提示。
    armConfirm('btnLibClear', {
      confirmText: '确认清空？',
      hint: function () {
        return '「清空待导出库」会移除全部 ' + S.exportLib.length + ' 项，' +
          '浏览器本地保存的记录一并删除，不可撤销。再点一次按钮确认；' +
          '4 秒内不点则自动取消，也可按 Esc 或点击别处取消。';
      },
      guard: function () {
        if (!S.exportLib.length) { log('待导出库本来就是空的，无需清空。'); return false; }
        return true;
      },
      action: clearExportLibrary
    });
    loadExportLibFromStorage();
    renderExportLibrary();

    draw();
    log('工具就绪。求解口径：Solver.solve 六遍编排；进度口径：已完成盒数 ÷ 总盒数；冰耐久 3。');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
